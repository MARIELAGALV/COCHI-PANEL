# CO-CHI v0.23.53 - RELEASE OFUSCADA / R8
#
# La ofuscacion real la realiza R8 porque release usa minifyEnabled true.
# Estas reglas mantienen solo metadatos necesarios para compatibilidad y
# trazas recuperables con mapping.txt, sin conservar nombres de clases de CO-CHI.

# Compatibilidad con anotaciones/genericos usados por librerias AndroidX/Media3/Coil.
-keepattributes RuntimeVisibleAnnotations,RuntimeInvisibleAnnotations,AnnotationDefault,Signature,InnerClasses,EnclosingMethod

# Mantener numeros de linea para poder usar mapping.txt al diagnosticar fallos,
# pero ocultar el nombre real de los archivos fuente en las trazas.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# No se agrega un -keep global para com.cochi.client: las clases internas
# de la app quedan disponibles para renombrado/optimizacion por R8.
# Los componentes declarados en AndroidManifest son gestionados por el plugin Android.

# v0.23.53: se mantiene el endurecimiento adicional sin conservar nombres de la app.
-allowaccessmodification

# Evitar que logs de desarrollo de nivel verbose/debug/info terminen exponiendo
# rutas internas o estados de ejecución en una release. Warn/Error se conservan
# porque ya están sanitizados y ayudan a diagnosticar fallos reales.
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
    public static int i(...);
}

# v0.23.55: reempaqueta las clases de programa para reducir informacion
# de paquetes/nombres disponible al descompilar la APK release.
-repackageclasses x


# v0.23.62: adaptar referencias textuales a clases cuando R8 las renombra.
-adaptclassstrings

# Mantener ocultos metadatos de parámetros/métodos que no necesita la app.
-renamesourcefileattribute SourceFile
