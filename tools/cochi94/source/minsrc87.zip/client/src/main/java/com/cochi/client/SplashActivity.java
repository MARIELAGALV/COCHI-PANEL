package com.cochi.client;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/** Entrada única de CO-CHI con actualización obligatoria antes de abrir la app. */
public class SplashActivity extends AppCompatActivity {
    private TextView updateStatus;
    private View updateAction;
    private boolean routed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!AppIntegrity.isRuntimeAllowed(this)) {
            Toast.makeText(this, "Instalación de CO-CHI no válida", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        setContentView(R.layout.activity_splash);
        updateStatus = findViewById(R.id.updateStatus);
        updateAction = findViewById(R.id.updateAction);

        UpdateManager.checkOnLaunch(this, updateStatus, updateAction, this::openNextScreen);
    }

    @Override
    protected void onResume() {
        super.onResume();
        UpdateManager.resumePendingInstall(this, updateStatus, updateAction, this::openNextScreen);
    }

    @Override
    public void onBackPressed() {
        if (UpdateManager.hasMandatoryPending(this)) {
            Toast.makeText(this,
                    "Instalá la actualización para continuar con CO-CHI",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        super.onBackPressed();
    }

    private void openNextScreen() {
        if (routed || isFinishing() || UpdateManager.hasMandatoryPending(this)) return;
        routed = true;

        if (!SessionManager.isActivated(this)) {
            routeAfterRefresh();
            return;
        }

        // v0.23.79: antes de decidir que una cuenta venció, consultamos el PANEL.
        // Evita bloquear un dispositivo por un vencimiento viejo guardado localmente
        // después de que el cliente fue renovado desde el panel.
        updateStatus.setText("Comprobando vigencia…");
        new Thread(() -> {
            try {
                SessionManager.refreshActivationBlocking(SplashActivity.this);
            } catch (Exception ignored) {
                // Sin red conservamos el último estado conocido; no inventamos fechas.
            }
            runOnUiThread(this::routeAfterRefresh);
        }, "cochi-launch-access-refresh").start();
    }
    private void routeAfterRefresh() {
        if (isFinishing()) return;
        Intent intent;
        if (!SessionManager.isActivated(this)) {
            intent = new Intent(this, LoginActivity.class);
        } else if (SessionManager.isExpired(this)) {
            intent = new Intent(this, ExpiredActivity.class);
        } else {
            intent = new Intent(this, MainActivity.class);
        }
        startActivity(intent);
        finish();
    }

}
