package com.cochi.client;

import org.json.JSONObject;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Opción reproducible que nunca muestra su URL al usuario. */
public final class PlaybackOption {
    public final String server;
    public final String language;
    public final String subtitles;
    public final String quality;
    public final String url;
    public final String type;
    public final Map<String, String> headers;
    public final String clearKeyPairs;
    public final int priority;
    public final int localStoreIndex;
    public final int localSourceIndex;

    public PlaybackOption(String server, String language, String subtitles, String quality,
                          String url, String type, Map<String, String> headers,
                          String clearKeyPairs, int priority) {
        this(server, language, subtitles, quality, url, type, headers, clearKeyPairs, priority, -1, -1);
    }

    public PlaybackOption(String server, String language, String subtitles, String quality,
                          String url, String type, Map<String, String> headers,
                          String clearKeyPairs, int priority, int localStoreIndex, int localSourceIndex) {
        this.server = safe(server).isEmpty() ? "Servidor" : safe(server);
        this.language = normalizeLanguage(language);
        this.subtitles = normalizeSubtitles(subtitles);
        this.quality = safe(quality);
        this.url = safe(url);
        this.type = safe(type).isEmpty() ? "auto" : safe(type);
        this.headers = headers == null || headers.isEmpty()
                ? Collections.emptyMap()
                : Collections.unmodifiableMap(new LinkedHashMap<>(headers));
        this.clearKeyPairs = safe(clearKeyPairs);
        this.priority = priority;
        this.localStoreIndex = localStoreIndex;
        this.localSourceIndex = localSourceIndex;
    }

    public boolean isPlayable() { return !url.isEmpty(); }

    public String groupKey() {
        return server.toLowerCase() + "|" + language.toLowerCase() + "|" + subtitles.toLowerCase();
    }

    public String groupLabel() {
        StringBuilder b = new StringBuilder(server).append(" · ").append(language);
        if (!subtitles.isEmpty() && !"Sin subtítulos informados".equals(subtitles)) b.append(" · ").append(subtitles);
        return b.toString();
    }

    public String optionLabel(int index) {
        String q = quality.isEmpty() ? "Calidad automática" : quality;
        return "Opción " + (index + 1) + " · " + q;
    }

    public JSONObject headersJson() {
        JSONObject obj = new JSONObject();
        try { for (Map.Entry<String, String> e : headers.entrySet()) obj.put(e.getKey(), e.getValue()); }
        catch (Exception ignored) { }
        return obj;
    }

    private static String normalizeLanguage(String raw) {
        String v = safe(raw);
        if (v.isEmpty()) return "Idioma sin verificar";
        String n = v.toLowerCase();
        if (n.contains("lat") || n.contains("es-419") || n.contains("es_la") || n.contains("es-la")) return "Español Latino";
        if (n.contains("cast") || n.contains("es-es") || n.equals("españa")) return "Castellano";
        if (n.equals("es") || n.contains("spanish") || n.contains("español")) return "Español";
        if (n.contains("eng") || n.equals("en") || n.contains("ingl")) return "Inglés";
        return v;
    }

    private static String normalizeSubtitles(String raw) {
        String v = safe(raw);
        if (v.isEmpty()) return "Sin subtítulos informados";
        String n = v.toLowerCase();
        if (n.contains("es") || n.contains("spa") || n.contains("spanish") || n.contains("españ")) return "Subtítulos ES";
        if (n.equals("none") || n.equals("no") || n.contains("sin subt")) return "Sin subtítulos";
        return v;
    }

    private static String safe(String v) { return v == null ? "" : v.trim(); }
}
