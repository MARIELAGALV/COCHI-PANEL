package com.cochi.client;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.List;

public final class WebSearchAdapter extends RecyclerView.Adapter<WebSearchAdapter.Holder> {
    public interface Listener {
        void onClick(WebSearchResult item);
        void onFocus(WebSearchResult item);
    }

    private final Context context;
    private final Listener listener;
    private final boolean television;
    private final List<WebSearchResult> items = new ArrayList<>();

    public WebSearchAdapter(Context context, boolean television, Listener listener) {
        this.context = context;
        this.television = television;
        this.listener = listener;
        setHasStableIds(true);
    }

    public void submitList(List<WebSearchResult> next) {
        items.clear();
        if (next != null) items.addAll(next);
        notifyDataSetChanged();
    }

    @Override public long getItemId(int position) {
        WebSearchResult item = items.get(position);
        return (item.mediaType + ":" + item.tmdbId).hashCode();
    }

    @NonNull
    @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        MaterialCardView card = new MaterialCardView(context);
        card.setFocusable(true);
        card.setClickable(true);
        card.setRadius(dp(television ? 16 : 18));
        card.setCardBackgroundColor(ManagedTheme.button(context));
        card.setStrokeColor(ManagedTheme.border(context));
        card.setStrokeWidth(dp(1));

        RecyclerView.LayoutParams cardParams = new RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(dp(television ? 7 : 6), dp(6), dp(television ? 7 : 6), dp(10));
        card.setLayoutParams(cardParams);

        LinearLayout content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 0, 0, dp(10));
        card.addView(content, new MaterialCardView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ImageView poster = new ImageView(context);
        poster.setScaleType(ImageView.ScaleType.CENTER_CROP);
        poster.setContentDescription("Póster");
        content.addView(poster, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(television ? 228 : 240)));

        TextView type = new TextView(context);
        type.setTextColor(ManagedTheme.color(context, R.color.cochi_accent_2));
        type.setTextSize(television ? 10f : 11f);
        type.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        type.setPadding(dp(10), dp(8), dp(10), 0);
        content.addView(type, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(context);
        title.setTextColor(ManagedTheme.color(context, R.color.cochi_text));
        title.setTextSize(television ? 15f : 16f);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setMaxLines(2);
        title.setGravity(Gravity.START);
        title.setPadding(dp(10), dp(2), dp(10), 0);
        content.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView year = new TextView(context);
        year.setTextColor(ManagedTheme.color(context, R.color.cochi_muted));
        year.setTextSize(television ? 11f : 12f);
        year.setPadding(dp(10), dp(2), dp(10), 0);
        content.addView(year, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        return new Holder(card, poster, type, title, year);
    }

    @Override public void onBindViewHolder(@NonNull Holder holder, int position) {
        WebSearchResult item = items.get(position);
        holder.type.setText(item.typeLabel());
        holder.title.setText(item.title);
        holder.year.setText(item.year.isEmpty() ? "Año sin informar" : item.year);
        ImageLoader.load(item.posterUrl, holder.poster);

        holder.card.setOnClickListener(v -> listener.onClick(item));
        holder.card.setOnFocusChangeListener((v, hasFocus) -> {
            holder.card.setStrokeWidth(dp(hasFocus ? 3 : 1));
            holder.card.setStrokeColor(context.getColor(hasFocus
                    ? R.color.cochi_accent_2
                    : television ? R.color.cochi_tv_border_soft : R.color.cochi_border));
            holder.card.setCardBackgroundColor(context.getColor(hasFocus
                    ? (television ? R.color.cochi_tv_surface_focus : R.color.cochi_surface_focus)
                    : (television ? R.color.cochi_tv_surface : R.color.cochi_surface)));
            if (hasFocus) listener.onFocus(item);
        });
    }

    @Override public int getItemCount() { return items.size(); }

    static final class Holder extends RecyclerView.ViewHolder {
        final MaterialCardView card;
        final ImageView poster;
        final TextView type;
        final TextView title;
        final TextView year;

        Holder(@NonNull MaterialCardView card, ImageView poster, TextView type, TextView title, TextView year) {
            super(card);
            this.card = card;
            this.poster = poster;
            this.type = type;
            this.title = title;
            this.year = year;
        }
    }

    private int dp(int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }
}
