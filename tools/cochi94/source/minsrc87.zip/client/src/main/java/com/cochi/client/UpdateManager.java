package com.cochi.client;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.view.View;
import android.widget.TextView;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Actualizador obligatorio de CO-CHI.
 *
 * Si existe una versión nueva, SplashActivity queda bloqueada detrás del instalador.
 * CO-CHI no abre la pantalla principal hasta que la versión instalada ya sea la nueva.
 */
public final class UpdateManager {
    private static final String APK_ASSET_NAME = "CO-CHI.apk";
    private static final String PREFS = "cochi_updater";
    private static final String KEY_PENDING_APK = "pending_apk";
    private static final String KEY_PENDING_VERSION = "pending_version";
    private static final String KEY_AWAITING_PERMISSION = "awaiting_permission";

    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final AtomicBoolean CHECK_BUSY = new AtomicBoolean(false);
    private static final AtomicBoolean RESUME_BUSY = new AtomicBoolean(false);

    private UpdateManager() {}

    public interface DoneCallback {
        void onDone();
    }

    public static boolean hasMandatoryPending(Context context) {
        String version = prefs(context).getString(KEY_PENDING_VERSION, "");
        return version != null && !version.trim().isEmpty()
                && isNewer(version, installedVersion(context));
    }

    public static void checkOnLaunch(
            Activity activity, TextView status, View action, DoneCallback done) {
        hideAction(action);

        // Si una actualización obligatoria quedó pendiente de un intento anterior,
        // jamás entramos a la app vieja. Dejamos al usuario en esta pantalla.
        String pendingVersion = prefs(activity).getString(KEY_PENDING_VERSION, "");
        String pendingPath = prefs(activity).getString(KEY_PENDING_APK, "");
        if (pendingVersion != null && !pendingVersion.trim().isEmpty()) {
            if (!isNewer(pendingVersion, installedVersion(activity))) {
                clearPending(activity);
            } else if (pendingPath != null && !pendingPath.trim().isEmpty()
                    && new File(pendingPath).isFile()) {
                setStatusNow(status,
                        "Actualización obligatoria " + pendingVersion + " · instalá para continuar");
                showInstallAction(activity, status, action, new File(pendingPath));
                return;
            } else {
                clearPending(activity);
            }
        }

        if (!CHECK_BUSY.compareAndSet(false, true)) return;

        setStatus(activity, status, "Buscando actualizaciones…");
        EXECUTOR.execute(() -> {
            try {
                ReleaseInfo release = fetchLatestRelease(activity);
                if (release == null || !isNewer(release.versionName, installedVersion(activity))) {
                    finishNormally(activity, status, action, done);
                    return;
                }
                if (release.apkUrl == null || release.apkUrl.trim().isEmpty()) {
                    finishNormally(activity, status, action, done);
                    return;
                }

                setStatus(activity, status,
                        "Nueva versión " + release.versionName + " · descargando…");
                File apk = downloadApk(activity, release.apkUrl);
                if (apk == null || !apk.isFile() || apk.length() < 1024L) {
                    CHECK_BUSY.set(false);
                    activity.runOnUiThread(() -> {
                        setStatusNow(status,
                                "No pude descargar la actualización · reintentá para continuar");
                        showRetryAction(activity, status, action, done);
                    });
                    return;
                }

                prefs(activity).edit()
                        .putString(KEY_PENDING_APK, apk.getAbsolutePath())
                        .putString(KEY_PENDING_VERSION, release.versionName)
                        .putBoolean(KEY_AWAITING_PERMISSION, false)
                        .apply();

                CHECK_BUSY.set(false);
                activity.runOnUiThread(() -> {
                    setStatusNow(status,
                            "Actualización " + release.versionName + " lista · instalando…");
                    hideAction(action);
                    installOrRequestPermission(activity, apk, status, action);
                });
            } catch (Exception ignored) {
                finishNormally(activity, status, action, done);
            }
        });
    }

    /**
     * Al volver del instalador o de Ajustes comprobamos la versión instalada.
     * Si sigue siendo vieja, Splash permanece bloqueada y ofrece INSTALAR ACTUALIZACIÓN.
     */
    public static void resumePendingInstall(
            Activity activity, TextView status, View action, DoneCallback done) {
        if (!RESUME_BUSY.compareAndSet(false, true)) return;
        try {
            String version = prefs(activity).getString(KEY_PENDING_VERSION, "");
            String path = prefs(activity).getString(KEY_PENDING_APK, "");
            if (version == null || version.trim().isEmpty()) return;

            // La instalación se completó: recién ahora permitimos entrar a CO-CHI.
            if (!isNewer(version, installedVersion(activity))) {
                clearPending(activity);
                hideAction(action);
                CHECK_BUSY.set(false);
                done.onDone();
                return;
            }

            File apk = path == null ? null : new File(path);
            if (apk == null || !apk.isFile()) {
                clearPending(activity);
                CHECK_BUSY.set(false);
                setStatusNow(status, "Actualización pendiente · descargando nuevamente…");
                checkOnLaunch(activity, status, action, done);
                return;
            }

            boolean wasWaitingPermission = prefs(activity)
                    .getBoolean(KEY_AWAITING_PERMISSION, false);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    && !activity.getPackageManager().canRequestPackageInstalls()) {
                setStatusNow(status,
                        "Actualización obligatoria · habilitá CO-CHI para instalarla");
                showInstallAction(activity, status, action, apk);
                return;
            }

            // Si el usuario acaba de volver de habilitar "apps desconocidas",
            // continuamos automáticamente con el instalador, sin mandarlo al inicio.
            if (wasWaitingPermission) {
                prefs(activity).edit().putBoolean(KEY_AWAITING_PERMISSION, false).apply();
                setStatusNow(status, "Permiso listo · abriendo actualización…");
                installOrRequestPermission(activity, apk, status, action);
                return;
            }

            setStatusNow(status,
                    "Actualización obligatoria " + version + " · instalá para continuar");
            showInstallAction(activity, status, action, apk);
        } catch (Exception ignored) {
            // Una actualización ya detectada nunca deriva a la pantalla principal vieja.
            setStatusNow(status, "Actualización obligatoria · reintentá la instalación");
        } finally {
            RESUME_BUSY.set(false);
        }
    }

    private static ReleaseInfo fetchLatestRelease(Context context) throws Exception {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(RuntimeStrings.updatesApi());
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(7000);
            connection.setReadTimeout(9000);
            connection.setUseCaches(false);
            connection.setRequestProperty("Accept", "application/vnd.github+json");
            connection.setRequestProperty("Cache-Control", "no-cache");
            connection.setRequestProperty("Pragma", "no-cache");
            connection.setRequestProperty("User-Agent", "CO-CHI-Updater/" + installedVersion(context));

            int code = connection.getResponseCode();
            if (code != HttpURLConnection.HTTP_OK) return null;

            String json = readUtf8(connection.getInputStream());
            JSONArray releases = new JSONArray(json);
            ReleaseInfo best = null;

            for (int r = 0; r < releases.length(); r++) {
                JSONObject root = releases.optJSONObject(r);
                if (root == null || root.optBoolean("draft", false) || root.optBoolean("prerelease", false)) continue;

                String tag = normalizeVersion(root.optString("tag_name", ""));
                if (tag.isEmpty()) continue;

                String apkUrl = "";
                JSONArray assets = root.optJSONArray("assets");
                if (assets != null) {
                    for (int i = 0; i < assets.length(); i++) {
                        JSONObject asset = assets.optJSONObject(i);
                        if (asset == null) continue;
                        if (APK_ASSET_NAME.equalsIgnoreCase(asset.optString("name", ""))) {
                            apkUrl = asset.optString("browser_download_url", "");
                            break;
                        }
                    }
                }
                if (apkUrl.isEmpty()) continue;

                ReleaseInfo candidate = new ReleaseInfo(tag, apkUrl);
                if (best == null || isNewer(candidate.versionName, best.versionName)) {
                    best = candidate;
                }
            }
            return best;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static File downloadApk(Context context, String apkUrl) throws Exception {
        File root = context.getExternalFilesDir(null);
        if (root == null) root = context.getFilesDir();
        File updatesDir = new File(root, "updates");
        if (!updatesDir.exists() && !updatesDir.mkdirs()) return null;

        File temp = new File(updatesDir, "CO-CHI.download");
        File target = new File(updatesDir, APK_ASSET_NAME);
        if (temp.exists()) temp.delete();

        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(apkUrl).openConnection();
            connection.setRequestMethod("GET");
            connection.setInstanceFollowRedirects(true);
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(30000);
            connection.setRequestProperty("User-Agent", "CO-CHI-Updater/" + installedVersion(context));

            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) return null;

            try (InputStream in = new BufferedInputStream(connection.getInputStream());
                 FileOutputStream out = new FileOutputStream(temp)) {
                byte[] buffer = new byte[32 * 1024];
                int read;
                while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
                out.flush();
            }

            if (target.exists() && !target.delete()) return null;
            if (!temp.renameTo(target)) {
                try (InputStream in = new BufferedInputStream(new java.io.FileInputStream(temp));
                     FileOutputStream out = new FileOutputStream(target)) {
                    byte[] buffer = new byte[32 * 1024];
                    int read;
                    while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
                }
                temp.delete();
            }
            return target;
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static void installOrRequestPermission(
            Activity activity, File apk, TextView status, View action) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                && !activity.getPackageManager().canRequestPackageInstalls()) {
            setStatusNow(status, "Habilitá CO-CHI para instalar la actualización obligatoria");
            prefs(activity).edit().putBoolean(KEY_AWAITING_PERMISSION, true).apply();
            try {
                Intent settings = new Intent(
                        Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + activity.getPackageName()));
                activity.startActivity(settings);
                return;
            } catch (Exception ignored) {
            }
        }

        try {
            prefs(activity).edit().putBoolean(KEY_AWAITING_PERMISSION, false).apply();
            hideAction(action);
            launchInstaller(activity, apk);
            // IMPORTANTE: no llamamos a done.onDone() y no limpiamos el pendiente.
            // Splash queda debajo del instalador y la pantalla principal no puede abrirse.
        } catch (Exception ignored) {
            setStatusNow(status, "No pude abrir el instalador · reintentá");
            showInstallAction(activity, status, action, apk);
        }
    }

    private static void showInstallAction(
            Activity activity, TextView status, View action, File apk) {
        if (action == null) return;
        action.setVisibility(View.VISIBLE);
        action.setEnabled(true);
        if (action instanceof TextView) ((TextView) action).setText("INSTALAR ACTUALIZACIÓN");
        action.setOnClickListener(v -> installOrRequestPermission(activity, apk, status, action));
    }

    private static void showRetryAction(
            Activity activity, TextView status, View action, DoneCallback done) {
        if (action == null) return;
        action.setVisibility(View.VISIBLE);
        action.setEnabled(true);
        if (action instanceof TextView) ((TextView) action).setText("REINTENTAR DESCARGA");
        action.setOnClickListener(v -> checkOnLaunch(activity, status, action, done));
    }

    private static void hideAction(View action) {
        if (action == null) return;
        action.setVisibility(View.GONE);
        action.setOnClickListener(null);
    }

    private static void launchInstaller(Activity activity, File apk) {
        Uri uri;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            uri = FileProvider.getUriForFile(
                    activity,
                    activity.getPackageName() + ".fileprovider",
                    apk);
        } else {
            uri = Uri.fromFile(apk);
        }

        Intent install = new Intent(Intent.ACTION_VIEW);
        install.setDataAndType(uri, "application/vnd.android.package-archive");
        install.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        activity.startActivity(install);
    }

    private static String installedVersion(Context context) {
        try {
            android.content.pm.PackageInfo info = context.getPackageManager()
                    .getPackageInfo(context.getPackageName(), 0);
            String version = info.versionName;
            return version == null || version.trim().isEmpty() ? "0" : version.trim();
        } catch (Exception ignored) {
            return "0";
        }
    }

    private static boolean isNewer(String remote, String local) {
        int[] r = versionParts(remote);
        int[] l = versionParts(local);
        int max = Math.max(r.length, l.length);
        for (int i = 0; i < max; i++) {
            int rv = i < r.length ? r[i] : 0;
            int lv = i < l.length ? l[i] : 0;
            if (rv != lv) return rv > lv;
        }
        return false;
    }

    private static int[] versionParts(String value) {
        String clean = normalizeVersion(value);
        String[] raw = clean.split("\\.");
        int[] result = new int[raw.length];
        for (int i = 0; i < raw.length; i++) {
            String digits = raw[i].replaceAll("[^0-9].*$", "");
            try {
                result[i] = digits.isEmpty() ? 0 : Integer.parseInt(digits);
            } catch (NumberFormatException ignored) {
                result[i] = 0;
            }
        }
        return result;
    }

    private static String normalizeVersion(String value) {
        if (value == null) return "";
        String out = value.trim().toLowerCase(Locale.ROOT);
        while (out.startsWith("v")) out = out.substring(1);
        return out;
    }

    private static String readUtf8(InputStream input) throws Exception {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int read;
        while ((read = input.read(buffer)) != -1) out.write(buffer, 0, read);
        return out.toString(java.nio.charset.StandardCharsets.UTF_8.name());
    }

    private static void finishNormally(
            Activity activity, TextView status, View action, DoneCallback done) {
        CHECK_BUSY.set(false);
        activity.runOnUiThread(() -> {
            hideAction(action);
            setStatusNow(status, "CO-CHI está actualizado");
            if (status != null) status.postDelayed(done::onDone, 350L);
            else done.onDone();
        });
    }

    private static void setStatus(Activity activity, TextView status, String text) {
        activity.runOnUiThread(() -> setStatusNow(status, text));
    }

    private static void setStatusNow(TextView status, String text) {
        if (status != null) status.setText(text);
    }

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static void clearPending(Context context) {
        prefs(context).edit()
                .remove(KEY_PENDING_APK)
                .remove(KEY_PENDING_VERSION)
                .remove(KEY_AWAITING_PERMISSION)
                .apply();
    }

    private static final class ReleaseInfo {
        final String versionName;
        final String apkUrl;
        ReleaseInfo(String versionName, String apkUrl) {
            this.versionName = versionName;
            this.apkUrl = apkUrl;
        }
    }
}
