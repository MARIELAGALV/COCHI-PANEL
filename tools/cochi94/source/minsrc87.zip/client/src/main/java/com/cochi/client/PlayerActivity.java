package com.cochi.client;

import android.annotation.SuppressLint;
import android.app.UiModeManager;
import android.content.Context;
import android.content.res.Configuration;
import android.media.MediaDrm;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.ImageButton;
import android.widget.TextView;
import com.google.android.material.button.MaterialButton;
import com.tuempresa.motor.MotorPrivado;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.drm.DefaultDrmSessionManager;
import androidx.media3.exoplayer.drm.ExoMediaDrm;
import androidx.media3.exoplayer.drm.FrameworkMediaDrm;
import androidx.media3.exoplayer.drm.LocalMediaDrmCallback;
import androidx.media3.exoplayer.drm.MediaDrmCallback;
import androidx.media3.exoplayer.drm.MediaDrmCallbackException;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy;
import androidx.media3.ui.DefaultTimeBar;
import androidx.media3.ui.PlayerView;
import androidx.media3.ui.TrackSelectionDialogBuilder;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import org.json.JSONArray;
import org.json.JSONObject;

public class PlayerActivity extends AppCompatActivity {

    // Entradas antiguas: se conservan solo para pruebas internas y compatibilidad de desarrollo.
    public static final String EXTRA_URL = "cochi.extra.URL";
    public static final String EXTRA_CLEARKEY_KID = "cochi.extra.CLEARKEY_KID";
    public static final String EXTRA_CLEARKEY_KEY = "cochi.extra.CLEARKEY_KEY";
    public static final String EXTRA_CLEARKEY_MULTI = "cochi.extra.CLEARKEY_MULTI";
    public static final String EXTRA_STREAM_TYPE = "cochi.extra.STREAM_TYPE";
    public static final String EXTRA_HEADERS_JSON = "cochi.extra.HEADERS_JSON";
    public static final String EXTRA_DISPLAY_NAME = "cochi.extra.DISPLAY_NAME";

    // Entradas de la experiencia TV real.
    public static final String EXTRA_TV_MODE = "cochi.extra.TV_MODE";
    public static final String EXTRA_CHANNEL_INDEX = "cochi.extra.CHANNEL_INDEX";
    public static final String EXTRA_STORE_ITEM = "cochi.extra.STORE_ITEM";
    public static final String EXTRA_CATALOG_SOURCE = "cochi.extra.CATALOG_SOURCE";
    public static final String EXTRA_FORCE_START = "cochi.extra.FORCE_START";
    public static final String EXTRA_AUTO_RESUME = "cochi.extra.AUTO_RESUME";
    public static final String EXTRA_AUTO_NEXT_SERIES = "cochi.extra.AUTO_NEXT_SERIES";

    private static final int BUFFER_MIN_MS = 20_000;
    private static final int BUFFER_MAX_MS = 60_000;
    private static final int BUFFER_PLAYBACK_MS = 1_000;
    private static final int BUFFER_AFTER_REBUFFER_MS = 5_000;
    private static final long SEEK_INCREMENT_MS = 10_000L;
    private static final long LARGE_SEEK_INCREMENT_MS = 15L * 60L * 1000L;

    // v0.23.58: recuperación rápida. En TV el usuario no debe quedar esperando
    // 10-30 s a que una conexión vieja agote sus timeouts. Media3 conserva algunos
    // reintentos internos, pero CO-CHI fuerza una recuperación escalonada propia.
    private static final int TV_LOAD_RETRY_COUNT = 1;
    private static final int VOD_LOAD_RETRY_COUNT = 4;
    private static final long TV_FAST_RECOVERY_MS = 1_800L;
    private static final long TV_FULL_RECOVERY_MS = 6_500L;
    private static final long VOD_FAST_RECOVERY_MS = 3_500L;
    private static final long VOD_FULL_RECOVERY_MS = 7_000L;
    private static final long[] FATAL_RECONNECT_DELAYS_MS = {300L, 700L, 1_400L, 2_500L};
    private static final long TV_STARTUP_STATUS_MS = 9_000L;

    private ExoPlayer player;
    private PlayerView playerView;
    private WebView youtubeWebView;
    private ProgressBar loading;
    private View channelInfo;
    private TextView channelNumber;
    private TextView channelName;
    private View episodeActions;
    private MaterialButton skipRecapButton;
    private MaterialButton skipIntroButton;
    private MaterialButton nextEpisodeButton;
    private View cochiNavOverlay;
    private ImageButton cochiPreviousButton;
    private ImageButton cochiNextButton;
    private ImageButton cochiSettingsButton;
    private SeriesStore.EpisodeMarkers activeEpisodeMarkers = new SeriesStore.EpisodeMarkers(null, null, -1L);

    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable hideChannelInfo = () -> channelInfo.setVisibility(View.GONE);
    // Hilo de trabajo dedicado al SDK motorprivado (sus llamadas son
    // sincronas y con red: nunca ejecutarlas en el hilo principal).
    private final ExecutorService motorPrivadoExecutor = Executors.newSingleThreadExecutor();
    private boolean tvMode;
    private boolean storeItemMode;
    private CatalogSource catalogSource;
    private int tv2ResolveGeneration = 0;
    private int privateMediaResolveGeneration = 0;
    private int currentChannelIndex = -1;
    private int fatalRetryCount = 0;
    private long reconnectResumePositionMs = 0L;
    private int playbackGeneration = 0;
    private Channel activeChannel;
    private Runnable fastRecoveryWatchdog;
    private Runnable fullRecoveryWatchdog;
    private boolean recoveryOperationRunning;
    private boolean activeChannelReachedReady;
    private boolean startupUnavailableShown;
    private Runnable startupStatusWatchdog;
    private final Runnable fatalReconnectRunnable = new Runnable() {
        @Override public void run() {
            if (player == null || isFinishing() || isDestroyed()) return;
            try {
                // Películas/Series continúan desde el mismo punto. En TV en vivo
                // dejamos que el MediaSource vuelva a resolver el punto actual/directo.
                if (shouldTrackProgress() && reconnectResumePositionMs > 0L) {
                    player.seekTo(reconnectResumePositionMs);
                }
                player.prepare();
                player.play();
                armPlaybackRecoveryWatchdog();
            } catch (Exception e) {
                Log.w("COCHI-NET", "Reintento de reproducción falló", e);
            }
        }
    };
    private boolean forceStart;
    private boolean autoResume;
    private boolean autoNextSeries;
    private boolean endHandledForCurrent;
    private volatile boolean seriesAccessCheckRunning;
    private boolean seriesAccessDenied;
    private Runnable pendingSeriesAccessAction;
    private static final long RECENT_SERIES_ACCESS_WINDOW_MS = 30_000L;

    private static final String DRM_TAG = "COCHI-DRM";
    private volatile String lastDrmRequestDiagnostic = "KeyRequest aún no recibido";

    private final Runnable progressTicker = new Runnable() {
        @Override public void run() {
            saveProgressNow();
            uiHandler.postDelayed(this, 10_000L);
        }
    };


    private final Runnable markerTicker = new Runnable() {
        @Override public void run() {
            // Los marcadores no necesitan reconstruir la botonera cinco veces por segundo.
            // En TV/Box eso generaba trabajo de foco innecesario y tirones al navegar.
            updateEpisodeActions();
            syncCochiNavigationWithController();
            uiHandler.postDelayed(this, 500L);
        }
    };

    // Mantiene los botones propios de navegación sincronizados con la botonera real
    // de Media3, incluso cuando esta se oculta automáticamente sin un nuevo toque.
    private final Runnable navigationVisibilityTicker = new Runnable() {
        @Override public void run() {
            syncCochiNavigationWithController();
            // En Android TV también seguimos la visibilidad del controlador cuando
            // reproducimos Películas/Series. Es un chequeo liviano y evita que Media3
            // oculte los extremos ANTERIOR/SIGUIENTE en Películas.
            boolean television = isTelevisionDevice();
            if (!television || (storeItemMode && !tvMode)) {
                uiHandler.postDelayed(this, television ? 250L : 160L);
            }
        }
    };

    // Series puede quedar cargada desde caché. Mientras se reproduce un episodio,
    // comprobamos periódicamente el estado real del dispositivo para que un bloqueo
    // desde el PANEL corte también una reproducción que ya estaba abierta.
    private final Runnable seriesAccessTicker = new Runnable() {
        @Override public void run() {
            if (catalogSource != CatalogSource.SERIES || isFinishing() || isDestroyed()) return;
            validateSeriesAccessAsync(false, null);
            uiHandler.postDelayed(this, 30_000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        MotorPrivado.initialize(getApplicationContext());

        // Mientras el reproductor de CO-CHI esté en primer plano, Android no debe
        // atenuar ni bloquear la pantalla por inactividad. La bandera pertenece a
        // esta Activity, por lo que se libera automáticamente al salir del player.
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (!BuildConfig.DEBUG) {
            // Release: evita capturas/grabación del reproductor y de datos de reproducción.
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        }

        playerView = findViewById(R.id.playerView);
        youtubeWebView = findViewById(R.id.youtubeWebView);
        loading = findViewById(R.id.loading);
        channelInfo = findViewById(R.id.channelInfo);
        channelNumber = findViewById(R.id.channelNumber);
        channelName = findViewById(R.id.channelName);
        episodeActions = findViewById(R.id.episodeActions);
        skipRecapButton = findViewById(R.id.skipRecapButton);
        skipIntroButton = findViewById(R.id.skipIntroButton);
        nextEpisodeButton = findViewById(R.id.nextEpisodeButton);
        cochiNavOverlay = findViewById(R.id.cochiNavOverlay);
        cochiPreviousButton = findViewById(R.id.cochiPreviousButton);
        cochiNextButton = findViewById(R.id.cochiNextButton);
        cochiSettingsButton = findViewById(R.id.cochiSettingsButton);

        skipRecapButton.setOnClickListener(v -> skipMarker(activeEpisodeMarkers.recap, "Resumen omitido"));
        skipIntroButton.setOnClickListener(v -> skipMarker(activeEpisodeMarkers.intro, "Intro omitida"));
        nextEpisodeButton.setOnClickListener(v -> playNextEpisodeNow());
        cochiPreviousButton.setOnClickListener(v -> playStoreItemRelative(-1));
        cochiNextButton.setOnClickListener(v -> playStoreItemRelative(+1));
        cochiSettingsButton.setOnClickListener(v -> showPlayerSettingsDialog());
        cochiNavOverlay.setVisibility(View.GONE);

        tvMode = getIntent().getBooleanExtra(EXTRA_TV_MODE, false);
        storeItemMode = getIntent().getBooleanExtra(EXTRA_STORE_ITEM, false);
        if (tvMode) {
            // En TV el zapping debe ser limpio: cambiar de canal no fuerza la aparición
            // de los controles centrales de Media3. El usuario todavía puede abrirlos
            // manualmente con OK/ENTER cuando realmente los necesite.
            playerView.setControllerAutoShow(false);
            playerView.hideController();
        }
        String sourceName = getIntent().getStringExtra(EXTRA_CATALOG_SOURCE);
        if (sourceName != null) {
            try { catalogSource = CatalogSource.valueOf(sourceName); } catch (Exception ignored) {}
        }

        forceStart = getIntent().getBooleanExtra(EXTRA_FORCE_START, false);
        autoResume = getIntent().getBooleanExtra(EXTRA_AUTO_RESUME, false);
        autoNextSeries = getIntent().getBooleanExtra(EXTRA_AUTO_NEXT_SERIES, false);

        // Sincronización exacta con la visibilidad del controlador de Media3.
        // Es especialmente importante para Películas/Series: los botones propios
        // ANTERIOR/SIGUIENTE deben desaparecer en el mismo instante que -10/Play/+10.
        playerView.setControllerVisibilityListener((PlayerView.ControllerVisibilityListener) visibility -> {
            if (visibility == View.VISIBLE) {
                uiHandler.post(this::syncCochiNavigationWithController);
            } else {
                if (cochiNavOverlay != null) cochiNavOverlay.setVisibility(View.GONE);
                if (cochiSettingsButton != null) cochiSettingsButton.setVisibility(View.GONE);
            }
        });

        // Conservamos un chequeo liviano como respaldo para variantes de Media3/TV
        // que animan el controlador antes de emitir el cambio final de visibilidad.
        uiHandler.removeCallbacks(navigationVisibilityTicker);
        if (!isTelevisionDevice() || (storeItemMode && !tvMode)) uiHandler.post(navigationVisibilityTicker);

        if (catalogSource == CatalogSource.SERIES) {
            uiHandler.removeCallbacks(seriesAccessTicker);
            uiHandler.postDelayed(seriesAccessTicker, 30_000L);
        }

        if (tvMode || storeItemMode) {
            currentChannelIndex = getIntent().getIntExtra(EXTRA_CHANNEL_INDEX, 0);
            if (shouldTrackProgress()) {
                Channel channel = ChannelStore.get(currentChannelIndex);
                ProgressManager.Entry progress = channel == null ? null
                        : ProgressManager.get(this, catalogSource, channel.id);
                if (forceStart) {
                    playChannelAt(currentChannelIndex, 0L);
                } else if (autoResume && progress != null && progress.positionMs >= 10_000L) {
                    playChannelAt(currentChannelIndex, progress.positionMs);
                } else if (progress != null && progress.positionMs >= 10_000L) {
                    showResumeDialog(progress);
                } else {
                    playChannelAt(currentChannelIndex, 0L);
                }
            } else {
                playChannelAt(currentChannelIndex, 0L);
            }
        } else {
            playLegacyIntent();
        }
    }

    private void validateSeriesAccessAsync(boolean showMessage, Runnable onAllowed) {
        if (catalogSource != CatalogSource.SERIES) {
            if (onAllowed != null) onAllowed.run();
            return;
        }
        if (seriesAccessDenied) return;

        // Las acciones de usuario (abrir/cambiar capítulo) no repiten una consulta
        // que el PANEL ya confirmó hace pocos segundos. El ticker periódico, en cambio,
        // sigue haciendo una validación REAL cada 30 s.
        if (onAllowed != null
                && SessionManager.wasAccessRecentlyValidated(RECENT_SERIES_ACCESS_WINDOW_MS)) {
            onAllowed.run();
            return;
        }

        if (seriesAccessCheckRunning) {
            // Si el ticker está validando justo cuando se pulsa siguiente/anterior,
            // no perdemos el OK: dejamos la última acción pendiente.
            if (onAllowed != null) pendingSeriesAccessAction = onAllowed;
            return;
        }

        seriesAccessCheckRunning = true;
        boolean userInitiated = showMessage || onAllowed != null;
        if (userInitiated) loading.setVisibility(View.VISIBLE);
        new Thread(() -> {
            Boolean allowed = null;
            Exception validationError = null;
            try {
                allowed = SessionManager.validateAccessBlocking(getApplicationContext());
            } catch (Exception error) {
                // Importante: timeout/microcorte != dispositivo bloqueado. Solo una
                // respuesta REAL del backend con allowed=false puede cerrar el player.
                validationError = error;
            }
            final Boolean finalAllowed = allowed;
            final Exception finalValidationError = validationError;
            runOnUiThread(() -> {
                seriesAccessCheckRunning = false;
                Runnable pending = pendingSeriesAccessAction;
                pendingSeriesAccessAction = null;

                if (finalAllowed == null) {
                    seriesAccessDenied = false;
                    if (userInitiated) loading.setVisibility(View.GONE);
                    Log.w("COCHI-ACCESS", "Validación temporalmente no disponible; se conserva la reproducción",
                            finalValidationError);
                    // Si el usuario pidió abrir/cambiar capítulo durante un microcorte,
                    // permitimos continuar con la sesión local vigente. El ticker volverá
                    // a comprobar el estado real a los 30 s.
                    if (SessionManager.isActivated(this) && !SessionManager.isExpired(this)) {
                        if (onAllowed != null) onAllowed.run();
                        if (pending != null && pending != onAllowed && !isFinishing()) pending.run();
                    } else if (showMessage || pending != null) {
                        Toast.makeText(this, "No se pudo validar el acceso. Reintentá en unos segundos.",
                                Toast.LENGTH_SHORT).show();
                    }
                    return;
                }

                if (!finalAllowed) {
                    seriesAccessDenied = true;
                    CatalogRepository.clearSeriesCache(this);
                    releaseCurrentPlayback();
                    loading.setVisibility(View.GONE);
                    if (showMessage || pending != null) {
                        Toast.makeText(this, "Dispositivo bloqueado o sin acceso", Toast.LENGTH_LONG).show();
                    }
                    finish();
                    return;
                }
                seriesAccessDenied = false;
                if (userInitiated) loading.setVisibility(View.GONE);
                if (onAllowed != null) onAllowed.run();
                if (pending != null && pending != onAllowed && !isFinishing()) pending.run();
            });
        }, "cochi-series-player-access").start();
    }

    private boolean playIntentSnapshotFallback() {
        String url = getIntent().getStringExtra(EXTRA_URL);
        if (url == null || url.trim().isEmpty()) return false;
        String type = getIntent().getStringExtra(EXTRA_STREAM_TYPE);
        String name = getIntent().getStringExtra(EXTRA_DISPLAY_NAME);
        String clearKey = getIntent().getStringExtra(EXTRA_CLEARKEY_MULTI);
        String headersJson = getIntent().getStringExtra(EXTRA_HEADERS_JSON);
        LinkedHashMap<String, String> headers = new LinkedHashMap<>();
        if (headersJson != null && !headersJson.trim().isEmpty()) {
            try {
                JSONObject h = new JSONObject(headersJson);
                java.util.Iterator<String> keys = h.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    String value = h.optString(key, "");
                    if (!key.trim().isEmpty() && !value.trim().isEmpty()) headers.put(key, value);
                }
            } catch (Exception ignored) { }
        }
        Channel snapshot = new Channel("tv-snapshot", 0,
                name == null ? "Canal" : name,
                type == null ? "auto" : type, url, false,
                clearKey == null ? "" : clearKey, headers);
        currentChannelIndex = 0;
        playChannel(snapshot);
        return true;
    }

    private void playLegacyIntent() {
        String url = getIntent().getStringExtra(EXTRA_URL);
        String clearKeyKid = getIntent().getStringExtra(EXTRA_CLEARKEY_KID);
        String clearKeyKey = getIntent().getStringExtra(EXTRA_CLEARKEY_KEY);
        String clearKeyMulti = getIntent().getStringExtra(EXTRA_CLEARKEY_MULTI);
        String streamType = getIntent().getStringExtra(EXTRA_STREAM_TYPE);
        String displayName = getIntent().getStringExtra(EXTRA_DISPLAY_NAME);
        String headersJson = getIntent().getStringExtra(EXTRA_HEADERS_JSON);

        if (url == null || url.trim().isEmpty()) {
            finish();
            return;
        }

        LinkedHashMap<String, String> directHeaders = new LinkedHashMap<>();
        if (headersJson != null && !headersJson.trim().isEmpty()) {
            try {
                JSONObject h = new JSONObject(headersJson);
                java.util.Iterator<String> keys = h.keys();
                while (keys.hasNext()) {
                    String key = keys.next();
                    String value = h.optString(key, "");
                    if (!key.trim().isEmpty() && !value.trim().isEmpty()) directHeaders.put(key, value);
                }
            } catch (Exception ignored) { }
        }

        Channel channel = new Channel(
                "direct-search", 0,
                displayName == null || displayName.trim().isEmpty() ? "Reproducción" : displayName.trim(),
                streamType == null || streamType.trim().isEmpty() ? "auto" : streamType.trim(), url,
                false,
                clearKeyMulti != null && !clearKeyMulti.trim().isEmpty()
                        ? clearKeyMulti
                        : (clearKeyKid != null && clearKeyKey != null
                            ? clearKeyKid + ":" + clearKeyKey
                            : ""),
                directHeaders);
        playChannel(channel);
    }

    private void playChannelAt(int index) {
        playChannelAt(index, 0L);
    }

    private void playChannelAt(int index, long resumePositionMs) {
        if (catalogSource == CatalogSource.SERIES) {
            final int requestedIndex = index;
            final long requestedResume = resumePositionMs;
            validateSeriesAccessAsync(true, () -> playChannelAtAuthorized(requestedIndex, requestedResume));
            return;
        }
        playChannelAtAuthorized(index, resumePositionMs);
    }

    private void playChannelAtAuthorized(int index, long resumePositionMs) {
        int size = ChannelStore.size();
        if (size == 0) {
            // v0.23.47: nunca expulsar al usuario a la grilla por una carrera de estado.
            // TvActivity manda una instantánea del canal tocado y podemos reproducirla
            // aunque Android haya reclamado/recreado el store global.
            if (playIntentSnapshotFallback()) return;
            Toast.makeText(this, "Canal temporalmente no disponible", Toast.LENGTH_SHORT).show();
            return;
        }

        if (index < 0) index = size - 1;
        if (index >= size) index = 0;
        currentChannelIndex = index;
        endHandledForCurrent = false;

        Channel channel = ChannelStore.get(index);
        if (channel == null) return;
        activeEpisodeMarkers = catalogSource == CatalogSource.SERIES
                ? SeriesStore.markersForEpisode(channel.id)
                : new SeriesStore.EpisodeMarkers(null, null, -1L);
        hideEpisodeActions();
        playChannel(channel, resumePositionMs);
    }

    private void playChannel(Channel channel) {
        playChannel(channel, 0L);
    }

    private void playChannel(Channel channel, long resumePositionMs) {
        if (channel != null && BackendClient.requiresPrivateMediaResolution(channel.url)) {
            resolveAndPlayPrivateMedia(channel, resumePositionMs);
            return;
        }
        if (channel != null && catalogSource == CatalogSource.TV2
                && channel.url != null && channel.url.startsWith("cochi://resolve/tv2/")) {
            resolveAndPlayTv2(channel, resumePositionMs);
            return;
        }
        boolean targetYoutube = "youtube".equalsIgnoreCase(channel.type)
                || PlayerRouter.engineFor(channel.url) == PlayerRouter.Engine.YOUTUBE;

        // Fast Zapping v0.23.58: Media3 -> Media3 conserva la instancia para no
        // recrear codecs, pero CANCELA inmediatamente la carga/red del canal anterior.
        // Así CH+/CH- nunca espera a que una conexión vieja agote su timeout.
        preparePlaybackSwitch(!targetYoutube);
        activeChannel = channel;
        showChannelInfo(channel);

        if (channel.hasClearKey()) {
            playMedia3ClearKey(channel, resumePositionMs);
        } else if (targetYoutube) {
            playYoutube(channel.url);
        } else {
            playMedia3(channel, resumePositionMs);
        }
    }

    private void resolveAndPlayPrivateMedia(Channel original, long resumePositionMs) {
        if (original == null || original.url == null || original.url.trim().isEmpty()) return;
        final int generation = ++privateMediaResolveGeneration;
        loading.setVisibility(View.VISIBLE);
        showChannelInfo(original);
        new Thread(() -> {
            try {
                String signedUrl = BackendClient.resolvePrivateMediaUrl(getApplicationContext(), original.url);
                uiHandler.post(() -> {
                    if (generation != privateMediaResolveGeneration || isFinishing() || isDestroyed()) return;
                    Channel playable = new Channel(
                            original.id, original.number, original.name, original.type, signedUrl,
                            original.adult, original.clearKeyPairs, original.headers,
                            original.category, original.logo, original.description, null);
                    playChannel(playable, resumePositionMs);
                });
            } catch (Exception e) {
                uiHandler.post(() -> {
                    if (generation != privateMediaResolveGeneration || isFinishing() || isDestroyed()) return;
                    loading.setVisibility(View.GONE);
                    Toast.makeText(PlayerActivity.this,
                            "Película temporalmente no disponible", Toast.LENGTH_SHORT).show();
                    Log.w("COCHI-PRIVATE-MEDIA", "No se pudo obtener URL temporal: " + e.getMessage());
                });
            }
        }, "cochi-private-media-resolve").start();
    }

    private void resolveAndPlayTv2(Channel placeholder, long resumePositionMs) {
        final String prefix = "cochi://resolve/tv2/";
        final String sourceId = placeholder.url.substring(prefix.length()).trim();
        final int generation = ++tv2ResolveGeneration;
        loading.setVisibility(View.VISIBLE);
        showChannelInfo(placeholder);
        new Thread(() -> {
            try {
                String json = BackendClient.downloadTv2ResolvedPlayback(getApplicationContext(), sourceId);
                Channel resolved = CatalogRepository.parseResolvedTv2Playback(json);
                uiHandler.post(() -> {
                    if (generation != tv2ResolveGeneration || isFinishing() || isDestroyed()) return;
                    // Conservamos nombre/número/categoría de la lista visible, pero la reproducción
                    // usa exclusivamente URL/headers/DRM resueltos en ese instante por el PANEL.
                    Channel playable = new Channel(
                            placeholder.id, placeholder.number, placeholder.name,
                            resolved.type, resolved.url, placeholder.adult,
                            resolved.clearKeyPairs, resolved.headers,
                            placeholder.category, placeholder.logo, placeholder.description,
                            resolved.sources);
                    playChannel(playable, resumePositionMs);
                });
            } catch (Exception e) {
                uiHandler.post(() -> {
                    if (generation != tv2ResolveGeneration || isFinishing() || isDestroyed()) return;
                    loading.setVisibility(View.GONE);
                    Toast.makeText(PlayerActivity.this, "Canal temporalmente no disponible", Toast.LENGTH_SHORT).show();
                    Log.w("COCHI-TV2-ID", "No se pudo resolver " + sourceId + ": " + e.getMessage());
                });
            }
        }, "cochi-tv2-resolve").start();
    }

    private void armStartupStatusWatchdog() {
        if (!tvMode || activeChannel == null) return;
        cancelStartupStatusWatchdog();
        final int generation = playbackGeneration;
        startupStatusWatchdog = () -> {
            startupStatusWatchdog = null;
            if (generation != playbackGeneration || activeChannelReachedReady
                    || isFinishing() || isDestroyed()) return;
            startupUnavailableShown = true;
            loading.setVisibility(View.GONE);
            Toast.makeText(PlayerActivity.this,
                    "Canal temporalmente no disponible", Toast.LENGTH_SHORT).show();
            Log.w("COCHI-NET", "El canal no alcanzó READY dentro del tiempo de arranque");
        };
        uiHandler.postDelayed(startupStatusWatchdog, TV_STARTUP_STATUS_MS);
    }

    private void cancelStartupStatusWatchdog() {
        if (startupStatusWatchdog != null) {
            uiHandler.removeCallbacks(startupStatusWatchdog);
            startupStatusWatchdog = null;
        }
    }

    private void preparePlaybackSwitch(boolean keepMedia3Player) {
        playbackGeneration++;
        cancelPlaybackRecoveryWatchdog();
        uiHandler.removeCallbacks(hideChannelInfo);
        uiHandler.removeCallbacks(progressTicker);
        uiHandler.removeCallbacks(markerTicker);
        uiHandler.removeCallbacks(navigationVisibilityTicker);
        uiHandler.removeCallbacks(fatalReconnectRunnable);
        fatalRetryCount = 0;
        reconnectResumePositionMs = 0L;
        recoveryOperationRunning = false;
        activeChannelReachedReady = false;
        startupUnavailableShown = false;
        cancelStartupStatusWatchdog();
        if (cochiNavOverlay != null) cochiNavOverlay.setVisibility(View.GONE);
        if (cochiSettingsButton != null) cochiSettingsButton.setVisibility(View.GONE);
        loading.setVisibility(View.VISIBLE);

        if (player != null) {
            if (keepMedia3Player) {
                // stop()+clearMediaItems() aborta manifiestos/segmentos pendientes del
                // canal anterior sin pagar el costo de reconstruir codecs/renderers.
                try {
                    player.stop();
                    player.clearMediaItems();
                } catch (Exception ignored) { }
            } else {
                playerView.setPlayer(null);
                player.release();
                player = null;
            }
        }
        if (youtubeWebView != null && youtubeWebView.getVisibility() == View.VISIBLE) {
            youtubeWebView.stopLoading();
            youtubeWebView.loadUrl("about:blank");
            youtubeWebView.clearHistory();
            youtubeWebView.onPause();
            youtubeWebView.setVisibility(View.GONE);
        }
    }

    private void playMedia3(Channel channel, long resumePositionMs) {
        youtubeWebView.setVisibility(View.GONE);
        playerView.setVisibility(View.VISIBLE);
        DefaultHttpDataSource.Factory httpFactory = buildHttpFactory(channel);
        DefaultMediaSourceFactory mediaSourceFactory = new DefaultMediaSourceFactory(httpFactory)
                .setLoadErrorHandlingPolicy(new DefaultLoadErrorHandlingPolicy(loadRetryCountForCurrentMode()));
        if (player == null) {
            player = buildStablePlayer(mediaSourceFactory);
            attachPlayerAndErrors();
        } else {
            playerView.setPlayer(player);
        }

        player.setMediaSource(mediaSourceFactory.createMediaSource(buildMediaItem(channel)));
        if (resumePositionMs > 0L) player.seekTo(resumePositionMs);
        player.prepare();
        player.play();
        armStartupStatusWatchdog();
        armPlaybackRecoveryWatchdog();
    }

    private void playMedia3ClearKey(Channel channel, long resumePositionMs) {
        youtubeWebView.setVisibility(View.GONE);
        // channel.url es final: la URL resuelta se propaga en una variable
        // local hasta la fabrica HTTP y el MediaItem. La resolucion corre en
        // el executor dedicado (red fuera del hilo principal) con tope de
        // espera; si falla o expira se conserva la URL original.
        String playUrl = channel.url;
        if (channel.isTemplate) {
            String resolved = resolveMotorPrivadoUrl(channel);
            if (resolved != null) playUrl = resolved;
        }
        playerView.setVisibility(View.VISIBLE);
        try {
            List<KeyPair> pairs = parseKeyPairs(channel.clearKeyPairs);
            lastDrmRequestDiagnostic = "Esperando KeyRequest de Android MediaDrm…";
            MediaDrmCallback drmCallback = buildDiagnosticClearKeyCallback(pairs);

            DefaultDrmSessionManager drmSessionManager = new DefaultDrmSessionManager.Builder()
                    .setPlayClearSamplesWithoutKeys(true)
                    .setMultiSession(true)
                    .setUuidAndExoMediaDrmProvider(C.CLEARKEY_UUID, FrameworkMediaDrm.DEFAULT_PROVIDER)
                    .build(drmCallback);
            DefaultMediaSourceFactory mediaSourceFactory = new DefaultMediaSourceFactory(
                    buildHttpFactory(channel, playUrl))
                    .setLoadErrorHandlingPolicy(new DefaultLoadErrorHandlingPolicy(loadRetryCountForCurrentMode()))
                    .setDrmSessionManagerProvider(mediaItem -> drmSessionManager);

            if (player == null) {
                player = buildStablePlayer(mediaSourceFactory);
                attachPlayerAndErrors();
            } else {
                playerView.setPlayer(player);
            }

            player.setMediaSource(mediaSourceFactory.createMediaSource(buildMediaItem(channel, playUrl)));
            if (resumePositionMs > 0L) player.seekTo(resumePositionMs);
            player.prepare();
            player.play();
            armStartupStatusWatchdog();
            armPlaybackRecoveryWatchdog();
        } catch (IllegalArgumentException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    /** Resuelve la URL con plantilla fuera del hilo principal. Devuelve null si falla. */
    private String resolveMotorPrivadoUrl(Channel channel) {
        try {
            Future<String> future = motorPrivadoExecutor.submit(() ->
                    MotorPrivado.resolveGeneratedVideoUrl(
                            probeUrlForChannel(channel),
                            channel.nameRedirect,
                            channel.codeRedirect,
                            channel.template));
            return future.get(20, TimeUnit.SECONDS);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * URL de prueba (probe) del canal: se deriva de la plantilla rellenando
     * {codigo}/{nombre}; si la plantilla arranca con {token} se antepone el
     * host de redirect generado. El redirect de chromecast.cvattv.com.ar exige
     * el sufijo SA_Live_dash_cenc (302); la plantilla de reproduccion usa
     * SA_Live_dash_enc sobre el edge. Igual que el flujo xtv: cada canal usa
     * su propia URL para que el token quede atado a su path.
     */
    private String probeUrlForChannel(Channel channel) {
        String template = channel.template == null ? "" : channel.template.trim();
        String filled = template
                .replace("{codigo}", channel.codeRedirect == null ? "" : channel.codeRedirect.trim())
                .replace("{nombre}", channel.nameRedirect == null ? "" : channel.nameRedirect.trim());
        if (filled.startsWith("{token}")) {
            String path = filled.substring("{token}".length());
            return "https://chromecast.cvattv.com.ar"
                    + path.replace("SA_Live_dash_enc", "SA_Live_dash_cenc");
        }
        return filled;
    }

    /**
     * Respeta type cuando el catálogo lo declara explícitamente. Esto permite
     * reproducir endpoints HLS/DASH cuya URL no termina en .m3u8/.mpd.
     * YouTube no entra por este camino y queda exactamente como estaba.
     */
    private MediaItem buildMediaItem(Channel channel) {
        return buildMediaItem(channel, channel.url);
    }

    private MediaItem buildMediaItem(Channel channel, String uri) {
        MediaItem.Builder builder = new MediaItem.Builder().setUri(uri);
        String type = channel.type == null ? "" : channel.type.trim().toLowerCase(Locale.ROOT);
        if ("hls".equals(type) || "m3u8".equals(type)) {
            builder.setMimeType(MimeTypes.APPLICATION_M3U8);
        } else if ("dash".equals(type) || "mpd".equals(type)) {
            builder.setMimeType(MimeTypes.APPLICATION_MPD);
        }
        return builder.build();
    }

    private DefaultHttpDataSource.Factory buildHttpFactory(Channel channel) {
        return buildHttpFactory(channel, channel == null ? "" : channel.url);
    }

    private DefaultHttpDataSource.Factory buildHttpFactory(Channel channel, String url) {
        Map<String, String> resolved = HeaderResolver.resolve(
                url,
                channel == null ? null : channel.headers);

        LinkedHashMap<String, String> requestProperties = new LinkedHashMap<>(resolved);
        String userAgent = removeIgnoreCase(requestProperties, "User-Agent");
        if (userAgent == null || userAgent.trim().isEmpty()) userAgent = "CO-CHI/" + BuildConfig.VERSION_NAME;

        // v0.23.58: los timeouts de TV acompañan al watchdog 2.5/5 s. Si un host
        // realmente está caído, preferimos reconectar o dejar zappear antes que congelar
        // la experiencia. Películas/Series conservan un margen algo mayor.
        int connectTimeoutMs = tvMode ? 2_500 : 7_000;
        int readTimeoutMs = tvMode ? 4_500 : 12_000;
        DefaultHttpDataSource.Factory factory = new DefaultHttpDataSource.Factory()
                .setConnectTimeoutMs(connectTimeoutMs)
                .setReadTimeoutMs(readTimeoutMs)
                .setAllowCrossProtocolRedirects(true)
                .setUserAgent(userAgent);

        if (!requestProperties.isEmpty()) {
            factory.setDefaultRequestProperties(requestProperties);
        }
        return factory;
    }

    private static String removeIgnoreCase(Map<String, String> map, String name) {
        String found = null;
        for (String key : new ArrayList<>(map.keySet())) {
            if (key.equalsIgnoreCase(name)) {
                found = map.remove(key);
                break;
            }
        }
        return found;
    }

    private int loadRetryCountForCurrentMode() {
        return tvMode ? TV_LOAD_RETRY_COUNT : VOD_LOAD_RETRY_COUNT;
    }

    private void cancelPlaybackRecoveryWatchdog() {
        if (fastRecoveryWatchdog != null) {
            uiHandler.removeCallbacks(fastRecoveryWatchdog);
            fastRecoveryWatchdog = null;
        }
        if (fullRecoveryWatchdog != null) {
            uiHandler.removeCallbacks(fullRecoveryWatchdog);
            fullRecoveryWatchdog = null;
        }
    }

    private boolean playbackNeedsRecovery() {
        if (player == null || isFinishing() || isDestroyed()) return false;
        int state = player.getPlaybackState();
        return state != Player.STATE_READY && state != Player.STATE_ENDED;
    }

    private long currentRecoveryPositionMs() {
        if (!shouldTrackProgress() || player == null) return 0L;
        try { return Math.max(0L, player.getCurrentPosition()); }
        catch (Exception ignored) { return 0L; }
    }

    private void armPlaybackRecoveryWatchdog() {
        if (player == null || activeChannel == null || isFinishing() || isDestroyed()
                || recoveryOperationRunning) return;
        // Si ya hay un ciclo activo no movemos el reloj: el segundo escalón queda
        // anclado a los 5 s originales aunque el reintento rápido vuelva a BUFFERING.
        if (fastRecoveryWatchdog != null || fullRecoveryWatchdog != null) return;
        final int generation = playbackGeneration;
        final long fastDelay = tvMode ? TV_FAST_RECOVERY_MS : VOD_FAST_RECOVERY_MS;
        final long fullDelay = tvMode ? TV_FULL_RECOVERY_MS : VOD_FULL_RECOVERY_MS;

        fastRecoveryWatchdog = () -> {
            fastRecoveryWatchdog = null;
            if (generation != playbackGeneration || !playbackNeedsRecovery() || recoveryOperationRunning) return;
            // El reintento rápido es solo para un canal que YA había reproducido y sufrió
            // un microcorte. En el arranque inicial no reiniciamos a los 1.8 s porque
            // señales válidas pueden necesitar 3-4 s para resolver manifiesto/primer segmento.
            if (!activeChannelReachedReady) return;
            recoveryOperationRunning = true;
            reconnectResumePositionMs = currentRecoveryPositionMs();
            try {
                Log.w("COCHI-NET", "Recuperación rápida: reiniciando carga a los " + fastDelay + " ms");
                player.stop();
                if (reconnectResumePositionMs > 0L) player.seekTo(reconnectResumePositionMs);
                player.prepare();
                player.play();
            } catch (Exception error) {
                Log.w("COCHI-NET", "Recuperación rápida falló", error);
            } finally {
                recoveryOperationRunning = false;
            }
        };

        fullRecoveryWatchdog = () -> {
            fullRecoveryWatchdog = null;
            if (generation != playbackGeneration || !playbackNeedsRecovery() || recoveryOperationRunning) return;
            recoveryOperationRunning = true;
            reconnectResumePositionMs = currentRecoveryPositionMs();
            Channel channel = activeChannel;
            try {
                Log.w("COCHI-NET", "Recuperación completa: reconstruyendo player a los " + fullDelay + " ms");
                playerView.setPlayer(null);
                if (player != null) player.release();
                player = null;
            } catch (Exception ignored) {
                player = null;
            } finally {
                recoveryOperationRunning = false;
            }

            if (channel == null || generation != playbackGeneration || isFinishing() || isDestroyed()) return;
            if (channel.hasClearKey()) {
                playMedia3ClearKey(channel, reconnectResumePositionMs);
            } else {
                playMedia3(channel, reconnectResumePositionMs);
            }
        };

        uiHandler.postDelayed(fastRecoveryWatchdog, fastDelay);
        uiHandler.postDelayed(fullRecoveryWatchdog, fullDelay);
    }

    private ExoPlayer buildStablePlayer(DefaultMediaSourceFactory mediaSourceFactory) {
        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(
                        BUFFER_MIN_MS,
                        BUFFER_MAX_MS,
                        BUFFER_PLAYBACK_MS,
                        BUFFER_AFTER_REBUFFER_MS)
                .setPrioritizeTimeOverSizeThresholds(true)
                .build();

        return new ExoPlayer.Builder(this)
                .setMediaSourceFactory(mediaSourceFactory)
                .setLoadControl(loadControl)
                .setSeekBackIncrementMs(SEEK_INCREMENT_MS)
                .setSeekForwardIncrementMs(SEEK_INCREMENT_MS)
                .build();
    }

    private void attachPlayerAndErrors() {
        playerView.setPlayer(player);
        if (tvMode) hideControllerAfterZap();
        installMinimalControllerHandlers();
        uiHandler.removeCallbacks(navigationVisibilityTicker);
        if (!isTelevisionDevice() || (storeItemMode && !tvMode)) uiHandler.post(navigationVisibilityTicker);
        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int playbackState) {
                loading.setVisibility(
                        playbackState == Player.STATE_BUFFERING && !startupUnavailableShown
                                ? View.VISIBLE : View.GONE);
                if (playbackState == Player.STATE_READY) {
                    activeChannelReachedReady = true;
                    startupUnavailableShown = false;
                    cancelStartupStatusWatchdog();
                    fatalRetryCount = 0;
                    reconnectResumePositionMs = 0L;
                    recoveryOperationRunning = false;
                    cancelPlaybackRecoveryWatchdog();
                    uiHandler.removeCallbacks(fatalReconnectRunnable);
                    uiHandler.removeCallbacks(progressTicker);
                    if (shouldTrackProgress()) uiHandler.postDelayed(progressTicker, 10_000L);
                    uiHandler.removeCallbacks(markerTicker);
                    if (catalogSource == CatalogSource.SERIES && !activeEpisodeMarkers.isEmpty()) {
                        uiHandler.post(markerTicker);
                    }
                    // PlayerControlView actualiza el estado de sus botones al recibir la timeline.
                    // Reaplicamos nuestra navegación de canal una vez que el stream está listo.
                    uiHandler.post(PlayerActivity.this::installMinimalControllerHandlers);
                } else if (playbackState == Player.STATE_BUFFERING) {
                    // También cubre un canal que estaba andando y se queda sin datos
                    // minutos después: 2.5 s -> reintento; 5 s -> player nuevo en TV.
                    armPlaybackRecoveryWatchdog();
                } else if (playbackState == Player.STATE_ENDED) {
                    cancelPlaybackRecoveryWatchdog();
                    handlePlaybackEnded();
                }
            }

            @Override
            public void onEvents(Player player, Player.Events events) {
                // El PlayerControlView puede recalcular el estado de anterior/siguiente
                // cuando cambia la timeline o los comandos disponibles. CO-CHI los
                // mantiene como navegación del catálogo activo.
                uiHandler.post(PlayerActivity.this::installMinimalControllerHandlers);
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                loading.setVisibility(View.VISIBLE);

                // v0.23.53: no mostramos una pantalla de "señal caída".
                // Cualquier error del reproductor se trata como una desconexión transitoria:
                // CO-CHI permanece dentro del canal y vuelve a preparar la misma fuente.
                if (player == null) return;

                if (shouldTrackProgress()) {
                    try { reconnectResumePositionMs = Math.max(0L, player.getCurrentPosition()); }
                    catch (Exception ignored) { reconnectResumePositionMs = 0L; }
                } else {
                    reconnectResumePositionMs = 0L;
                }

                long delay = FATAL_RECONNECT_DELAYS_MS[Math.min(
                        fatalRetryCount, FATAL_RECONNECT_DELAYS_MS.length - 1)];
                fatalRetryCount++;

                String safeCode = error == null || error.getErrorCodeName() == null
                        ? "PLAYBACK_ERROR"
                        : error.getErrorCodeName();
                String tag = isDrmError(error) ? DRM_TAG : "COCHI-NET";
                Log.w(tag, "Reconexion silenciosa #" + fatalRetryCount
                        + " en " + delay + " ms: " + safeCode);

                uiHandler.removeCallbacks(fatalReconnectRunnable);
                uiHandler.postDelayed(fatalReconnectRunnable, delay);
            }
        });
    }

    private static boolean isRecoverableIoError(PlaybackException error) {
        if (error == null) return false;
        // Media3 reserva la familia 2xxx para errores de entrada/salida (red/HTTP/archivo).
        // Los errores de parsing/decodificación/DRM quedan fuera para no entrar en bucles.
        return error.errorCode >= 2000 && error.errorCode < 3000;
    }

    private static boolean isDrmError(PlaybackException error) {
        if (error == null) return false;
        int code = error.errorCode;
        return code >= 6000 && code < 7000;
    }

    private String buildDrmDiagnosticMessage(PlaybackException error) {
        StringBuilder out = new StringBuilder();
        out.append("DRM ")
                .append(error == null ? "desconocido" : error.getErrorCodeName());
        if (error != null) out.append(" (").append(error.errorCode).append(")");

        Channel current = ChannelStore.get(currentChannelIndex);
        if (current != null && current.name != null && !current.name.trim().isEmpty()) {
            out.append(" · ").append(current.name);
        }

        Throwable cause = error == null ? null : error.getCause();
        int depth = 0;
        while (cause != null && depth < 6) {
            String detail = null;
            if (cause instanceof MediaDrm.MediaDrmStateException) {
                try {
                    detail = ((MediaDrm.MediaDrmStateException) cause).getDiagnosticInfo();
                } catch (Exception ignored) {}
            }
            if (detail == null || detail.trim().isEmpty()) {
                detail = cause.getMessage();
            }
            if (detail != null && !detail.trim().isEmpty()) {
                out.append("\n").append(cause.getClass().getSimpleName())
                        .append(": ").append(detail.trim());
            } else {
                out.append("\n").append(cause.getClass().getSimpleName());
            }
            cause = cause.getCause();
            depth++;
        }
        return out.toString();
    }

    /**
     * Controlador CO-CHI v0.23.4:
     * - Celular/tablet en TV1/TV2: anterior/siguiente cambia de canal; la barra DVR se arrastra táctilmente.
     * - Android TV/TV Box: ↑/↓ hace zapping cuando el controlador está oculto. Con OK se muestran
     *   controles y el foco puede llegar a la barra DVR; izquierda/derecha sobre la barra mueve 15 min.
     * - Retroceso/avance corto se mantiene en ±10 s cuando el stream es seekable.
     */
    private void installMinimalControllerHandlers() {
        if (playerView == null) return;

        View previous = playerView.findViewById(androidx.media3.ui.R.id.exo_prev);
        View next = playerView.findViewById(androidx.media3.ui.R.id.exo_next);
        View rewind = playerView.findViewById(androidx.media3.ui.R.id.exo_rew);
        if (rewind == null) rewind = playerView.findViewById(androidx.media3.ui.R.id.exo_rew_with_amount);
        View forward = playerView.findViewById(androidx.media3.ui.R.id.exo_ffwd);
        if (forward == null) forward = playerView.findViewById(androidx.media3.ui.R.id.exo_ffwd_with_amount);
        View settings = playerView.findViewById(androidx.media3.ui.R.id.exo_settings);
        View playPause = playerView.findViewById(androidx.media3.ui.R.id.exo_play_pause);
        View progress = playerView.findViewById(androidx.media3.ui.R.id.exo_progress);

        boolean canSeek = player != null && player.isCurrentMediaItemSeekable();
        boolean television = isTelevisionDevice();
        boolean canSwitchTvChannel = tvMode && ChannelStore.size() > 1;

        if (previous != null) {
            if (tvMode && television) {
                previous.setEnabled(canSeek);
                previous.setAlpha(canSeek ? 1f : 0.35f);
                previous.setContentDescription("Retroceder 15 minutos");
                previous.setOnClickListener(v -> seekByLarge(-LARGE_SEEK_INCREMENT_MS));
            } else if (tvMode) {
                previous.setEnabled(canSwitchTvChannel);
                previous.setAlpha(canSwitchTvChannel ? 1f : 0.35f);
                previous.setContentDescription("Canal anterior");
                previous.setOnClickListener(v -> { if (canSwitchTvChannel) zap(-1); });
            } else {
                // Películas/Series usan botones propios superpuestos. Media3 vuelve a
                // deshabilitar exo_prev porque el reproductor tiene un solo MediaItem,
                // por eso ocultamos el botón estándar en vez de pelear con su estado.
                previous.setVisibility(View.INVISIBLE);
                previous.setEnabled(false);
            }
        }

        if (next != null) {
            if (tvMode && television) {
                next.setEnabled(canSeek);
                next.setAlpha(canSeek ? 1f : 0.35f);
                next.setContentDescription("Avanzar 15 minutos");
                next.setOnClickListener(v -> seekByLarge(LARGE_SEEK_INCREMENT_MS));
            } else if (tvMode) {
                next.setEnabled(canSwitchTvChannel);
                next.setAlpha(canSwitchTvChannel ? 1f : 0.35f);
                next.setContentDescription("Canal siguiente");
                next.setOnClickListener(v -> { if (canSwitchTvChannel) zap(+1); });
            } else {
                // Igual que exo_prev: el botón estándar queda fuera y usamos el
                // botón CO-CHI, que Media3 no conoce ni puede deshabilitar.
                next.setVisibility(View.INVISIBLE);
                next.setEnabled(false);
            }
        }

        if (rewind != null) rewind.setOnClickListener(v -> seekBackTenSeconds());
        if (forward != null) forward.setOnClickListener(v -> seekForwardTenSeconds());
        if (settings != null) {
            if (television) {
                settings.setEnabled(true);
                settings.setClickable(true);
                settings.setAlpha(1f);
                settings.setVisibility(View.VISIBLE);
                settings.setOnClickListener(v -> showPlayerSettingsDialog());
            } else {
                // En móvil ocultamos el engranaje interno de Media3: puede verse gris y
                // quedar sin área táctil. El botón cochiSettingsButton lo reemplaza.
                settings.setVisibility(View.INVISIBLE);
                settings.setEnabled(false);
                settings.setClickable(false);
            }
        }

        // Android TV / TV Box: integrar los botones propios CO-CHI en la cadena de foco
        // horizontal del mando, sin cambiar absolutamente nada del comportamiento táctil.
        // Orden: ANTERIOR -> -10 -> PLAY/PAUSA -> +10 -> SIGUIENTE.
        // Indicador visual de foco exclusivo para Android TV/TV Box.
        // No cambia la navegación ni el comportamiento táctil: solo dibuja
        // un contorno azul/cian alrededor del control seleccionado.
        if (television) {
            applyTvFocusIndicator(previous);
            applyTvFocusIndicator(rewind);
            applyTvFocusIndicator(playPause);
            applyTvFocusIndicator(forward);
            applyTvFocusIndicator(next);
            applyTvFocusIndicator(settings);
            if (storeItemMode && !tvMode) {
                applyTvFocusIndicator(cochiPreviousButton);
                applyTvFocusIndicator(cochiNextButton);
            }
        }

        if (television && storeItemMode && !tvMode
                && cochiPreviousButton != null && cochiNextButton != null) {
            cochiPreviousButton.setFocusable(true);
            cochiPreviousButton.setFocusableInTouchMode(false);
            cochiNextButton.setFocusable(true);
            cochiNextButton.setFocusableInTouchMode(false);

            if (rewind != null) {
                cochiPreviousButton.setNextFocusRightId(rewind.getId());
                rewind.setNextFocusLeftId(cochiPreviousButton.getId());
            }
            if (rewind != null && playPause != null) {
                rewind.setNextFocusRightId(playPause.getId());
                playPause.setNextFocusLeftId(rewind.getId());
            }
            if (playPause != null && forward != null) {
                playPause.setNextFocusRightId(forward.getId());
                forward.setNextFocusLeftId(playPause.getId());
            }
            if (forward != null) {
                forward.setNextFocusRightId(cochiNextButton.getId());
                cochiNextButton.setNextFocusLeftId(forward.getId());
            }
        }

        // Barra de tiempo:
        // - Películas/Series en Android TV: siempre vuelve a formar parte de la navegación por foco.
        // - TV en vivo: solo recibe foco cuando el stream permite seek/DVR.
        // El cambio de v0.23.12 es deliberadamente SOLO de navegación con mando.
        if (progress != null) {
            boolean storeTimelineFocusable = television && storeItemMode && !tvMode;
            boolean liveTimelineFocusable = television && tvMode && canSeek;
            progress.setFocusable(storeTimelineFocusable || liveTimelineFocusable);
            progress.setFocusableInTouchMode(false);
            progress.setEnabled(!tvMode || canSeek);
            progress.setAlpha(!tvMode || canSeek ? 1f : 0.45f);

            if (storeTimelineFocusable) {
                progress.setContentDescription("Barra de progreso. Izquierda y derecha desplazan la reproducción");

                // Reincorporar explícitamente la barra a la ruta vertical de los controles CO-CHI.
                // Desde cualquiera de los cinco controles principales, DPAD_UP llega a la barra;
                // DPAD_DOWN desde la barra baja a Ajustes; DPAD_UP desde Ajustes vuelve a la barra.
                int progressId = progress.getId();
                if (cochiPreviousButton != null) cochiPreviousButton.setNextFocusUpId(progressId);
                if (rewind != null) rewind.setNextFocusUpId(progressId);
                if (playPause != null) playPause.setNextFocusUpId(progressId);
                if (forward != null) forward.setNextFocusUpId(progressId);
                if (cochiNextButton != null) cochiNextButton.setNextFocusUpId(progressId);
                if (settings != null) {
                    progress.setNextFocusDownId(settings.getId());
                    settings.setNextFocusUpId(progressId);
                } else if (playPause != null) {
                    // Respaldo por si una variante de Media3 no expone Ajustes.
                    progress.setNextFocusDownId(playPause.getId());
                }
            } else {
                progress.setContentDescription(canSeek
                        ? "Barra DVR. Izquierda y derecha mueven 15 minutos"
                        : "Canal en vivo sin DVR");
            }

            if (progress instanceof DefaultTimeBar && tvMode) {
                ((DefaultTimeBar) progress).setKeyTimeIncrement(LARGE_SEEK_INCREMENT_MS);
            }
        }
    }

    private void applyTvFocusIndicator(View view) {
        if (view == null) return;
        // v0.23.14: el foco se dibuja como FOREGROUND y no como background.
        // Media3 usa el background de los botones -10/+10 para dibujar su icono;
        // reemplazarlo hacía desaparecer la flecha circular y el número 10 al enfocar.
        // El foreground conserva intacto el icono original y añade solo el contorno neón.
        view.setForeground(getDrawable(R.drawable.cochi_player_focus));
    }

    private void showCochiNavigationOverlay() {
        if (cochiNavOverlay == null || tvMode || !storeItemMode) return;
        cochiNavOverlay.setVisibility(View.VISIBLE);
        cochiNavOverlay.bringToFront();

        boolean hasPrevious = currentChannelIndex > 0 && ChannelStore.size() > 0;
        boolean hasNext = currentChannelIndex >= 0 && currentChannelIndex + 1 < ChannelStore.size();
        boolean movies = catalogSource == CatalogSource.MOVIES;

        cochiPreviousButton.setEnabled(hasPrevious);
        cochiPreviousButton.setClickable(hasPrevious);
        cochiPreviousButton.setAlpha(hasPrevious ? 1f : 0.32f);
        cochiPreviousButton.setVisibility(View.VISIBLE);
        cochiPreviousButton.setContentDescription(catalogSource == CatalogSource.SERIES
                ? "Capítulo anterior" : movies ? "Película anterior" : "Contenido anterior");

        cochiNextButton.setEnabled(hasNext);
        cochiNextButton.setClickable(hasNext);
        cochiNextButton.setAlpha(hasNext ? 1f : 0.32f);
        cochiNextButton.setVisibility(View.VISIBLE);
        cochiNextButton.setContentDescription(catalogSource == CatalogSource.SERIES
                ? "Capítulo siguiente" : movies ? "Película siguiente" : "Contenido siguiente");
    }

    private void syncCochiNavigationWithController() {
        if (playerView == null) return;

        boolean controllerVisible = playerView.isControllerFullyVisible();

        // v0.23.29: en celular usamos un engranaje CO-CHI independiente del exo_settings.
        // Así Media3 no puede dejarlo gris/deshabilitado y, al estar dentro del root de la
        // Activity con margen respecto de la barra de navegación, Android no intercepta el toque.
        if (cochiSettingsButton != null) {
            if (!isTelevisionDevice() && controllerVisible) {
                cochiSettingsButton.setVisibility(View.VISIBLE);
                cochiSettingsButton.setEnabled(true);
                cochiSettingsButton.setClickable(true);
                cochiSettingsButton.setAlpha(1f);
                cochiSettingsButton.bringToFront();
            } else {
                cochiSettingsButton.setVisibility(View.GONE);
            }
        }

        if (cochiNavOverlay == null || tvMode || !storeItemMode) {
            if (cochiNavOverlay != null) cochiNavOverlay.setVisibility(View.GONE);
            return;
        }

        // Los botones CO-CHI siguen exactamente la visibilidad real del controlador
        // de Media3: aparecen con -10/Play/+10 y desaparecen cuando esa botonera se oculta.
        if (controllerVisible) {
            showCochiNavigationOverlay();
            // El overlay de navegación ocupa toda la pantalla; el engranaje debe quedar arriba.
            if (cochiSettingsButton != null && cochiSettingsButton.getVisibility() == View.VISIBLE)
                cochiSettingsButton.bringToFront();
        } else {
            cochiNavOverlay.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        boolean handled = super.dispatchTouchEvent(event);
        if (event != null && event.getActionMasked() == MotionEvent.ACTION_DOWN
                && storeItemMode && !tvMode) {
            // Media3 procesa primero el toque. Un instante después copiamos su estado
            // real para que nuestros extremos aparezcan/oculten junto con la botonera.
            uiHandler.postDelayed(this::syncCochiNavigationWithController, 80L);
        }
        return handled;
    }

    private boolean isTelevisionDevice() {
        UiModeManager ui = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        return (ui != null && ui.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION)
                || getPackageManager().hasSystemFeature("android.software.leanback")
                || getPackageManager().hasSystemFeature("android.hardware.type.television");
    }

    private void seekBackTenSeconds() {
        if (player == null) return;
        if (!player.isCurrentMediaItemSeekable()) {
            Toast.makeText(this, "Este contenido no permite retroceder", Toast.LENGTH_SHORT).show();
            return;
        }
        player.seekBack();
    }

    private void seekForwardTenSeconds() {
        if (player == null) return;
        if (!player.isCurrentMediaItemSeekable()) {
            Toast.makeText(this, "Este contenido no permite avanzar", Toast.LENGTH_SHORT).show();
            return;
        }
        player.seekForward();
    }

    private void seekByLarge(long deltaMs) {
        if (player == null) return;
        if (!player.isCurrentMediaItemSeekable()) {
            Toast.makeText(this, "Este canal no permite desplazamiento DVR", Toast.LENGTH_SHORT).show();
            return;
        }

        long current = Math.max(0L, player.getCurrentPosition());
        long duration = player.getDuration();
        long target = current + deltaMs;

        if (deltaMs < 0L) {
            target = Math.max(0L, target);
            player.seekTo(target);
        } else if (duration != C.TIME_UNSET && duration > 0L) {
            if (target >= duration - 1_500L && player.isCurrentMediaItemLive()) {
                player.seekToDefaultPosition();
                player.play();
                Toast.makeText(this, "EN VIVO", Toast.LENGTH_SHORT).show();
                return;
            }
            player.seekTo(Math.min(target, duration));
        } else {
            player.seekTo(Math.max(0L, target));
        }

        Toast.makeText(this,
                deltaMs < 0L ? "−15 min" : "+15 min",
                Toast.LENGTH_SHORT).show();
    }

    private void returnToLive() {
        if (player == null || !player.isCurrentMediaItemLive()) return;
        player.seekToDefaultPosition();
        player.play();
        Toast.makeText(this, "EN VIVO", Toast.LENGTH_SHORT).show();
    }

    private void updateEpisodeActions() {
        if (player == null || catalogSource != CatalogSource.SERIES || activeEpisodeMarkers.isEmpty()) {
            hideEpisodeActions();
            return;
        }
        long position = Math.max(0L, player.getCurrentPosition());
        boolean recapVisible = inMarkerRange(position, activeEpisodeMarkers.recap);
        boolean introVisible = inMarkerRange(position, activeEpisodeMarkers.intro);
        boolean hasNext = currentChannelIndex + 1 < ChannelStore.size();
        boolean nextVisible = hasNext
                && activeEpisodeMarkers.nextEpisodeAtMs >= 0L
                && position >= activeEpisodeMarkers.nextEpisodeAtMs;

        skipRecapButton.setVisibility(recapVisible ? View.VISIBLE : View.GONE);
        skipIntroButton.setVisibility(introVisible ? View.VISIBLE : View.GONE);
        nextEpisodeButton.setVisibility(nextVisible ? View.VISIBLE : View.GONE);
        episodeActions.setVisibility(recapVisible || introVisible || nextVisible ? View.VISIBLE : View.GONE);
    }

    private static boolean inMarkerRange(long positionMs, SeriesStore.MarkerRange range) {
        return range != null && range.isValid()
                && positionMs >= range.startMs && positionMs < range.endMs;
    }

    private void skipMarker(SeriesStore.MarkerRange range, String message) {
        if (player == null || range == null || !range.isValid()) return;
        if (!player.isCurrentMediaItemSeekable()) {
            Toast.makeText(this, "Este contenido no permite saltar", Toast.LENGTH_SHORT).show();
            return;
        }
        player.seekTo(range.endMs);
        player.play();
        updateEpisodeActions();
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void playNextEpisodeNow() {
        if (currentChannelIndex + 1 >= ChannelStore.size()) {
            Toast.makeText(this, "No hay otro episodio", Toast.LENGTH_SHORT).show();
            return;
        }
        saveProgressNow();
        Channel current = ChannelStore.get(currentChannelIndex);
        if (current != null) {
            ProgressManager.remove(this, CatalogSource.SERIES, current.id);
            ProgressManager.markWatched(this, CatalogSource.SERIES, current.id);
        }
        playChannelAt(currentChannelIndex + 1, 0L);
    }

    private void hideEpisodeActions() {
        if (episodeActions != null) episodeActions.setVisibility(View.GONE);
        if (skipRecapButton != null) skipRecapButton.setVisibility(View.GONE);
        if (skipIntroButton != null) skipIntroButton.setVisibility(View.GONE);
        if (nextEpisodeButton != null) nextEpisodeButton.setVisibility(View.GONE);
    }

    private void showPlayerSettingsDialog() {
        if (player == null) {
            Toast.makeText(this, "Ajustes disponibles durante la reproducción", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean showLive = tvMode
                && player.isCurrentMediaItemLive()
                && player.isCurrentMediaItemSeekable();
        String[] options = showLive
                ? new String[] {"Volver a EN VIVO", "Calidad", "Audio", "Subtítulos"}
                : new String[] {"Calidad", "Audio", "Subtítulos"};

        new AlertDialog.Builder(this)
                .setTitle("Ajustes")
                .setItems(options, (dialog, which) -> {
                    if (showLive) {
                        if (which == 0) {
                            returnToLive();
                        } else if (which == 1) {
                            showTrackDialog("Calidad", C.TRACK_TYPE_VIDEO);
                        } else if (which == 2) {
                            showTrackDialog("Audio", C.TRACK_TYPE_AUDIO);
                        } else {
                            showSubtitleDialog();
                        }
                    } else if (which == 0) {
                        showTrackDialog("Calidad", C.TRACK_TYPE_VIDEO);
                    } else if (which == 1) {
                        showTrackDialog("Audio", C.TRACK_TYPE_AUDIO);
                    } else {
                        showSubtitleDialog();
                    }
                })
                .show();
    }

    private void showSubtitleDialog() {
        if (player == null) return;

        if (!hasTrackType(C.TRACK_TYPE_TEXT)) {
            new AlertDialog.Builder(this)
                    .setTitle("Subtítulos")
                    .setMessage("Subtítulos no disponibles para este contenido")
                    .setPositiveButton("Aceptar", null)
                    .show();
            return;
        }

        new TrackSelectionDialogBuilder(this, "Subtítulos", player, C.TRACK_TYPE_TEXT)
                .setAllowAdaptiveSelections(false)
                .setShowDisableOption(true)
                .build()
                .show();
    }

    private boolean hasTrackType(@C.TrackType int trackType) {
        if (player == null) return false;
        for (androidx.media3.common.Tracks.Group group : player.getCurrentTracks().getGroups()) {
            if (group.getType() == trackType && group.length > 0) return true;
        }
        return false;
    }

    private void showTrackDialog(String title, @C.TrackType int trackType) {
        if (player == null) return;
        new TrackSelectionDialogBuilder(this, title, player, trackType)
                .setAllowAdaptiveSelections(false)
                .setShowDisableOption(false)
                .build()
                .show();
    }

    private void handlePlaybackEnded() {
        if (endHandledForCurrent) return;
        endHandledForCurrent = true;
        uiHandler.removeCallbacks(progressTicker);
        uiHandler.removeCallbacks(markerTicker);
        hideEpisodeActions();

        Channel current = ChannelStore.get(currentChannelIndex);
        if (shouldTrackProgress() && current != null) {
            ProgressManager.remove(this, catalogSource, current.id);
            ProgressManager.markWatched(this, catalogSource, current.id);
        }

        if (autoNextSeries
                && catalogSource == CatalogSource.SERIES
                && currentChannelIndex + 1 < ChannelStore.size()) {
            Channel next = ChannelStore.get(currentChannelIndex + 1);
            Toast.makeText(this,
                    next == null ? "Siguiente capítulo" : "Siguiente: " + next.name,
                    Toast.LENGTH_SHORT).show();
            uiHandler.postDelayed(() -> playChannelAt(currentChannelIndex + 1, 0L), 1200L);
        } else if (autoNextSeries && catalogSource == CatalogSource.SERIES) {
            Toast.makeText(this, "Terminaste la serie ✓", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (tvMode
                && event.getAction() == KeyEvent.ACTION_DOWN
                && event.getRepeatCount() == 0) {
            int code = event.getKeyCode();
            boolean controllerVisible = playerView != null && playerView.isControllerFullyVisible();
            // CHANNEL_UP/DOWN siempre hace zapping. DPAD ↑/↓ solo zapea con controles ocultos;
            // cuando el controlador está abierto se deja navegar hasta la barra DVR.
            if (code == KeyEvent.KEYCODE_CHANNEL_UP
                    || (code == KeyEvent.KEYCODE_DPAD_UP && !controllerVisible)) {
                zap(+1);
                return true;
            }
            if (code == KeyEvent.KEYCODE_CHANNEL_DOWN
                    || (code == KeyEvent.KEYCODE_DPAD_DOWN && !controllerVisible)) {
                zap(-1);
                return true;
            }
            if (code == KeyEvent.KEYCODE_INFO) {
                Channel channel = ChannelStore.get(currentChannelIndex);
                if (channel != null) showChannelInfo(channel);
                return true;
            }
            if (code == KeyEvent.KEYCODE_MENU) {
                showPlayerSettingsDialog();
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }


    private void playStoreItemRelative(int delta) {
        if (!storeItemMode || tvMode) return;
        int target = currentChannelIndex + delta;
        if (target < 0 || target >= ChannelStore.size()) {
            String kind = catalogSource == CatalogSource.SERIES ? "capítulo"
                    : catalogSource == CatalogSource.MOVIES ? "película" : "contenido";
            Toast.makeText(this, delta < 0
                    ? "No hay " + kind + " anterior"
                    : "No hay " + kind + " siguiente", Toast.LENGTH_SHORT).show();
            installMinimalControllerHandlers();
            syncCochiNavigationWithController();
            return;
        }
        saveProgressNow();
        playChannelAt(target, 0L);
        uiHandler.post(() -> {
            installMinimalControllerHandlers();
            syncCochiNavigationWithController();
        });
    }

    private void zap(int delta) {
        saveProgressNow();
        int size = ChannelStore.size();
        if (size < 2) {
            Channel channel = ChannelStore.get(currentChannelIndex);
            if (channel != null) showChannelInfo(channel);
            hideControllerAfterZap();
            return;
        }

        // Ocultamos antes y después del cambio. PlayerView puede intentar mostrar
        // el controlador cuando recibe un Player nuevo, por eso reforzamos el ocultado
        // durante los primeros milisegundos del zapping.
        hideControllerAfterZap();
        playChannelAt(currentChannelIndex + delta);
        hideControllerAfterZap();
    }

    private void hideControllerAfterZap() {
        if (!tvMode || playerView == null) return;
        playerView.hideController();
        uiHandler.post(playerView::hideController);
        uiHandler.postDelayed(playerView::hideController, 120L);
        uiHandler.postDelayed(playerView::hideController, 350L);
    }

    private boolean shouldTrackProgress() {
        return storeItemMode
                && catalogSource != null
                && (catalogSource == CatalogSource.MOVIES || catalogSource == CatalogSource.SERIES);
    }

    private void showResumeDialog(ProgressManager.Entry progress) {
        new AlertDialog.Builder(this)
                .setTitle(progress.name)
                .setMessage("¿Querés continuar desde " + formatPosition(progress.positionMs) + "?")
                .setNegativeButton("Desde el inicio", (d, which) -> {
                    ProgressManager.remove(this, catalogSource, progress.itemId);
                    playChannelAt(currentChannelIndex, 0L);
                })
                .setPositiveButton("Continuar", (d, which) ->
                        playChannelAt(currentChannelIndex, progress.positionMs))
                .setOnCancelListener(d -> finish())
                .show();
    }

    private static String formatPosition(long positionMs) {
        long totalSeconds = Math.max(0L, positionMs / 1000L);
        long hours = totalSeconds / 3600L;
        long minutes = (totalSeconds % 3600L) / 60L;
        long seconds = totalSeconds % 60L;
        if (hours > 0) return String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds);
        return String.format(Locale.US, "%d:%02d", minutes, seconds);
    }

    private void saveProgressNow() {
        if (!shouldTrackProgress() || player == null) return;
        Channel channel = ChannelStore.get(currentChannelIndex);
        if (channel == null) return;
        long duration = player.getDuration();
        long position = player.getCurrentPosition();
        if (duration <= 0L || duration == C.TIME_UNSET) return;
        ProgressManager.save(this, catalogSource, channel, position, duration);
    }

    private void showChannelInfo(Channel channel) {
        if (channel == null) return;
        channelNumber.setText(String.format(Locale.US, "%03d", channel.number));
        channelName.setText(channel.name);
        channelInfo.setVisibility(View.VISIBLE);
        uiHandler.removeCallbacks(hideChannelInfo);
        uiHandler.postDelayed(hideChannelInfo, 2_700);
    }

    /**
     * Diagnóstico ClearKey v0.22.14.
     *
     * Android MediaDrm genera un KeyRequest con el/los KID que realmente necesita
     * el MPD. En vez de asumir a ciegas el orden del par recibido desde BA2, esta
     * envoltura observa ese pedido y compara el KID solicitado contra ambos lados
     * del par. Si coincide con el segundo valor, arma la respuesta invirtiendo
     * KID/KEY únicamente para esa sesión. No cambia la URI ni los headers de BA2.
     */
    private MediaDrmCallback buildDiagnosticClearKeyCallback(List<KeyPair> sourcePairs) {
        final List<KeyPair> originalPairs = new ArrayList<>(sourcePairs);
        final LocalMediaDrmCallback provisionDelegate = new LocalMediaDrmCallback(
                buildClearKeyResponse(originalPairs).getBytes(StandardCharsets.UTF_8));

        return new MediaDrmCallback() {
            @Override
            public MediaDrmCallback.Response executeKeyRequest(
                    UUID uuid, ExoMediaDrm.KeyRequest request) throws MediaDrmCallbackException {
                String requestText = "";
                if (request != null && request.getData() != null) {
                    requestText = new String(request.getData(), StandardCharsets.UTF_8);
                }

                List<String> requestedKids = parseRequestedKidsFromRequest(requestText);
                OrientationResult orientation = orientPairsForRequestedKids(
                        originalPairs, requestedKids);
                String responseJson = buildClearKeyResponse(orientation.pairs);

                // Diagnóstico sanitizado: no guardar ni imprimir KID, KEY ni contenido
                // del KeyRequest. Conservamos solo estado técnico no sensible.
                StringBuilder diagnostic = new StringBuilder();
                diagnostic.append("KeyRequest recibido: sí");
                diagnostic.append("; kids detectados: ").append(requestedKids.size());
                diagnostic.append("; coincidencia BA2: ")
                        .append(orientation.matched ? "sí" : "no");
                diagnostic.append("; orientación: ")
                        .append(orientation.swapped ? "invertida" : "normal");
                lastDrmRequestDiagnostic = diagnostic.toString();
                Log.d(DRM_TAG, lastDrmRequestDiagnostic);

                LocalMediaDrmCallback keyDelegate = new LocalMediaDrmCallback(
                        responseJson.getBytes(StandardCharsets.UTF_8));
                return keyDelegate.executeKeyRequest(uuid, request);
            }

            @Override
            public MediaDrmCallback.Response executeProvisionRequest(
                    UUID uuid, ExoMediaDrm.ProvisionRequest request) throws MediaDrmCallbackException {
                return provisionDelegate.executeProvisionRequest(uuid, request);
            }
        };
    }

    private static List<String> parseRequestedKidsFromRequest(String requestText) {
        List<String> kids = new ArrayList<>();
        if (requestText == null || requestText.trim().isEmpty()) return kids;
        try {
            JSONObject root = new JSONObject(requestText);
            JSONArray array = root.optJSONArray("kids");
            if (array == null) return kids;
            for (int i = 0; i < array.length(); i++) {
                String normalized = normalize128(array.optString(i, ""));
                if (isHex128(normalized) && !containsIgnoreCase(kids, normalized)) {
                    kids.add(normalized);
                }
            }
        } catch (Exception ignored) {
            // El texto crudo igualmente queda visible en el diagnóstico.
        }
        return kids;
    }

    private static OrientationResult orientPairsForRequestedKids(
            List<KeyPair> originalPairs, List<String> requestedKids) {
        if (requestedKids == null || requestedKids.isEmpty()) {
            return new OrientationResult(new ArrayList<>(originalPairs), false, false);
        }

        List<KeyPair> selected = new ArrayList<>();
        boolean swapped = false;
        boolean matched = false;

        for (String requestedKid : requestedKids) {
            KeyPair normal = null;
            KeyPair reversed = null;
            for (KeyPair pair : originalPairs) {
                if (pair.kidHex.equalsIgnoreCase(requestedKid)) {
                    normal = pair;
                    break;
                }
                if (pair.keyHex.equalsIgnoreCase(requestedKid)) {
                    reversed = pair;
                }
            }

            if (normal != null) {
                addUniqueKeyPair(selected, normal.kidHex, normal.keyHex);
                matched = true;
            } else if (reversed != null) {
                addUniqueKeyPair(selected, reversed.keyHex, reversed.kidHex);
                swapped = true;
                matched = true;
            }
        }

        if (selected.isEmpty()) {
            selected.addAll(originalPairs);
        }
        return new OrientationResult(selected, swapped, matched);
    }

    private static boolean containsIgnoreCase(List<String> values, String target) {
        for (String value : values) {
            if (value.equalsIgnoreCase(target)) return true;
        }
        return false;
    }

    private static String joinValues(List<String> values) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < values.size(); i++) {
            if (i > 0) out.append(", ");
            out.append(values.get(i));
        }
        return out.toString();
    }

    private static String shortText(String value, int max) {
        if (value == null) return "";
        String oneLine = value.replace('\n', ' ').replace('\r', ' ').trim();
        return oneLine.length() <= max ? oneLine : oneLine.substring(0, max) + "…";
    }

    private static String buildClearKeyResponse(List<KeyPair> pairs) {
        StringBuilder json = new StringBuilder("{\"keys\":[");
        for (int i = 0; i < pairs.size(); i++) {
            KeyPair pair = pairs.get(i);
            if (i > 0) json.append(',');

            String kidB64 = Base64.encodeToString(
                    hexToBytes(pair.kidHex), Base64.URL_SAFE | Base64.NO_PADDING | Base64.NO_WRAP);
            String keyB64 = Base64.encodeToString(
                    hexToBytes(pair.keyHex), Base64.URL_SAFE | Base64.NO_PADDING | Base64.NO_WRAP);

            json.append("{\"kty\":\"oct\",\"kid\":\"")
                    .append(kidB64)
                    .append("\",\"k\":\"")
                    .append(keyB64)
                    .append("\"}");
        }
        json.append("],\"type\":\"temporary\"}");
        return json.toString();
    }

    private static List<KeyPair> parseKeyPairs(String text) {
        String normalized = text == null ? "" : text.trim();
        if (normalized.isEmpty()) {
            throw new IllegalArgumentException("Faltan claves ClearKey");
        }

        String[] entries = normalized.split("[\\r\\n,;]+");
        List<KeyPair> result = new ArrayList<>();

        for (String raw : entries) {
            String entry = raw.trim();
            if (entry.isEmpty()) continue;

            // El separador principal es ':' porque Base64 puede contener '=' como padding.
            // Convención Max: Max:KEY_HEX:KID_HEX; los dos últimos campos se toman y se invierten.
            String[] parts = entry.split("\\s*:\\s*");
            if (parts.length < 2) {
                // Compatibilidad adicional con pares HEX antiguos KID|KEY o KID=KEY.
                parts = entry.split("\\s*[|=]\\s*", 2);
            }
            if (parts.length < 2) {
                throw new IllegalArgumentException("Formato ClearKey inválido");
            }

            boolean maxFormat = parts.length >= 3
                    && "max".equalsIgnoreCase(parts[0].trim());

            String first = normalize128(parts[parts.length - 2]);
            String second = normalize128(parts[parts.length - 1]);
            if (!isHex128(first) || !isHex128(second)) {
                throw new IllegalArgumentException("KID/KEY inválido");
            }

            // Formatos aceptados:
            //   KID_BASE64:KEY_BASE64 -> orden normal KID:KEY
            //   KID_HEX:KEY_HEX       -> orden normal KID:KEY
            //   Max:KEY_HEX:KID_HEX   -> convención Max, se invierte
            String kid = maxFormat ? second : first;
            String key = maxFormat ? first : second;
            addUniqueKeyPair(result, kid, key);
        }

        if (result.isEmpty()) {
            throw new IllegalArgumentException("Faltan claves ClearKey");
        }
        return result;
    }

    private static void addUniqueKeyPair(List<KeyPair> result, String kid, String key) {
        for (KeyPair existing : result) {
            if (existing.kidHex.equalsIgnoreCase(kid)
                    && existing.keyHex.equalsIgnoreCase(key)) {
                return;
            }
        }
        result.add(new KeyPair(kid, key));
    }

    private static String normalize128(String raw) {
        if (raw == null) return "";
        String trimmed = raw.trim();
        String hex = cleanHex(trimmed);
        if (isHex128(hex)) return hex.toLowerCase(Locale.ROOT);

        try {
            String padded = trimmed;
            int remainder = padded.length() % 4;
            if (remainder != 0) padded += "====".substring(remainder);

            byte[] decoded;
            try {
                decoded = Base64.decode(padded, Base64.NO_WRAP);
            } catch (IllegalArgumentException standardError) {
                decoded = Base64.decode(padded, Base64.URL_SAFE | Base64.NO_WRAP);
            }
            if (decoded.length != 16) return "";

            StringBuilder out = new StringBuilder(32);
            for (byte b : decoded) out.append(String.format(Locale.US, "%02x", b & 0xff));
            return out.toString();
        } catch (Exception ignored) {
            return "";
        }
    }

    private static byte[] hexToBytes(String value) {
        String clean = cleanHex(value);
        if (!isHex128(clean)) {
            throw new IllegalArgumentException("KID/KEY inválido");
        }
        byte[] out = new byte[clean.length() / 2];
        for (int i = 0; i < clean.length(); i += 2) {
            out[i / 2] = (byte) Integer.parseInt(clean.substring(i, i + 2), 16);
        }
        return out;
    }

    private static String cleanHex(String value) {
        return value == null ? "" : value.replace("-", "").replace(" ", "").trim();
    }

    private static boolean isHex128(String value) {
        return value.length() == 32 && value.matches("(?i)[0-9a-f]{32}");
    }

    private static final class OrientationResult {
        final List<KeyPair> pairs;
        final boolean swapped;
        final boolean matched;

        OrientationResult(List<KeyPair> pairs, boolean swapped, boolean matched) {
            this.pairs = pairs;
            this.swapped = swapped;
            this.matched = matched;
        }
    }

    private static final class KeyPair {
        final String kidHex;
        final String keyHex;

        KeyPair(String kidHex, String keyHex) {
            this.kidHex = kidHex;
            this.keyHex = keyHex;
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void playYoutube(String url) {
        String videoId = PlayerRouter.youtubeVideoId(url);
        if (videoId == null || videoId.isEmpty()) {
            Toast.makeText(this, "No pude identificar el video de YouTube", Toast.LENGTH_LONG).show();
            return;
        }

        loading.setVisibility(View.GONE);
        playerView.setVisibility(View.GONE);

        // Zapping YouTube <-> HLS/DASH:
        // releaseCurrentPlayback() pausa el WebView cuando salimos de YouTube.
        // Si volvemos a YouTube dentro de la misma Activity hay que reanudar
        // explícitamente su ciclo de vida antes de cargar el nuevo iframe; de
        // lo contrario algunos TV/TV Box dejan el video congelado al regresar.
        youtubeWebView.stopLoading();
        youtubeWebView.onResume();
        youtubeWebView.resumeTimers();
        youtubeWebView.setVisibility(View.VISIBLE);

        WebSettings settings = youtubeWebView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        youtubeWebView.setWebChromeClient(new WebChromeClient());
        youtubeWebView.setWebViewClient(new WebViewClient());

        String html = "<!doctype html><html><head>" +
                "<meta name='viewport' content='width=device-width,height=device-height,initial-scale=1,maximum-scale=1,user-scalable=no'>" +
                "<meta name='referrer' content='strict-origin-when-cross-origin'>" +
                "<style>html,body{margin:0;background:#000;width:100%;height:100%;overflow:hidden}iframe{width:100%;height:100%;border:0}</style>" +
                "</head><body>" +
                "<iframe src='https://www.youtube.com/embed/" + videoId + "?autoplay=1&playsinline=1&origin=https%3A%2F%2Fcom.cochi.client' " +
                "allow='autoplay; encrypted-media; picture-in-picture' allowfullscreen></iframe>" +
                "</body></html>";

        youtubeWebView.loadDataWithBaseURL(
                "https://com.cochi.client/", html, "text/html", "UTF-8", null);
    }

    private void releaseCurrentPlayback() {
        uiHandler.removeCallbacks(hideChannelInfo);
        uiHandler.removeCallbacks(progressTicker);
        uiHandler.removeCallbacks(markerTicker);
        uiHandler.removeCallbacks(navigationVisibilityTicker);
        uiHandler.removeCallbacks(seriesAccessTicker);
        uiHandler.removeCallbacks(fatalReconnectRunnable);
        cancelPlaybackRecoveryWatchdog();
        cancelStartupStatusWatchdog();
        playbackGeneration++;
        activeChannel = null;
        recoveryOperationRunning = false;
        activeChannelReachedReady = false;
        startupUnavailableShown = false;
        fatalRetryCount = 0;
        reconnectResumePositionMs = 0L;
        if (cochiNavOverlay != null) cochiNavOverlay.setVisibility(View.GONE);
        loading.setVisibility(View.GONE);
        if (player != null) {
            playerView.setPlayer(null);
            player.release();
            player = null;
        }
        if (youtubeWebView != null) {
            // Liberar por completo el contenido YouTube anterior antes de
            // entregar la pantalla a Media3. Conservamos la misma instancia
            // WebView para no recrear la jerarquía de vistas, pero eliminamos
            // navegación/iframe previos y pausamos su ciclo de vida.
            youtubeWebView.stopLoading();
            youtubeWebView.loadUrl("about:blank");
            youtubeWebView.clearHistory();
            youtubeWebView.onPause();
            youtubeWebView.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onStop() {
        saveProgressNow();
        cancelPlaybackRecoveryWatchdog();
        uiHandler.removeCallbacks(fatalReconnectRunnable);
        super.onStop();
        if (player != null) player.pause();
        if (youtubeWebView != null) youtubeWebView.onPause();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (player != null) {
            player.play();
            if (player.getPlaybackState() == Player.STATE_BUFFERING) armPlaybackRecoveryWatchdog();
        }
        if (youtubeWebView != null) youtubeWebView.onResume();
    }

    @Override
    protected void onDestroy() {
        saveProgressNow();
        releaseCurrentPlayback();
        if (youtubeWebView != null) {
            youtubeWebView.destroy();
        }
        super.onDestroy();
    }
}
