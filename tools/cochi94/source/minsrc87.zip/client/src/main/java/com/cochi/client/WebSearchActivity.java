package com.cochi.client;

import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * v0.23.46: Buscador de series y películas + selector de servidores.
 * La búsqueda se consulta mediante CO-CHI PANEL para mantener la credencial fuera de la APK.
 * La reproducción sigue usando exclusivamente el catálogo y el player existentes de CO-CHI.
 */
public final class WebSearchActivity extends AppCompatActivity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final AtomicInteger requestVersion = new AtomicInteger();

    private boolean television;
    private EditText searchInput;
    private MaterialButton searchButton;
    private ProgressBar loading;
    private TextView statusText;
    private TextView detailTitle;
    private TextView detailMeta;
    private TextView detailOverview;
    private ImageView detailPoster;
    private RecyclerView recycler;
    private WebSearchAdapter adapter;
    private Runnable pendingSearch;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!SessionManager.isLoggedIn(this)) {
            finish();
            return;
        }
        television = isTelevision();
        buildUi();
        ManagedTheme.applyToActivity(this);
        if (television) applyTvBackground();
        statusText.setText("Escribí una película o serie. Ejemplo: Batman");
        searchInput.requestFocus();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        final int sidePadding = dp(television ? 28 : 16);
        final int baseTopPadding = dp(television ? 22 : 14);
        final int baseBottomPadding = dp(16);
        root.setPadding(sidePadding, baseTopPadding, sidePadding, baseBottomPadding);
        // Android 15+ puede dibujar la app debajo de las barras del sistema.
        // Sumamos los insets en móvil para que el título nunca quede detrás del reloj/señal.
        if (!television) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                v.setPadding(sidePadding, baseTopPadding + insets.getSystemWindowInsetTop(),
                        sidePadding, baseBottomPadding + insets.getSystemWindowInsetBottom());
                return insets;
            });
            root.requestApplyInsets();
        }
        root.setBackgroundResource(television ? R.drawable.cochi_tv_dark_background : R.drawable.cochi_neon_background);
        setContentView(root);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        MaterialButton back = new MaterialButton(this);
        back.setText("Atrás");
        back.setAllCaps(false);
        back.setIconResource(R.drawable.ic_cochi_home);
        back.setIconTint(android.content.res.ColorStateList.valueOf(ManagedTheme.color(this, R.color.cochi_accent_2)));
        back.setTextColor(ManagedTheme.color(this, R.color.cochi_text));
        back.setBackgroundTintList(android.content.res.ColorStateList.valueOf(ManagedTheme.button(this)));
        back.setStrokeColor(android.content.res.ColorStateList.valueOf(ManagedTheme.color(this, R.color.cochi_accent)));
        back.setStrokeWidth(dp(1));
        back.setCornerRadius(dp(12));
        back.setOnClickListener(v -> finish());
        top.addView(back, new LinearLayout.LayoutParams(dp(television ? 132 : 108), dp(television ? 50 : 48)));

        TextView heading = new TextView(this);
        heading.setText("BUSCADOR DE SERIES Y PELÍCULAS");
        heading.setTextColor(ManagedTheme.color(this, R.color.cochi_text));
        heading.setTextSize(television ? 24f : 20f);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        hp.setMarginStart(dp(16));
        top.addView(heading, hp);

        LinearLayout searchRow = new LinearLayout(this);
        searchRow.setOrientation(LinearLayout.HORIZONTAL);
        searchRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams srp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        srp.topMargin = dp(16);
        root.addView(searchRow, srp);

        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setHint("Batman, Rocky, Star Wars...");
        searchInput.setHintTextColor(ManagedTheme.color(this, R.color.cochi_muted));
        searchInput.setTextColor(ManagedTheme.color(this, R.color.cochi_text));
        searchInput.setTextSize(television ? 18f : 16f);
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchInput.setBackgroundResource(R.drawable.tv_search_selector);
        searchInput.setPadding(dp(16), 0, dp(16), 0);
        searchRow.addView(searchInput, new LinearLayout.LayoutParams(0, dp(television ? 56 : 52), 1f));

        searchButton = new MaterialButton(this);
        searchButton.setText("Buscar");
        searchButton.setAllCaps(false);
        searchButton.setIconResource(R.drawable.ic_cochi_search);
        searchButton.setIconTint(android.content.res.ColorStateList.valueOf(ManagedTheme.color(this, R.color.cochi_text)));
        searchButton.setTextColor(ManagedTheme.color(this, R.color.cochi_text));
        searchButton.setBackgroundTintList(ManagedTheme.colors(this, R.color.cochi_blue_button));
        searchButton.setCornerRadius(dp(12));
        LinearLayout.LayoutParams sbp = new LinearLayout.LayoutParams(dp(television ? 150 : 124), dp(television ? 56 : 52));
        sbp.setMarginStart(dp(10));
        searchRow.addView(searchButton, sbp);

        LinearLayout stateRow = new LinearLayout(this);
        stateRow.setOrientation(LinearLayout.HORIZONTAL);
        stateRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stp.topMargin = dp(10);
        root.addView(stateRow, stp);

        loading = new ProgressBar(this);
        loading.setVisibility(View.GONE);
        stateRow.addView(loading, new LinearLayout.LayoutParams(dp(26), dp(26)));

        statusText = new TextView(this);
        statusText.setTextColor(ManagedTheme.color(this, R.color.cochi_muted));
        statusText.setTextSize(television ? 14f : 13f);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        statusParams.setMarginStart(dp(8));
        stateRow.addView(statusText, statusParams);

        LinearLayout contentRow = new LinearLayout(this);
        contentRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams crp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        crp.topMargin = dp(8);
        root.addView(contentRow, crp);

        recycler = new RecyclerView(this);
        recycler.setClipChildren(false);
        recycler.setClipToPadding(false);
        recycler.setOverScrollMode(View.OVER_SCROLL_NEVER);
        int columns = television ? 5 : (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE ? 4 : 2);
        recycler.setLayoutManager(new GridLayoutManager(this, columns));
        adapter = new WebSearchAdapter(this, television, new WebSearchAdapter.Listener() {
            @Override public void onClick(WebSearchResult item) { openOrLocate(item); }
            @Override public void onFocus(WebSearchResult item) { showDetail(item); }
        });
        recycler.setAdapter(adapter);
        contentRow.addView(recycler, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, television ? 0.70f : 1f));

        if (television) {
            MaterialCardView detailCard = buildDetailCard();
            LinearLayout.LayoutParams dcp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.30f);
            dcp.setMarginStart(dp(16));
            contentRow.addView(detailCard, dcp);
        }

        searchButton.setOnClickListener(v -> performSearch(searchInput.getText().toString()));
        searchInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH
                    || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                performSearch(searchInput.getText().toString());
                return true;
            }
            return false;
        });
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (pendingSearch != null) handler.removeCallbacks(pendingSearch);
                String q = s == null ? "" : s.toString().trim();
                if (q.length() < 3) return;
                pendingSearch = () -> performSearch(q);
                handler.postDelayed(pendingSearch, 650);
            }
            @Override public void afterTextChanged(Editable s) { }
        });
    }

    private MaterialCardView buildDetailCard() {
        MaterialCardView card = new MaterialCardView(this);
        card.setCardBackgroundColor(ManagedTheme.color(this, R.color.cochi_tv_surface));
        card.setRadius(dp(18));
        card.setStrokeColor(ManagedTheme.color(this, R.color.cochi_tv_border_soft));
        card.setStrokeWidth(dp(1));

        LinearLayout inner = new LinearLayout(this);
        inner.setOrientation(LinearLayout.VERTICAL);
        inner.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.addView(inner, new MaterialCardView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        detailPoster = new ImageView(this);
        detailPoster.setScaleType(ImageView.ScaleType.CENTER_CROP);
        detailPoster.setImageResource(R.drawable.ic_cochi);
        inner.addView(detailPoster, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(248)));

        detailTitle = new TextView(this);
        detailTitle.setText("Elegí un resultado");
        detailTitle.setTextColor(ManagedTheme.color(this, R.color.cochi_text));
        detailTitle.setTextSize(20f);
        detailTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams dtp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dtp.topMargin = dp(12);
        inner.addView(detailTitle, dtp);

        detailMeta = new TextView(this);
        detailMeta.setTextColor(ManagedTheme.color(this, R.color.cochi_accent_2));
        detailMeta.setTextSize(13f);
        inner.addView(detailMeta, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        detailOverview = new TextView(this);
        detailOverview.setText("Los resultados se usan para identificar el título. Al elegirlo, CO-CHI busca si ya está disponible en tu catálogo.");
        detailOverview.setTextColor(ManagedTheme.color(this, R.color.cochi_muted));
        detailOverview.setTextSize(13f);
        detailOverview.setMaxLines(7);
        LinearLayout.LayoutParams dop = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dop.topMargin = dp(8);
        inner.addView(detailOverview, dop);
        return card;
    }

    private void showDetail(WebSearchResult item) {
        if (!television || item == null || detailTitle == null) return;
        detailTitle.setText(item.title);
        detailMeta.setText(item.typeLabel() + (item.year.isEmpty() ? "" : " · " + item.year));
        detailOverview.setText(item.overview.isEmpty() ? "Sin sinopsis disponible." : item.overview);
        ImageLoader.load(item.posterUrl, detailPoster);
    }

    private void performSearch(String rawQuery) {
        String query = rawQuery == null ? "" : rawQuery.trim();
        if (query.length() < 2) {
            statusText.setText("Escribí al menos 2 letras.");
            return;
        }
        int version = requestVersion.incrementAndGet();
        setSearching(true, "Buscando “" + query + "”…");
        new Thread(() -> {
            try {
                List<WebSearchResult> results = TmdbSearchClient.search(getApplicationContext(), query);
                runOnUiThread(() -> {
                    if (version != requestVersion.get() || isFinishing()) return;
                    adapter.submitList(results);
                    setSearching(false, results.isEmpty()
                            ? "No se encontraron resultados."
                            : results.size() + " resultados encontrados");
                    if (!results.isEmpty()) {
                        showDetail(results.get(0));
                        recycler.scrollToPosition(0);
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (version != requestVersion.get() || isFinishing()) return;
                    setSearching(false, "No se pudo realizar la búsqueda. Probá nuevamente.");
                });
            }
        }, "cochi-tmdb-search").start();
    }

    private void openOrLocate(WebSearchResult result) {
        if (result == null) return;
        CatalogSource source = result.isSeries() ? CatalogSource.SERIES : CatalogSource.MOVIES;
        setSearching(true, "Buscando opciones para “" + result.title + "”…");

        CatalogRepository.load(this, source, new CatalogRepository.Callback() {
            @Override public void onLoaded(List<Channel> items, boolean fromRemote) {
                if (isFinishing() || isDestroyed()) return;
                List<Channel> visible = new ArrayList<>();
                if (items != null) for (Channel channel : items) if (channel != null && !channel.adult) visible.add(channel);
                int index = findBestMatch(visible, result);
                Channel matched = index >= 0 ? visible.get(index) : null;

                // En series primero hay que elegir temporada/capítulo. Conservamos la ficha
                // existente y el selector de fuentes se aplica a las opciones directas.
                if (result.isSeries() && matched != null) {
                    setSearching(false, "");
                    SeriesStore.SeriesInfo info = SeriesStore.getSeries(matched.id);
                    if (info == null || info.episodeCount() == 0) {
                        Toast.makeText(WebSearchActivity.this, "La serie fue encontrada, pero no tiene capítulos disponibles", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Intent intent = new Intent(WebSearchActivity.this, SeriesDetailActivity.class);
                    intent.putExtra(SeriesDetailActivity.EXTRA_SERIES_ID, matched.id);
                    startActivity(intent);
                    return;
                }

                final Channel localMatch = matched;
                final int localIndex = index;
                if (!result.isSeries() && localMatch != null) ChannelStore.setActiveChannels(visible);
                new Thread(() -> resolvePlaybackOptions(result, localMatch, localIndex), "cochi-media-options").start();
            }

            @Override public void onError(String message) {
                new Thread(() -> resolvePlaybackOptions(result, null, -1), "cochi-media-options").start();
            }
        });
    }

    private void resolvePlaybackOptions(WebSearchResult result, Channel localMatch, int localIndex) {
        List<PlaybackOption> options = new ArrayList<>();
        if (localMatch != null) options.addAll(localOptions(localMatch, localIndex));

        try {
            org.json.JSONObject root = BackendClient.mediaPlaybackOptions(getApplicationContext(), result);
            org.json.JSONArray remote = root.optJSONArray("options");
            if (remote != null) {
                for (int i = 0; i < remote.length() && options.size() < 40; i++) {
                    org.json.JSONObject item = remote.optJSONObject(i);
                    PlaybackOption option = parseRemoteOption(item);
                    if (option != null && option.isPlayable() && !hasUrl(options, option.url)) options.add(option);
                }
            }
        } catch (Exception ignored) { }

        final List<PlaybackOption> ready = sortPlaybackOptions(options);
        runOnUiThread(() -> {
            if (isFinishing() || isDestroyed()) return;
            setSearching(false, "");
            if (!ready.isEmpty()) {
                String meta = result.typeLabel() + (result.year.isEmpty() ? "" : " · " + result.year);
                PlaybackOptionStore.set(result.title, meta, ready);
                startActivity(new Intent(WebSearchActivity.this, PlaybackOptionsActivity.class));
                return;
            }
            new AlertDialog.Builder(WebSearchActivity.this)
                    .setTitle(result.title + (result.year.isEmpty() ? "" : " (" + result.year + ")"))
                    .setMessage("No se encontraron opciones directas de reproducción para este título.")
                    .setPositiveButton("Aceptar", null)
                    .show();
        });
    }

    private List<PlaybackOption> localOptions(Channel channel, int localIndex) {
        List<PlaybackOption> out = new ArrayList<>();
        if (channel == null || channel.sources == null) return out;
        int i = 0;
        for (StreamSource source : channel.sources) {
            if (source == null || !source.isPlayable()) continue;
            String server = source.serverLabel.isEmpty() ? "CO-CHI" : source.serverLabel;
            String language = source.languageLabel;
            String subtitles = source.subtitlesLabel;
            out.add(new PlaybackOption(server, language, subtitles, source.qualityLabel,
                    source.url, source.type, source.headers, source.drm.clearKeyPairs, source.priority + i, localIndex, i));
            i++;
        }
        return out;
    }

    private PlaybackOption parseRemoteOption(org.json.JSONObject item) {
        if (item == null) return null;
        LinkedHashMap<String, String> headers = new LinkedHashMap<>();
        org.json.JSONObject h = item.optJSONObject("headers");
        if (h != null) {
            java.util.Iterator<String> keys = h.keys();
            while (keys.hasNext()) {
                String key = keys.next(); String value = h.optString(key, "");
                if (!key.trim().isEmpty() && !value.trim().isEmpty()) headers.put(key, value);
            }
        }
        return new PlaybackOption(
                item.optString("server", item.optString("provider", "Servidor")),
                item.optString("language", ""),
                item.optString("subtitles", ""),
                item.optString("quality", ""),
                item.optString("url", ""),
                item.optString("type", "auto"),
                headers,
                item.optString("clear_key_pairs", ""),
                item.optInt("priority", 100));
    }

    private boolean hasUrl(List<PlaybackOption> list, String url) {
        if (url == null || url.trim().isEmpty()) return true;
        for (PlaybackOption option : list) if (option != null && url.equals(option.url)) return true;
        return false;
    }

    private List<PlaybackOption> sortPlaybackOptions(List<PlaybackOption> input) {
        List<PlaybackOption> out = new ArrayList<>(input);
        out.sort((a, b) -> {
            int la = languageRank(a), lb = languageRank(b);
            if (la != lb) return Integer.compare(la, lb);
            int p = Integer.compare(a.priority, b.priority);
            if (p != 0) return p;
            return a.server.compareToIgnoreCase(b.server);
        });
        return out;
    }

    private int languageRank(PlaybackOption o) {
        String l = o == null ? "" : o.language.toLowerCase(Locale.ROOT);
        String s = o == null ? "" : o.subtitles.toLowerCase(Locale.ROOT);
        if (l.contains("latino")) return 0;
        if (l.contains("castellano")) return 1;
        if (l.contains("español")) return 2;
        if (s.contains("subtítulos es")) return 3;
        if (l.contains("sin verificar")) return 5;
        return 4;
    }

    private int findBestMatch(List<Channel> items, WebSearchResult result) {
        String wanted = normalizeTitle(result.title);
        String original = normalizeTitle(result.originalTitle);
        int containsCandidate = -1;
        for (int i = 0; i < items.size(); i++) {
            Channel channel = items.get(i);
            String candidate = normalizeTitle(channel.name);
            if (candidate.isEmpty()) continue;
            if (candidate.equals(wanted) || (!original.isEmpty() && candidate.equals(original))) return i;
            if (containsCandidate < 0 && (candidate.contains(wanted) || wanted.contains(candidate))) {
                containsCandidate = i;
            }
        }
        return containsCandidate;
    }

    private String normalizeTitle(String value) {
        if (value == null) return "";
        String normalized = Normalizer.normalize(value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .toLowerCase(Locale.ROOT)
                .replace('&', ' ')
                .replaceAll("[^a-z0-9]+", " ")
                .trim()
                .replaceAll("\\s+", " ");
        return normalized;
    }

    private void setSearching(boolean active, String message) {
        loading.setVisibility(active ? View.VISIBLE : View.GONE);
        searchButton.setEnabled(!active);
        if (message != null && !message.isEmpty()) statusText.setText(message);
    }

    private void applyTvBackground() {
        int bg = ManagedTheme.color(this, R.color.cochi_tv_bg);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setBackgroundColor(bg);
    }

    private boolean isTelevision() {
        UiModeManager manager = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        return (manager != null && manager.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION)
                || getPackageManager().hasSystemFeature("android.software.leanback");
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
