package com.cochi.client;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import android.os.Debug;

import java.io.BufferedReader;
import java.io.FileReader;
import java.security.MessageDigest;
import java.util.Locale;

/**
 * Comprobaciones locales de integridad de CO-CHI.
 *
 * Importante: ninguna comprobación dentro de una APK es invulnerable a un atacante
 * con control total del binario. Esta capa sirve para dificultar repaquetados y para
 * que el backend pueda recibir la huella de la firma instalada. La autorización real
 * de contenido sigue dependiendo de la sesión del servidor.
 */
public final class AppIntegrity {
    private static final String OFFICIAL_PACKAGE = "com.cochi.client";

    private AppIntegrity() {}

    public static boolean isRuntimeAllowed(Context context) {
        if (context == null || !OFFICIAL_PACKAGE.equals(context.getPackageName())) return false;

        // DEBUG queda disponible para desarrollo local aunque use la firma debug.
        // La política estricta se aplica únicamente a la compilación RELEASE.
        if (BuildConfig.DEBUG) return true;

        if (Debug.isDebuggerConnected() || Debug.waitingForDebugger() || isTracerAttached()) return false;
        try {
            ApplicationInfo info = context.getApplicationInfo();
            if ((info.flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) return false;
            if ((info.flags & ApplicationInfo.FLAG_TEST_ONLY) != 0) return false;
        } catch (Exception ignored) {
            return false;
        }

        // En la versión final este valor debe estar siempre fijado. Un valor vacío
        // se rechaza para evitar publicar accidentalmente una RELEASE sin pinning.
        String expected = normalize(BuildConfig.COCHI_RELEASE_CERT_SHA256);
        if (expected.isEmpty()) return false;
        String current = normalize(signatureSha256(context));
        return !current.isEmpty() && expected.equals(current);
    }

    public static String runtimeState(Context context) {
        if (BuildConfig.DEBUG) return "debug";
        if (Debug.isDebuggerConnected() || Debug.waitingForDebugger() || isTracerAttached()) return "debugger";
        return isRuntimeAllowed(context) ? "ok" : "rejected";
    }

    public static String signatureSha256(Context context) {
        if (context == null) return "";
        try {
            PackageManager pm = context.getPackageManager();
            Signature[] signatures;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                PackageInfo info = pm.getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
                if (info.signingInfo == null) return "";
                signatures = info.signingInfo.hasMultipleSigners()
                        ? info.signingInfo.getApkContentsSigners()
                        : info.signingInfo.getSigningCertificateHistory();
            } else {
                @SuppressWarnings("deprecation")
                PackageInfo info = pm.getPackageInfo(context.getPackageName(), PackageManager.GET_SIGNATURES);
                @SuppressWarnings("deprecation")
                Signature[] legacy = info.signatures;
                signatures = legacy;
            }
            if (signatures == null || signatures.length == 0) return "";
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] digest = md.digest(signatures[0].toByteArray());
            StringBuilder out = new StringBuilder(digest.length * 2);
            for (byte b : digest) out.append(String.format(Locale.ROOT, "%02X", b));
            return out.toString();
        } catch (Exception ignored) {
            return "";
        }
    }

    private static boolean isTracerAttached() {
        try (BufferedReader reader = new BufferedReader(new FileReader("/proc/self/status"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.startsWith("TracerPid:")) continue;
                String value = line.substring("TracerPid:".length()).trim();
                return !value.isEmpty() && !"0".equals(value);
            }
        } catch (Exception ignored) {
            // Si el sistema no expone /proc, no bloqueamos dispositivos legítimos.
        }
        return false;
    }

    private static String normalize(String value) {
        return value == null ? "" : value.replace(":", "").replace(" ", "").trim().toUpperCase(Locale.ROOT);
    }
}
