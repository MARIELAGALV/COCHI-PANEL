package com.cochi.client;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/** Sesión real de CO-CHI contra CO-CHI PANEL. */
public final class SessionManager {
    private static final String PREFS = "cochi_session";
    private static final String KEY_ACTIVATED = "activated";
    private static final String KEY_CLIENT_ID = "client_id";
    private static final String KEY_CLIENT_NAME = "client_name";
    private static final String KEY_DEVICE_ID = "device_id";
    private static final String KEY_DEVICE_SECRET = "device_secret";
    private static final String KEY_ACTIVATION_CODE = "activation_code";
    private static final String KEY_TOKEN = "session_token";
    private static final String KEY_TOKEN_EXPIRES_AT = "session_token_expires_at_ms";
    private static final String KEY_EXPIRES_AT = "expires_at_ms";
    private static final String KEY_SERVER_TIME_OFFSET = "server_time_offset_ms";
    private static final String KEY_DEVICE_LIMIT = "device_limit";
    private static final String KEY_LINKED_DEVICES = "linked_devices";
    private static final String KEY_DEVICE_INDEX = "device_index";

    // Última validación REAL satisfactoria contra el PANEL durante este proceso.
    // Sirve para no repetir la misma llamada de red al abrir una ficha y, segundos
    // después, tocar un capítulo. El reproductor de Series sigue validando cada 30 s.
    private static volatile long lastSuccessfulAccessValidationAtMs = 0L;

    private SessionManager() {}

    public static boolean isLoggedIn(Context context) { return isActivated(context); }

    /** Solo se considera activado si el dispositivo ya tiene credencial real del backend. */
    public static boolean isActivated(Context context) {
        SharedPreferences p = prefs(context);
        return p.getBoolean(KEY_ACTIVATED, false)
                && !deviceSecret(context).isEmpty();
    }

    public static String activationCode(Context context) {
        String code = prefs(context).getString(KEY_ACTIVATION_CODE, "");
        return code == null || code.trim().isEmpty() ? "---- ----" : code.trim().toUpperCase(Locale.ROOT);
    }

    public static String deviceId(Context context) {
        SharedPreferences prefs = prefs(context);
        String stored = prefs.getString(KEY_DEVICE_ID, "");
        if (stored != null && !stored.trim().isEmpty()) return stored;
        String androidId = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        if (androidId == null || androidId.trim().isEmpty()) androidId = "unknown-android-id";
        String value = "cochi:" + context.getPackageName() + ":" + androidId;
        String hashed = sha256(value);
        prefs.edit().putString(KEY_DEVICE_ID, hashed).apply();
        return hashed;
    }

    public static String deviceSecret(Context context) {
        SharedPreferences p = prefs(context);
        return clean(SecureStore.get(context, p, KEY_DEVICE_SECRET, ""));
    }

    /** Registra por primera vez el dispositivo y guarda su secreto local. */
    public static synchronized String registerIfNeededBlocking(Context context) throws Exception {
        SharedPreferences p = prefs(context);
        String secret = deviceSecret(context);
        String existingCode = activationCode(context);
        if (!secret.isEmpty() && !existingCode.startsWith("----")) return existingCode;

        JSONObject response = BackendClient.registerDevice(context);
        boolean existing = response.optBoolean("existing", false);
        String code = clean(response.optString("activationCode", ""));
        String newSecret = clean(response.optString("deviceSecret", ""));

        if (existing && newSecret.isEmpty()) {
            // Esto solo puede pasar si la app perdió su secreto local. No inventamos ni recuperamos credenciales.
            throw new IllegalStateException("El dispositivo ya está registrado pero falta su credencial local. Eliminá este dispositivo desde el PANEL y volvé a registrarlo.");
        }
        if (code.isEmpty() || newSecret.isEmpty()) throw new IllegalStateException("Respuesta de registro incompleta");

        p.edit()
                .putString(KEY_ACTIVATION_CODE, code)
                .putBoolean(KEY_ACTIVATED, false)
                .remove(KEY_TOKEN)
                .remove(KEY_TOKEN_EXPIRES_AT)
                .apply();
        SecureStore.put(context, p, KEY_DEVICE_SECRET, newSecret);
        return code;
    }

    /** Consulta estado real y, si está autorizado, obtiene una sesión de contenido. */
    public static synchronized boolean refreshActivationBlocking(Context context) throws Exception {
        String secret = deviceSecret(context);
        if (secret.isEmpty()) {
            registerIfNeededBlocking(context);
            secret = deviceSecret(context);
        }
        JSONObject status = BackendClient.deviceStatus(context, secret);
        syncServerClock(context, status);
        String code = clean(status.optString("activationCode", activationCode(context)));
        boolean allowed = status.optBoolean("allowed", false);
        String clientId = status.opt("clientId") == JSONObject.NULL ? "" : clean(status.optString("clientId", ""));
        String clientName = status.opt("clientName") == JSONObject.NULL ? "" : clean(status.optString("clientName", ""));
        // El vencimiento pertenece al CLIENTE, no al dispositivo. Todos los equipos
        // vinculados al mismo clientId deben persistir exactamente el mismo instante.
        long accessExpiry = resolveClientExpiryMillis(status);

        SharedPreferences.Editor edit = prefs(context).edit().putString(KEY_ACTIVATION_CODE, code);
        putDeviceCapacity(status, edit);
        if (!allowed) {
            lastSuccessfulAccessValidationAtMs = 0L;
            edit.putBoolean(KEY_ACTIVATED, false)
                    .remove(KEY_TOKEN).remove(KEY_TOKEN_EXPIRES_AT);
            edit.apply();
            return false;
        }

        JSONObject session = BackendClient.createSession(context, secret);
        String token = clean(session.optString("token", ""));
        long tokenExpiry = parseIsoMillis(session.optString("expiresAt", ""));
        if (token.isEmpty()) throw new IllegalStateException("El backend no entregó sesión");
        // La respuesta /status es la autoridad para la fecha del cliente. No dejamos
        // que un expiresAt/accessExpiresAt de sesión (propio de cada dispositivo)
        // reemplace una fecha de cliente ya obtenida. Solo usamos session como respaldo
        // cuando /status no entregó ningún vencimiento de cliente.
        if (accessExpiry <= 0L) accessExpiry = resolveClientExpiryMillis(session);

        SharedPreferences sessionPrefs = prefs(context);
        SharedPreferences.Editor sessionEdit = sessionPrefs.edit()
                .putBoolean(KEY_ACTIVATED, true)
                .putString(KEY_ACTIVATION_CODE, code)
                .putString(KEY_CLIENT_ID, clientId)
                .putString(KEY_CLIENT_NAME, clientName.isEmpty() ? "Cliente" : clientName)
                .putLong(KEY_TOKEN_EXPIRES_AT, tokenExpiry)
                .putLong(KEY_EXPIRES_AT, accessExpiry);
        putDeviceCapacity(status, sessionEdit);
        putDeviceCapacity(session, sessionEdit);
        sessionEdit.apply();
        SecureStore.put(context, sessionPrefs, KEY_TOKEN, token);
        lastSuccessfulAccessValidationAtMs = System.currentTimeMillis();
        return true;
    }

    /**
     * Valida el estado REAL del dispositivo sin reutilizar el estado local.
     * Se usa para cortar accesos que ya estaban cacheados (especialmente Series).
     * No crea una nueva sesión si el dispositivo sigue autorizado.
     */
    public static synchronized boolean validateAccessBlocking(Context context) throws Exception {
        String secret = deviceSecret(context);
        if (secret.isEmpty()) {
            registerIfNeededBlocking(context);
            secret = deviceSecret(context);
        }

        JSONObject status = BackendClient.deviceStatus(context, secret);
        syncServerClock(context, status);
        String code = clean(status.optString("activationCode", activationCode(context)));
        boolean allowed = status.optBoolean("allowed", false);
        String clientId = status.opt("clientId") == JSONObject.NULL ? "" : clean(status.optString("clientId", ""));
        String clientName = status.opt("clientName") == JSONObject.NULL ? "" : clean(status.optString("clientName", ""));
        long accessExpiry = resolveClientExpiryMillis(status);

        SharedPreferences.Editor edit = prefs(context).edit()
                .putString(KEY_ACTIVATION_CODE, code);
        putDeviceCapacity(status, edit);

        if (!allowed) {
            lastSuccessfulAccessValidationAtMs = 0L;
            edit.putBoolean(KEY_ACTIVATED, false)
                    .remove(KEY_TOKEN)
                    .remove(KEY_TOKEN_EXPIRES_AT)
                    .apply();
            return false;
        }

        edit.putBoolean(KEY_ACTIVATED, true)
                .putString(KEY_CLIENT_ID, clientId)
                .putString(KEY_CLIENT_NAME, clientName.isEmpty() ? "Cliente" : clientName)
                .putLong(KEY_EXPIRES_AT, accessExpiry)
                .apply();
        lastSuccessfulAccessValidationAtMs = System.currentTimeMillis();
        return true;
    }

    /**
     * Devuelve true solo si en esta misma ejecución se confirmó el acceso contra el PANEL
     * hace muy poco. Nunca extiende vencimientos ni sustituye las validaciones periódicas.
     */
    public static boolean wasAccessRecentlyValidated(long maxAgeMs) {
        long at = lastSuccessfulAccessValidationAtMs;
        if (at <= 0L || maxAgeMs <= 0L) return false;
        long age = System.currentTimeMillis() - at;
        return age >= 0L && age <= maxAgeMs;
    }

    /** Obtiene token válido para endpoints protegidos; renueva antes de caducar. */
    public static synchronized String ensureSessionTokenBlocking(Context context) throws Exception {
        SharedPreferences p = prefs(context);
        String token = clean(SecureStore.get(context, p, KEY_TOKEN, ""));
        long tokenExpiry = p.getLong(KEY_TOKEN_EXPIRES_AT, 0L);
        if (!token.isEmpty() && (tokenExpiry <= 0L || tokenExpiry - System.currentTimeMillis() > 60_000L)) return token;
        if (!refreshActivationBlocking(context)) throw new IllegalStateException("Dispositivo sin acceso activo");
        token = clean(SecureStore.get(context, prefs(context), KEY_TOKEN, ""));
        if (token.isEmpty()) throw new IllegalStateException("No se pudo crear la sesión");
        return token;
    }

    public static String username(Context context) { return clientName(context); }
    public static String clientName(Context context) { return prefs(context).getString(KEY_CLIENT_NAME, "Cliente"); }
    public static String clientId(Context context) { return prefs(context).getString(KEY_CLIENT_ID, "unlinked"); }
    public static String token(Context context) { return SecureStore.get(context, prefs(context), KEY_TOKEN, ""); }
    public static long expiresAt(Context context) { return prefs(context).getLong(KEY_EXPIRES_AT, 0L); }
    public static int deviceLimit(Context context) { return Math.max(1, prefs(context).getInt(KEY_DEVICE_LIMIT, 2)); }
    public static int linkedDevices(Context context) { return Math.max(0, prefs(context).getInt(KEY_LINKED_DEVICES, 0)); }
    public static int deviceIndex(Context context) { return Math.max(0, prefs(context).getInt(KEY_DEVICE_INDEX, 0)); }

    /** Etiqueta dinámica enviada por el backend, por ejemplo "2 de 3". */
    public static String devicePositionLabel(Context context) {
        int limit = deviceLimit(context);
        int index = deviceIndex(context);
        if (index > 0) return index + " de " + limit;
        int linked = linkedDevices(context);
        return linked > 0 ? linked + " de " + limit : "";
    }

    public static boolean isExpired(Context context) {
        long expiry = expiresAt(context);
        return isActivated(context) && expiry > 0L && serverNowMillis(context) >= expiry;
    }

    /**
     * Días COMPLETOS restantes, igual que el contador del PANEL.
     * No redondea hacia arriba: 29 días y 23 horas se muestran como 29 días, no 30.
     */
    public static int daysRemaining(Context context) {
        long remaining = millisRemaining(context);
        if (remaining <= 0L) return 0;
        return (int) (remaining / TimeUnit.DAYS.toMillis(1));
    }

    public static long millisRemaining(Context context) {
        long expiry = expiresAt(context);
        if (expiry <= 0L) return 0L;
        return Math.max(0L, expiry - serverNowMillis(context));
    }

    /** Mismo formato de tiempo restante que usa el PANEL: Nd HHh MMm. */
    public static String remainingTimeText(Context context) {
        long remaining = millisRemaining(context);
        if (remaining <= 0L) return "VENCIDO";
        long sec = (remaining + 999L) / 1000L;
        long days = sec / 86400L;
        sec -= days * 86400L;
        long hours = sec / 3600L;
        sec -= hours * 3600L;
        long minutes = sec / 60L;
        long seconds = sec - minutes * 60L;
        if (days > 0L) {
            return days + "d " + two(hours) + "h " + two(minutes) + "m";
        }
        return two(hours) + "h " + two(minutes) + "m " + two(seconds) + "s";
    }

    /** Un acceso menor o igual a 2 horas se presenta como demo/minutos, no como cuenta mensual. */
    public static boolean isShortAccess(Context context) {
        long remaining = millisRemaining(context);
        return remaining > 0L && remaining <= TimeUnit.HOURS.toMillis(2);
    }

    public static int minutesRemaining(Context context) {
        long remaining = millisRemaining(context);
        if (remaining <= 0L) return 0;
        long minute = TimeUnit.MINUTES.toMillis(1);
        return (int) Math.max(1L, (remaining + minute - 1L) / minute);
    }

    public static String accountStatusText(Context context) {
        if (isExpired(context)) return "CUENTA EXPIRADA";
        if (isShortAccess(context)) return "DEMO · " + minutesRemaining(context) + " min restantes";
        String remaining = remainingTimeText(context);
        if (millisRemaining(context) <= TimeUnit.DAYS.toMillis(2)) return "ATENCIÓN · vence en " + remaining;
        return "CUENTA ACTIVA · vence en " + remaining;
    }

    public static boolean shouldWarn(Context context) {
        return !isExpired(context) && (isShortAccess(context) || millisRemaining(context) <= TimeUnit.DAYS.toMillis(7));
    }

    /** Desvincula solo los datos locales; el PANEL conserva el dispositivo hasta que el vendedor lo gestione. */
    public static void logout(Context context) {
        lastSuccessfulAccessValidationAtMs = 0L;
        CatalogRepository.clearTransientCache();
        SharedPreferences prefs = prefs(context);
        String deviceId = prefs.getString(KEY_DEVICE_ID, "");
        prefs.edit().clear().putString(KEY_DEVICE_ID, deviceId == null ? "" : deviceId).apply();
    }

    /** Actualiza la capacidad dinámica con cualquier respuesta del PANEL (status/session/config). */
    public static void updateDeviceCapacity(Context context, JSONObject source) {
        if (context == null || source == null) return;
        SharedPreferences.Editor edit = prefs(context).edit();
        putDeviceCapacity(source, edit);
        JSONObject client = source.optJSONObject("client");
        if (client != null) putDeviceCapacity(client, edit);
        edit.apply();
    }

    private static void putDeviceCapacity(JSONObject source, SharedPreferences.Editor edit) {
        if (source == null || edit == null) return;
        int limit = source.optInt("deviceLimit", 0);
        int linked = source.optInt("linkedDevices", -1);
        int index = source.optInt("deviceIndex", -1);
        if (limit > 0) edit.putInt(KEY_DEVICE_LIMIT, limit);
        if (linked >= 0) edit.putInt(KEY_LINKED_DEVICES, linked);
        if (index >= 0) edit.putInt(KEY_DEVICE_INDEX, index);
    }

    private static SharedPreferences prefs(Context context) { return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
    private static String clean(String value) { return value == null ? "" : value.trim(); }

    /**
     * Resuelve la fecha CANÓNICA del cliente. Priorizamos clientExpiresAt y también
     * soportamos respuestas donde el PANEL anida los datos en client. accessExpiresAt
     * queda únicamente como compatibilidad con backends anteriores.
     */
    private static long resolveClientExpiryMillis(JSONObject source) {
        if (source == null) return 0L;
        long value = parseIsoMillis(source.optString("clientExpiresAt", ""));
        JSONObject client = source.optJSONObject("client");
        if (value <= 0L && client != null) {
            value = parseIsoMillis(client.optString("clientExpiresAt", ""));
            if (value <= 0L) value = parseIsoMillis(client.optString("expiresAt", ""));
            if (value <= 0L) value = parseIsoMillis(client.optString("accessExpiresAt", ""));
        }
        if (value <= 0L) value = parseIsoMillis(source.optString("accessExpiresAt", ""));
        return value;
    }

    private static long parseIsoMillis(String value) {
        String v = clean(value);
        if (v.isEmpty()) return 0L;

        // Acepta Z y offsets (+00:00 / -03:00), con o sin milisegundos. Esto evita
        // que dos dispositivos interpreten distinto la misma hora si el PANEL cambia
        // el formato ISO-8601 sin cambiar el instante real.
        String[] patterns = new String[] {
                "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
                "yyyy-MM-dd'T'HH:mm:ssXXX",
                "yyyy-MM-dd'T'HH:mm:ss.SSSXX",
                "yyyy-MM-dd'T'HH:mm:ssXX",
                "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
                "yyyy-MM-dd'T'HH:mm:ss'Z'"
        };
        for (String pattern : patterns) {
            try {
                SimpleDateFormat f = new SimpleDateFormat(pattern, Locale.US);
                f.setLenient(false);
                if (pattern.endsWith("'Z'")) f.setTimeZone(TimeZone.getTimeZone("UTC"));
                Date d = f.parse(v);
                if (d != null) return d.getTime();
            } catch (Exception ignored) { }
        }
        return 0L;
    }

    /**
     * Sincroniza el reloj usado para vencimientos con serverTime del PANEL.
     * Si no hay serverTime válido, conserva el último offset conocido y, en una
     * instalación nueva, equivale al reloj local (offset 0).
     */
    private static void syncServerClock(Context context, JSONObject source) {
        if (context == null || source == null) return;
        long serverTime = parseIsoMillis(source.optString("serverTime", ""));
        if (serverTime <= 0L) return;
        long offset = serverTime - System.currentTimeMillis();
        prefs(context).edit().putLong(KEY_SERVER_TIME_OFFSET, offset).apply();
    }

    private static long serverNowMillis(Context context) {
        long offset = prefs(context).getLong(KEY_SERVER_TIME_OFFSET, 0L);
        return System.currentTimeMillis() + offset;
    }

    private static String two(long value) {
        return String.format(Locale.ROOT, "%02d", value);
    }

    private static String sha256(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder(bytes.length * 2);
            for (byte b : bytes) out.append(String.format(Locale.ROOT, "%02x", b));
            return out.toString();
        } catch (Exception ignored) {
            return Integer.toHexString(value.hashCode()) + "00000000";
        }
    }
}
