package com.cochi.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ChannelStore {
    private static List<Channel> activeChannels = Collections.emptyList();

    private ChannelStore() {}

    public static synchronized void setActiveChannels(List<Channel> channels) {
        activeChannels = Collections.unmodifiableList(new ArrayList<>(channels));
    }

    public static synchronized List<Channel> getActiveChannels() {
        return activeChannels;
    }

    public static synchronized Channel get(int index) {
        if (index < 0 || index >= activeChannels.size()) return null;
        return activeChannels.get(index);
    }

    public static synchronized int size() {
        return activeChannels.size();
    }

    /** Selecciona una fuente concreta para un elemento sin perder el resto del catálogo. */
    public static synchronized boolean selectSourceAt(int channelIndex, int sourceIndex) {
        if (channelIndex < 0 || channelIndex >= activeChannels.size()) return false;
        Channel current = activeChannels.get(channelIndex);
        if (current == null || sourceIndex < 0 || sourceIndex >= current.sources.size()) return false;
        ArrayList<Channel> copy = new ArrayList<>(activeChannels);
        copy.set(channelIndex, current.usingSource(sourceIndex));
        activeChannels = Collections.unmodifiableList(copy);
        return true;
    }
}
