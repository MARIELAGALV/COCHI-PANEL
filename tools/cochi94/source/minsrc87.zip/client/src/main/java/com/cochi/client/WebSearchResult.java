package com.cochi.client;

/** Resultado normalizado proveniente de TMDb. */
public final class WebSearchResult {
    public final long tmdbId;
    public final String mediaType; // movie | tv
    public final String title;
    public final String originalTitle;
    public final String year;
    public final String posterUrl;
    public final String overview;

    public WebSearchResult(long tmdbId, String mediaType, String title, String originalTitle,
                           String year, String posterUrl, String overview) {
        this.tmdbId = tmdbId;
        this.mediaType = mediaType == null ? "" : mediaType;
        this.title = title == null ? "" : title;
        this.originalTitle = originalTitle == null ? "" : originalTitle;
        this.year = year == null ? "" : year;
        this.posterUrl = posterUrl == null ? "" : posterUrl;
        this.overview = overview == null ? "" : overview;
    }

    public boolean isSeries() {
        return "tv".equalsIgnoreCase(mediaType);
    }

    public String typeLabel() {
        return isSeries() ? "SERIE" : "PELÍCULA";
    }
}
