package com.cochi.client;

import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.text.Editable;
import android.text.TextWatcher;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class CatalogActivity extends AppCompatActivity {

    public static final String EXTRA_SOURCE = "cochi.extra.CATALOG_SOURCE";

    private RecyclerView itemRecycler;
    private int gridSpan = 1;
    private ChannelListAdapter adapter;
    private LinearLayout categoryRow;
    private ProgressBar loading;
    private TextView emptyText;
    private EditText searchInput;
    private CatalogSource source = CatalogSource.MOVIES;
    private List<Channel> allItems = new ArrayList<>();
    private String activeCategory = "Todos";
    private String searchText = "";
    private boolean firstResume = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog);
        ManagedTheme.applyToActivity(this);
        applyTvVisuals();

        String sourceName = getIntent().getStringExtra(EXTRA_SOURCE);
        if (sourceName != null) {
            try { source = CatalogSource.valueOf(sourceName); } catch (Exception ignored) {}
        }

        itemRecycler = findViewById(R.id.itemRecycler);
        categoryRow = findViewById(R.id.categoryRow);
        loading = findViewById(R.id.catalogLoading);
        emptyText = findViewById(R.id.emptyText);
        searchInput = findViewById(R.id.searchInput);

        gridSpan = isTelevision() ? 4 : 1;
        itemRecycler.setLayoutManager(gridSpan > 1
                ? new GridLayoutManager(this, gridSpan)
                : new LinearLayoutManager(this));
        itemRecycler.setHasFixedSize(true);
        if (isTelevision()) itemRecycler.setItemAnimator(null);
        itemRecycler.setItemViewCacheSize(10);
        adapter = new ChannelListAdapter(this, ChannelListAdapter.Mode.CATALOG,
                (position, item) -> open(position, item));
        itemRecycler.setAdapter(adapter);

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                searchText = s == null ? "" : s.toString().trim();
                renderActiveCategory();
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        searchInput.setOnEditorActionListener((v, actionId, event) -> {
            if (adapter != null && adapter.getItemCount() > 0) {
                focusFirstItem();
                return true;
            }
            return false;
        });

        itemRecycler.addOnChildAttachStateChangeListener(new RecyclerView.OnChildAttachStateChangeListener() {
            @Override
            public void onChildViewAttachedToWindow(View view) {
                view.setOnKeyListener((v, keyCode, event) -> {
                    if (!usesVerticalCategories() || event.getAction() != KeyEvent.ACTION_DOWN) return false;
                    if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
                        int position = itemRecycler.getChildAdapterPosition(v);
                        if (gridSpan <= 1 || position == RecyclerView.NO_POSITION || position % gridSpan == 0) {
                            focusActiveCategory();
                            return true;
                        }
                    }
                    return false;
                });
            }

            @Override
            public void onChildViewDetachedFromWindow(View view) {
                view.setOnKeyListener(null);
            }
        });

        TextView title = findViewById(R.id.catalogTitle);
        TextView subtitle = findViewById(R.id.catalogSubtitle);
        title.setText(source == CatalogSource.SERIES ? "SERIES" : "PELÍCULAS");
        subtitle.setText("Elegí una categoría o explorá todo");
        loadCatalog();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (source == CatalogSource.SERIES) {
            if (firstResume) {
                firstResume = false;
            } else {
                // Si Administración bloqueó/reactivó el dispositivo mientras esta pantalla
                // estaba abierta, no dejamos visible un catálogo viejo.
                loadCatalog();
            }
        }
    }

    private void loadCatalog() {
        loading.setVisibility(View.VISIBLE);
        emptyText.setVisibility(View.GONE);
        adapter.submitList(new ArrayList<>());
        categoryRow.removeAllViews();

        CatalogRepository.load(this, source, new CatalogRepository.Callback() {
            @Override
            public void onLoaded(List<Channel> items, boolean fromRemote) {
                if (isFinishing() || isDestroyed()) return;
                try {
                    loading.setVisibility(View.GONE);
                    List<Channel> visible = new ArrayList<>();
                    if (items != null) {
                        for (Channel item : items) {
                            if (item != null && !item.adult) visible.add(item);
                        }
                    }
                    allItems = visible;
                    renderCategories();
                    renderActiveCategory();
                } catch (Exception e) {
                    Log.e("COCHI-CATALOG", "Error renderizando catálogo " + source, e);
                    showCatalogError("No se pudo mostrar esta categoría. Tocá para reintentar.");
                }
            }

            @Override
            public void onError(String message) {
                if (isFinishing() || isDestroyed()) return;
                Log.w("COCHI-CATALOG", "Carga fallida " + source + ": " + message);
                showCatalogError("No se pudo cargar esta categoría. Tocá para reintentar.");
            }
        });
    }

    private void showCatalogError(String message) {
        if (source == CatalogSource.SERIES) {
            allItems = new ArrayList<>();
            CatalogRepository.clearSeriesCache(this);
            categoryRow.removeAllViews();
            adapter.submitList(new ArrayList<>());
        }
        loading.setVisibility(View.GONE);
        itemRecycler.setVisibility(View.GONE);
        emptyText.setText(message);
        emptyText.setVisibility(View.VISIBLE);
        emptyText.setClickable(true);
        emptyText.setFocusable(true);
        emptyText.setOnClickListener(v -> {
            emptyText.setClickable(false);
            loadCatalog();
        });
    }

    private void renderCategories() {
        categoryRow.removeAllViews();

        Map<String, String> categories = new LinkedHashMap<>();
        categories.put("todos", "Todos");
        if (source == CatalogSource.SERIES && !SeriesStore.isEmpty()) {
            for (String display : SeriesStore.getCategoryNames()) {
                if (display == null || display.trim().isEmpty()) continue;
                categories.putIfAbsent(display.toLowerCase(Locale.ROOT), display);
            }
        } else {
            for (Channel item : allItems) {
                if (item == null) continue;
                String display = safeCategory(item.category);
                categories.putIfAbsent(display.toLowerCase(Locale.ROOT), display);
            }
        }

        for (String category : categories.values()) {
            MaterialButton chip = new MaterialButton(this);
            chip.setText(category);
            chip.setAllCaps(false);
            chip.setFocusable(true);
            boolean television = isTelevision();
            chip.setMinHeight(dp(television ? 46 : 44));
            chip.setCornerRadius(dp(television ? 12 : 22));
            chip.setTextSize(television ? 14f : 14f);
            chip.setTag(category);
            chip.setOnClickListener(v -> selectCategory(category));
            chip.setOnFocusChangeListener((v, hasFocus) -> {
                if (television) {
                    // En TV el escalado animado de cada chip competía con el foco del mando.
                    // El contorno cian ya marca la selección sin trabajo extra de composición.
                    chip.animate().cancel();
                    chip.setScaleX(1f);
                    chip.setScaleY(1f);
                } else {
                    chip.animate().scaleX(hasFocus ? 1.04f : 1f).scaleY(hasFocus ? 1.04f : 1f)
                            .setDuration(120).start();
                }
                boolean selected = sameCategory(activeCategory, String.valueOf(chip.getTag()));
                applyCategoryStyle(chip, selected, hasFocus);
            });

            boolean vertical = usesVerticalCategories();
            if (vertical) {
                chip.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                chip.setPadding(dp(18), 0, dp(14), 0);
                chip.setOnKeyListener((v, keyCode, event) -> {
                    if (event.getAction() == KeyEvent.ACTION_DOWN
                            && keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                        focusFirstItem();
                        return true;
                    }
                    return false;
                });
            }

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    vertical ? LinearLayout.LayoutParams.MATCH_PARENT : LinearLayout.LayoutParams.WRAP_CONTENT,
                    dp(vertical ? (television ? 46 : 54) : 44));
            if (vertical) params.setMargins(dp(2), 0, dp(2), dp(television ? 6 : 10));
            else params.setMarginEnd(dp(8));
            chip.setLayoutParams(params);
            if (vertical && categoryRow.getChildCount() == 0) {
                int generatedId = View.generateViewId();
                chip.setId(generatedId);
                searchInput.setNextFocusDownId(generatedId);
                chip.setNextFocusUpId(R.id.searchInput);
            }
            categoryRow.addView(chip);
        }
        updateCategorySelection();
        if (isTelevision() && categoryRow.getChildCount() > 0) {
            View firstCategory = categoryRow.getChildAt(0);
            firstCategory.post(firstCategory::requestFocus);
        }
    }

    private void selectCategory(String category) {
        activeCategory = category;
        renderActiveCategory();
        updateCategorySelection();
    }

    private void updateCategorySelection() {
        for (int i = 0; i < categoryRow.getChildCount(); i++) {
            View child = categoryRow.getChildAt(i);
            if (!(child instanceof MaterialButton)) continue;
            MaterialButton button = (MaterialButton) child;
            boolean selected = sameCategory(activeCategory, String.valueOf(button.getTag()));
            applyCategoryStyle(button, selected, button.hasFocus());
        }
    }

    private void applyCategoryStyle(MaterialButton button, boolean selected, boolean focused) {
        boolean television = isTelevision();
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                selected ? ManagedTheme.selection(this) : ManagedTheme.button(this)));
        button.setTextColor(ManagedTheme.text(this));
        button.setStrokeColor(android.content.res.ColorStateList.valueOf(
                focused ? ManagedTheme.primary(this) : (selected ? ManagedTheme.primary(this) : ManagedTheme.border(this))));
        button.setStrokeWidth(dp(focused ? 3 : selected ? 2 : television ? 1 : 2));
    }

    private void renderActiveCategory() {
        List<Channel> visible = getVisibleItems();
        ChannelStore.setActiveChannels(visible);
        render(visible);
    }

    private List<Channel> getVisibleItems() {
        List<Channel> visible = new ArrayList<>();
        String query = searchText == null ? "" : searchText.trim().toLowerCase(Locale.ROOT);
        for (Channel item : allItems) {
            if (item == null) continue;
            boolean categoryMatches = !query.isEmpty() || (source == CatalogSource.SERIES
                    ? SeriesStore.belongsToCategory(item.id, activeCategory)
                    : ("Todos".equalsIgnoreCase(activeCategory)
                        || sameCategory(activeCategory, item.category)));
            if (!categoryMatches) continue;

            String name = item.name == null ? "" : item.name.toLowerCase(Locale.ROOT);
            if (query.isEmpty() || name.contains(query)) visible.add(item);
        }
        return visible;
    }

    private void render(List<Channel> items) {
        if (items.isEmpty()) {
            adapter.submitList(items);
            emptyText.setText(searchText == null || searchText.trim().isEmpty()
                    ? "No hay contenido en esta categoría."
                    : "No se encontraron resultados para \"" + searchText.trim() + "\".");
            emptyText.setVisibility(View.VISIBLE);
            itemRecycler.setVisibility(View.GONE);
            return;
        }

        emptyText.setVisibility(View.GONE);
        itemRecycler.setVisibility(View.VISIBLE);
        adapter.submitList(items);
        itemRecycler.scrollToPosition(0);
        ImageLoader.prefetch(this, items, isTelevision() ? 8 : 14);
    }

    private void open(int index, Channel item) {
        if (source == CatalogSource.SERIES) {
            SeriesStore.SeriesInfo series = SeriesStore.getSeries(item.id);
            if (series == null || series.episodeCount() == 0) {
                Toast.makeText(this, "Esta serie no tiene capítulos disponibles", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(this, SeriesDetailActivity.class);
            intent.putExtra(SeriesDetailActivity.EXTRA_SERIES_ID, item.id);
            startActivity(intent);
            return;
        }

        // Al volver desde otra pantalla el store puede haber cambiado; lo restauramos
        // con la categoría visible antes de abrir una película.
        List<Channel> visible = getVisibleItems();
        ChannelStore.setActiveChannels(visible);
        if (index < 0 || index >= visible.size()) {
            Toast.makeText(this, "Contenido no disponible", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent intent = new Intent(this, PlayerActivity.class);
        intent.putExtra(PlayerActivity.EXTRA_STORE_ITEM, true);
        intent.putExtra(PlayerActivity.EXTRA_CHANNEL_INDEX, index);
        intent.putExtra(PlayerActivity.EXTRA_CATALOG_SOURCE, source.name());
        startActivity(intent);
    }


    private void applyTvVisuals() {
        if (!isTelevision()) return;
        int bg = ManagedTheme.background(this);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setBackgroundColor(bg);
    }

    private boolean usesVerticalCategories() {
        return categoryRow != null && categoryRow.getOrientation() == LinearLayout.VERTICAL;
    }

    private void focusFirstItem() {
        if (adapter == null || adapter.getItemCount() == 0) return;
        itemRecycler.scrollToPosition(0);
        itemRecycler.post(() -> {
            RecyclerView.ViewHolder holder = itemRecycler.findViewHolderForAdapterPosition(0);
            if (holder != null) holder.itemView.requestFocus();
        });
    }

    private void focusActiveCategory() {
        for (int i = 0; i < categoryRow.getChildCount(); i++) {
            View child = categoryRow.getChildAt(i);
            if (sameCategory(activeCategory, String.valueOf(child.getTag()))) {
                child.requestFocus();
                return;
            }
        }
        if (categoryRow.getChildCount() > 0) categoryRow.getChildAt(0).requestFocus();
    }

    private boolean sameCategory(String a, String b) {
        return safeCategory(a).equalsIgnoreCase(safeCategory(b));
    }

    private String safeCategory(String value) {
        if (value == null || value.trim().isEmpty()) return "General";
        return value.trim();
    }

    private boolean isTelevision() {
        UiModeManager uiModeManager = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        return (uiModeManager != null
                && uiModeManager.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION)
                || getPackageManager().hasSystemFeature("android.software.leanback");
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
