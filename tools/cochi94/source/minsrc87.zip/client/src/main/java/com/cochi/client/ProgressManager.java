package com.cochi.client;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Guarda el avance local por usuario. Luego podrá sincronizarse con el backend. */
public final class ProgressManager {
    private static final String PREFIX = "entry:";
    private static final String WATCHED_PREFIX = "watched:";
    private static final long MIN_SAVE_POSITION_MS = 10_000L;
    private static final double COMPLETE_RATIO = 0.95d;

    private ProgressManager() {}

    public static final class Entry {
        public final String source;
        public final String itemId;
        public final String name;
        public final String logo;
        public final long positionMs;
        public final long durationMs;
        public final long updatedAt;

        Entry(String source, String itemId, String name, String logo,
              long positionMs, long durationMs, long updatedAt) {
            this.source = source;
            this.itemId = itemId;
            this.name = name;
            this.logo = logo;
            this.positionMs = positionMs;
            this.durationMs = durationMs;
            this.updatedAt = updatedAt;
        }

        public int percent() {
            if (durationMs <= 0) return 0;
            return Math.max(0, Math.min(100, (int) Math.round(positionMs * 100d / durationMs)));
        }
    }

    public static void save(Context context, CatalogSource source, Channel item,
                            long positionMs, long durationMs) {
        if (context == null || source == null || item == null) return;
        if (source != CatalogSource.MOVIES && source != CatalogSource.SERIES) return;
        if (durationMs <= 0 || positionMs < MIN_SAVE_POSITION_MS) return;

        // En Series, "Continuar viendo" representa a la serie completa:
        // debe existir una sola tarjeta y siempre corresponder al último episodio reproducido.
        // Antes de guardar el episodio actual eliminamos cualquier progreso anterior
        // perteneciente a la misma serie.
        if (source == CatalogSource.SERIES) {
            removeOtherSeriesProgress(context, item.id);
        }

        boolean completed = (double) positionMs / (double) durationMs >= COMPLETE_RATIO;
        if (completed) {
            markWatched(context, source, item.id);

            // Películas mantienen el comportamiento histórico: al completarlas
            // salen de "Continuar viendo". En Series conservamos el último episodio
            // (incluso completado) hasta que el usuario empiece otro capítulo.
            if (source == CatalogSource.MOVIES) {
                remove(context, source, item.id);
                return;
            }
        } else {
            // Si se vuelve a reproducir un capítulo ya visto y se deja a mitad,
            // pasa nuevamente a "Continuar viendo".
            clearWatched(context, source, item.id);
        }

        try {
            JSONObject object = new JSONObject();
            object.put("source", source.name());
            object.put("itemId", safe(item.id));
            object.put("name", safe(item.name));
            object.put("logo", safe(item.logo));
            object.put("positionMs", completed ? durationMs : positionMs);
            object.put("durationMs", durationMs);
            object.put("updatedAt", System.currentTimeMillis());
            prefs(context).edit().putString(key(source, item.id), object.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    public static Entry get(Context context, CatalogSource source, String itemId) {
        String json = prefs(context).getString(key(source, itemId), null);
        return parse(json);
    }

    public static void remove(Context context, CatalogSource source, String itemId) {
        prefs(context).edit().remove(key(source, itemId)).apply();
    }

    /**
     * Mantiene una única entrada de progreso por serie.
     * La pertenencia se resuelve con SeriesStore, por lo que no depende del nombre
     * visible del capítulo ni de convenciones del ID.
     */
    private static void removeOtherSeriesProgress(Context context, String currentEpisodeId) {
        SeriesStore.SeriesInfo series = SeriesStore.findSeriesByEpisodeId(currentEpisodeId);
        if (series == null) return;

        SharedPreferences preferences = prefs(context);
        SharedPreferences.Editor editor = null;
        for (Channel episode : series.allEpisodes()) {
            if (episode == null || safe(episode.id).equals(safe(currentEpisodeId))) continue;
            String episodeKey = key(CatalogSource.SERIES, episode.id);
            if (preferences.contains(episodeKey)) {
                if (editor == null) editor = preferences.edit();
                editor.remove(episodeKey);
            }
        }
        if (editor != null) editor.apply();
    }


    public static void markWatched(Context context, CatalogSource source, String itemId) {
        if (context == null || source == null || itemId == null || itemId.trim().isEmpty()) return;
        prefs(context).edit().putBoolean(watchedKey(source, itemId), true).apply();
    }

    public static boolean isWatched(Context context, CatalogSource source, String itemId) {
        if (context == null || source == null || itemId == null) return false;
        return prefs(context).getBoolean(watchedKey(source, itemId), false);
    }

    public static void clearWatched(Context context, CatalogSource source, String itemId) {
        if (context == null || source == null || itemId == null) return;
        prefs(context).edit().remove(watchedKey(source, itemId)).apply();
    }

    public static List<Entry> getAll(Context context) {
        List<Entry> entries = new ArrayList<>();
        for (Map.Entry<String, ?> pref : prefs(context).getAll().entrySet()) {
            if (!pref.getKey().startsWith(PREFIX) || !(pref.getValue() instanceof String)) continue;
            Entry parsed = parse((String) pref.getValue());
            if (parsed != null) entries.add(parsed);
        }
        Collections.sort(entries, Comparator.comparingLong((Entry e) -> e.updatedAt).reversed());

        // Compatibilidad con instalaciones anteriores: si quedaron varios capítulos
        // de la misma serie guardados, mostramos únicamente el más reciente.
        List<Entry> filtered = new ArrayList<>();
        Set<String> seriesSeen = new HashSet<>();
        for (Entry entry : entries) {
            if (!CatalogSource.SERIES.name().equals(entry.source)) {
                filtered.add(entry);
                continue;
            }
            SeriesStore.SeriesInfo series = SeriesStore.findSeriesByEpisodeId(entry.itemId);
            if (series == null || series.id.isEmpty()) {
                filtered.add(entry);
                continue;
            }
            if (seriesSeen.add(series.id)) filtered.add(entry);
        }
        return filtered;
    }

    public static int count(Context context) {
        return getAll(context).size();
    }

    private static Entry parse(String json) {
        if (json == null || json.trim().isEmpty()) return null;
        try {
            JSONObject o = new JSONObject(json);
            return new Entry(
                    o.optString("source", CatalogSource.MOVIES.name()),
                    o.optString("itemId", ""),
                    o.optString("name", "Contenido"),
                    o.optString("logo", ""),
                    o.optLong("positionMs", 0L),
                    o.optLong("durationMs", 0L),
                    o.optLong("updatedAt", 0L));
        } catch (Exception ignored) {
            return null;
        }
    }

    private static SharedPreferences prefs(Context context) {
        String client = SessionManager.clientId(context).replaceAll("[^A-Za-z0-9_.-]", "_");
        return context.getSharedPreferences("cochi_progress_" + client, Context.MODE_PRIVATE);
    }

    private static String key(CatalogSource source, String itemId) {
        return PREFIX + source.name() + ":" + safe(itemId);
    }

    private static String watchedKey(CatalogSource source, String itemId) {
        return WATCHED_PREFIX + source.name() + ":" + safe(itemId);
    }

    private static String safe(String value) {
        return value == null ? "" : value.trim();
    }
}
