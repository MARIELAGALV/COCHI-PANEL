@echo off
setlocal
set GRADLE_VERSION=8.13
set DIST_DIR=%~dp0.gradle-dist\gradle-%GRADLE_VERSION%
set ZIP_FILE=%~dp0.gradle-dist\gradle-%GRADLE_VERSION%-bin.zip

if not exist "%DIST_DIR%\bin\gradle.bat" (
  echo Preparando Gradle %GRADLE_VERSION%...
  if not exist "%~dp0.gradle-dist" mkdir "%~dp0.gradle-dist"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP_FILE%'"
  if errorlevel 1 exit /b 1
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%ZIP_FILE%' '%~dp0.gradle-dist'"
  if errorlevel 1 exit /b 1
)

call "%DIST_DIR%\bin\gradle.bat" %*
endlocal
