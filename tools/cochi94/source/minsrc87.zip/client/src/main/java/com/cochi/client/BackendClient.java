package com.cochi.client;

import android.content.Context;
import android.os.Build;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Cliente HTTPS mínimo para CO-CHI PANEL. No contiene URLs de catálogos privados. */
public final class BackendClient {
    private static final int CONNECT_TIMEOUT_MS = 12_000;
    private static final int READ_TIMEOUT_MS = 20_000;

    private BackendClient() {}

    public static JSONObject registerDevice(Context context) throws Exception {
        JSONObject body = new JSONObject();
        body.put("deviceUid", SessionManager.deviceId(context));
        body.put("deviceName", Build.MANUFACTURER + " " + Build.MODEL);
        body.put("platform", isTelevision(context) ? "android-tv" : "android");
        return requestJson(context, "POST", "/api/client-device/register", null, body);
    }

    public static JSONObject deviceStatus(Context context, String secret) throws Exception {
        JSONObject body = new JSONObject();
        body.put("deviceUid", SessionManager.deviceId(context));
        body.put("deviceSecret", secret == null ? "" : secret);
        return requestJson(context, "POST", "/api/client-device/status", null, body);
    }

    public static JSONObject createSession(Context context, String secret) throws Exception {
        JSONObject body = new JSONObject();
        body.put("deviceUid", SessionManager.deviceId(context));
        body.put("deviceSecret", secret == null ? "" : secret);
        return requestJson(context, "POST", "/api/client-device/session", null, body);
    }


    public static JSONObject verifyAdultPin(Context context, String pin) throws Exception {
        String token = SessionManager.ensureSessionTokenBlocking(context);
        JSONObject body = new JSONObject();
        body.put("pin", pin == null ? "" : pin.trim());
        return requestJson(context, "POST", "/api/client-device/adult/verify", token, body);
    }

    public static JSONObject searchMedia(Context context, String query) throws Exception {
        String token = SessionManager.ensureSessionTokenBlocking(context);
        String encoded = URLEncoder.encode(query == null ? "" : query.trim(), StandardCharsets.UTF_8.name());
        return requestJson(context, "GET", "/api/client-device/media-search?q=" + encoded, token, null);
    }

    public static JSONObject clientConfig(Context context) throws Exception {
        String token = SessionManager.ensureSessionTokenBlocking(context);
        return requestJson(context, "GET", "/api/client-device/config", token, null);
    }

    /**
     * Resuelve una URL privada de Películas/Series a través del PANEL.
     * La APK nunca recibe ni almacena MEDIA_ISSUER_KEY.
     */
    public static String resolvePrivateMediaUrl(Context context, String sourceUrl) throws Exception {
        String token = SessionManager.ensureSessionTokenBlocking(context);
        JSONObject body = new JSONObject();
        body.put("url", sourceUrl == null ? "" : sourceUrl.trim());
        JSONObject response = requestJson(context, "POST", "/api/client-device/media-signed-url", token, body);
        String signedUrl = response.optString("url", "").trim();
        if (signedUrl.isEmpty()) throw new IllegalStateException("El PANEL no devolvió URL de reproducción");
        return signedUrl;
    }

    public static boolean requiresPrivateMediaResolution(String sourceUrl) {
        String value = sourceUrl == null ? "" : sourceUrl.trim();
        if (value.regionMatches(true, 0, "cochi-private://", 0, "cochi-private://".length())) return true;
        String lower = value.toLowerCase(java.util.Locale.ROOT);
        return lower.startsWith("https://github.com/") && lower.contains("/releases/download/");
    }

    public static JSONObject mediaPlaybackOptions(Context context, WebSearchResult result) throws Exception {
        String token = SessionManager.ensureSessionTokenBlocking(context);
        if (result == null) throw new IllegalArgumentException("Resultado requerido");
        StringBuilder path = new StringBuilder("/api/client-device/media-playback-options?");
        path.append("media_type=").append(URLEncoder.encode(result.mediaType, StandardCharsets.UTF_8.name()));
        path.append("&media_id=").append(result.tmdbId);
        path.append("&title=").append(URLEncoder.encode(result.title, StandardCharsets.UTF_8.name()));
        path.append("&original_title=").append(URLEncoder.encode(result.originalTitle, StandardCharsets.UTF_8.name()));
        path.append("&year=").append(URLEncoder.encode(result.year, StandardCharsets.UTF_8.name()));
        return requestJson(context, "GET", path.toString(), token, null);
    }

    public static String downloadProtectedCatalog(Context context, CatalogSource source) throws Exception {
        String token = SessionManager.ensureSessionTokenBlocking(context);
        String key;
        switch (source) {
            case TV1: key = "tv1"; break;
            case TV2: key = "tv2"; break;
            case MOVIES: key = "movies"; break;
            case SERIES: key = "series"; break;
            default: throw new IllegalArgumentException("Fuente no soportada");
        }
        if (source == CatalogSource.TV1 || source == CatalogSource.TV2) {
            // v0.23.33: migración segura al cifrado TV V2.
            // Primero intentamos ECDH + AES-GCM. Si el teléfono, el proveedor
            // criptográfico o el backend rechazan el intercambio, reintentamos
            // automáticamente el endpoint histórico. De esta forma una prueba
            // de Crypto V2 nunca deja TV1/TV2 inutilizables.
            try {
                TvCatalogCrypto.RequestContext crypto = TvCatalogCrypto.begin(key);
                Map<String, String> headers = new LinkedHashMap<>(crypto.requestHeaders());
                if (source == CatalogSource.TV2) headers.put("X-COCHI-TV2-ID-CATALOG", "1");
                String response = requestText(
                        context, "GET", "/api/content/" + key, token, null, headers);
                return crypto.decryptOrPass(response);
            } catch (Exception cryptoError) {
                if (source == CatalogSource.TV2) {
                    Map<String, String> headers = new LinkedHashMap<>();
                    headers.put("X-COCHI-TV2-ID-CATALOG", "1");
                    return requestText(context, "GET", "/api/content/" + key, token, null, headers);
                }
                return requestText(context, "GET", "/api/content/" + key, token, null);
            }
        }
        return requestText(context, "GET", "/api/content/" + key, token, null);
    }

    public static String downloadTv2ResolvedPlayback(Context context, String sourceId) throws Exception {
        String token = SessionManager.ensureSessionTokenBlocking(context);
        String id = sourceId == null ? "" : sourceId.trim();
        if (!id.matches("(?i)^TV2_[A-Z0-9_-]{4,64}$")) throw new IllegalArgumentException("ID TV2 inválido");
        try {
            TvCatalogCrypto.RequestContext crypto = TvCatalogCrypto.begin("tv2");
            String response = requestText(context, "GET", "/api/content/tv2/resolve/" + id, token, null, crypto.requestHeaders());
            return crypto.decryptOrPass(response);
        } catch (Exception cryptoError) {
            return requestText(context, "GET", "/api/content/tv2/resolve/" + id, token, null);
        }
    }

    private static JSONObject requestJson(Context context, String method, String path, String token, JSONObject body) throws Exception {
        return new JSONObject(requestText(context, method, path, token, body));
    }

    private static String requestText(Context context, String method, String path, String token, JSONObject body) throws Exception {
        return requestText(context, method, path, token, body, Collections.emptyMap());
    }

    private static String requestText(Context context, String method, String path, String token, JSONObject body,
                                      Map<String, String> extraHeaders) throws Exception {
        if (!BuildConfig.DEBUG && !AppIntegrity.isRuntimeAllowed(context)) {
            throw new SecurityException("Instalación no autorizada");
        }
        HttpURLConnection connection = (HttpURLConnection) new URL(RuntimeStrings.panelBaseUrl() + path).openConnection();
        connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
        connection.setReadTimeout(READ_TIMEOUT_MS);
        connection.setRequestMethod(method);
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("Cache-Control", "no-cache");
        connection.setRequestProperty("User-Agent", "CO-CHI-Android/" + BuildConfig.VERSION_NAME);
        connection.setRequestProperty("X-COCHI-Package", context.getPackageName());
        connection.setRequestProperty("X-COCHI-Version", BuildConfig.VERSION_NAME);
        String signature = AppIntegrity.signatureSha256(context);
        if (!signature.isEmpty()) connection.setRequestProperty("X-COCHI-Signature", signature);
        connection.setRequestProperty("X-COCHI-Runtime", AppIntegrity.runtimeState(context));
        if (extraHeaders != null) {
            for (Map.Entry<String, String> header : extraHeaders.entrySet()) {
                if (header.getKey() != null && header.getValue() != null) {
                    connection.setRequestProperty(header.getKey(), header.getValue());
                }
            }
        }
        if (token != null && !token.trim().isEmpty()) {
            connection.setRequestProperty("Authorization", "Bearer " + token.trim());
        }
        if (body != null) {
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            byte[] payload = body.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(payload.length);
            try (OutputStream out = connection.getOutputStream()) { out.write(payload); }
        }

        int status = connection.getResponseCode();
        InputStream input = status >= 200 && status < 300
                ? connection.getInputStream() : connection.getErrorStream();
        String text = readAll(input);
        connection.disconnect();
        if (status < 200 || status >= 300) {
            String message = "HTTP " + status;
            try {
                JSONObject error = new JSONObject(text);
                String detail = error.optString("error", error.optString("reason", ""));
                if (!detail.isEmpty()) message += ": " + detail;
            } catch (Exception ignored) {}
            throw new BackendException(status, message);
        }
        return text;
    }

    private static String readAll(InputStream input) throws Exception {
        if (input == null) return "{}";
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) >= 0) out.write(buffer, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    private static boolean isTelevision(Context context) {
        return context.getPackageManager().hasSystemFeature("android.software.leanback")
                || context.getPackageManager().hasSystemFeature("android.hardware.type.television");
    }

    public static final class BackendException extends Exception {
        public final int statusCode;
        BackendException(int statusCode, String message) { super(message); this.statusCode = statusCode; }
    }
}
