package com.cochi.client;

import android.content.Intent;
import android.app.UiModeManager;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Ficha premium de Series: información, temporadas, capítulos y continuar viendo.
 */
public final class SeriesDetailActivity extends AppCompatActivity {
    public static final String EXTRA_SERIES_ID = "cochi.extra.SERIES_DETAIL_ID";

    private SeriesStore.SeriesInfo series;
    private LinearLayout seasonRow;
    private RecyclerView episodeRecycler;
    private EpisodeListAdapter adapter;
    private TextView episodesLabel;
    private MaterialButton continueButton;
    private MaterialButton startButton;
    private int selectedSeasonIndex = 0;
    private volatile boolean accessCheckRunning = false;
    private Runnable pendingAccessAction;
    private static final long RECENT_ACCESS_WINDOW_MS = 30_000L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_series_detail);
        ManagedTheme.applyToActivity(this);
        applyTvVisuals();

        String seriesId = getIntent().getStringExtra(EXTRA_SERIES_ID);
        series = SeriesStore.getSeries(seriesId);
        if (series == null || series.seasons.isEmpty()) {
            Toast.makeText(this, "La serie ya no está disponible", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        ImageView poster = findViewById(R.id.seriesPoster);
        ImageView backdrop = findViewById(R.id.seriesBackdrop);
        TextView title = findViewById(R.id.seriesTitle);
        TextView meta = findViewById(R.id.seriesMeta);
        TextView synopsis = findViewById(R.id.seriesSynopsis);
        seasonRow = findViewById(R.id.seasonRow);
        episodeRecycler = findViewById(R.id.episodeRecycler);
        episodesLabel = findViewById(R.id.episodesLabel);
        continueButton = findViewById(R.id.continueButton);
        startButton = findViewById(R.id.startButton);

        ImageLoader.load(series.poster, poster);
        ImageLoader.load(series.backdrop.isEmpty() ? series.poster : series.backdrop, backdrop);
        title.setText(series.name);
        meta.setText(buildMeta());
        synopsis.setText(series.synopsis.isEmpty()
                ? "Elegí una temporada para ver sus capítulos."
                : series.synopsis);

        episodeRecycler.setLayoutManager(isTelevision()
                ? new GridLayoutManager(this, 2)
                : new LinearLayoutManager(this));
        episodeRecycler.setHasFixedSize(true);
        if (isTelevision()) episodeRecycler.setItemAnimator(null);
        episodeRecycler.setItemViewCacheSize(10);
        adapter = new EpisodeListAdapter(this, this::openEpisode);
        episodeRecycler.setAdapter(adapter);

        ProgressManager.Entry latest = latestProgress();
        if (latest != null) selectedSeasonIndex = seasonIndexForEpisode(latest.itemId);
        else selectedSeasonIndex = firstSeasonWithUnwatchedEpisode();
        if (selectedSeasonIndex < 0) selectedSeasonIndex = 0;

        continueButton.setOnClickListener(v -> playContinueTarget());
        startButton.setOnClickListener(v -> playFromBeginning());

        renderSeasonButtons();
        renderSelectedSeason();
        refreshContinueButton();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // CatalogRepository ya validó el acceso al entrar a Series. Evitamos repetir
        // inmediatamente la misma consulta de red al abrir la ficha.
        if (!SessionManager.wasAccessRecentlyValidated(RECENT_ACCESS_WINDOW_MS)) {
            validateSeriesAccess(false, null);
        }
        if (series != null && adapter != null) {
            renderSelectedSeason();
            refreshContinueButton();
        }
    }

    private String buildMeta() {
        List<String> parts = new ArrayList<>();
        if (!series.year.isEmpty()) parts.add(series.year);
        if (!series.genre.isEmpty()) parts.add(series.genre);
        parts.add(series.seasons.size() == 1 ? "1 temporada" : series.seasons.size() + " temporadas");
        parts.add(series.episodeCount() == 1 ? "1 capítulo" : series.episodeCount() + " capítulos");
        return android.text.TextUtils.join("  •  ", parts);
    }

    private void renderSeasonButtons() {
        seasonRow.removeAllViews();
        for (int i = 0; i < series.seasons.size(); i++) {
            final int index = i;
            SeriesStore.Season season = series.seasons.get(i);
            MaterialButton button = new MaterialButton(this);
            button.setText(season.name);
            button.setAllCaps(false);
            button.setFocusable(true);
            boolean television = isTelevision();
            button.setTextSize(television ? 14f : 14f);
            button.setTypeface(Typeface.DEFAULT_BOLD);
            button.setCornerRadius(dp(television ? 12 : 18));
            button.setTag(index);
            button.setOnClickListener(v -> selectSeason(index));
            button.setOnFocusChangeListener((v, focused) -> applySeasonStyle(button, index, focused));
            button.setOnKeyListener((v, keyCode, event) -> {
                if (event.getAction() == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                    focusFirstEpisode();
                    return true;
                }
                return false;
            });
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, dp(television ? 46 : 46));
            params.setMarginEnd(dp(television ? 8 : 9));
            button.setLayoutParams(params);
            seasonRow.addView(button);
            applySeasonStyle(button, index, false);
        }
    }

    private void selectSeason(int index) {
        if (index < 0 || index >= series.seasons.size()) return;
        selectedSeasonIndex = index;
        for (int i = 0; i < seasonRow.getChildCount(); i++) {
            View child = seasonRow.getChildAt(i);
            if (child instanceof MaterialButton) {
                applySeasonStyle((MaterialButton) child, i, child.hasFocus());
            }
        }
        renderSelectedSeason();
        focusFirstEpisode();
    }

    private void applySeasonStyle(MaterialButton button, int index, boolean focused) {
        boolean selected = index == selectedSeasonIndex;
        boolean television = isTelevision();
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                selected ? ManagedTheme.selection(this) : ManagedTheme.button(this)));
        button.setTextColor(ManagedTheme.text(this));
        button.setStrokeColor(android.content.res.ColorStateList.valueOf(
                focused ? ManagedTheme.primary(this) : (selected ? ManagedTheme.primary(this) : ManagedTheme.border(this))));
        button.setStrokeWidth(dp(focused ? 3 : selected ? 2 : 1));
    }

    private void renderSelectedSeason() {
        if (selectedSeasonIndex < 0 || selectedSeasonIndex >= series.seasons.size()) return;
        SeriesStore.Season season = series.seasons.get(selectedSeasonIndex);
        episodesLabel.setText((season.name + "  ·  " + season.episodes.size()
                + (season.episodes.size() == 1 ? " CAPÍTULO" : " CAPÍTULOS")).toUpperCase(Locale.ROOT));

        List<EpisodeListAdapter.Row> rows = new ArrayList<>();
        for (Channel episode : season.episodes) {
            String status = "";
            ProgressManager.Entry progress = ProgressManager.get(this, CatalogSource.SERIES, episode.id);
            if (progress != null) {
                status = "Continuar · " + progress.percent() + "%";
            } else if (ProgressManager.isWatched(this, CatalogSource.SERIES, episode.id)) {
                status = "✓ Visto";
            }
            rows.add(new EpisodeListAdapter.Row(episode, status));
        }
        adapter.submitList(rows);
        ImageLoader.prefetch(this, season.episodes, isTelevision() ? 6 : 10);
    }

    private void refreshContinueButton() {
        ProgressManager.Entry latest = latestProgress();
        if (latest != null) {
            Channel episode = findEpisode(latest.itemId);
            if (episode != null) {
                continueButton.setText("CONTINUAR · EP " + String.format(Locale.US, "%02d", episode.number));
                continueButton.setEnabled(true);
                return;
            }
        }

        Channel next = firstUnwatchedEpisode();
        if (next != null) {
            continueButton.setText("REPRODUCIR · EP " + String.format(Locale.US, "%02d", next.number));
            continueButton.setEnabled(true);
        } else {
            continueButton.setText("VER DE NUEVO");
            continueButton.setEnabled(!series.allEpisodes().isEmpty());
        }
    }

    private void playContinueTarget() {
        ProgressManager.Entry latest = latestProgress();
        if (latest != null) {
            Channel episode = findEpisode(latest.itemId);
            if (episode != null) {
                launchEpisode(episode, false, true);
                return;
            }
        }
        Channel next = firstUnwatchedEpisode();
        if (next == null && !series.allEpisodes().isEmpty()) next = series.allEpisodes().get(0);
        if (next != null) launchEpisode(next, false, false);
    }

    private void playFromBeginning() {
        List<Channel> all = series.allEpisodes();
        if (all.isEmpty()) return;
        launchEpisode(all.get(0), true, false);
    }

    private void openEpisode(Channel episode) {
        launchEpisode(episode, false, false);
    }

    private void launchEpisode(Channel episode, boolean forceStart, boolean autoResume) {
        Runnable launch = () -> {
            List<Channel> all = series.allEpisodes();
            int index = indexOfEpisode(all, episode.id);
            if (index < 0) return;
            ChannelStore.setActiveChannels(all);
            Intent intent = new Intent(this, PlayerActivity.class);
            intent.putExtra(PlayerActivity.EXTRA_STORE_ITEM, true);
            intent.putExtra(PlayerActivity.EXTRA_CHANNEL_INDEX, index);
            intent.putExtra(PlayerActivity.EXTRA_CATALOG_SOURCE, CatalogSource.SERIES.name());
            intent.putExtra(PlayerActivity.EXTRA_FORCE_START, forceStart);
            intent.putExtra(PlayerActivity.EXTRA_AUTO_RESUME, autoResume);
            intent.putExtra(PlayerActivity.EXTRA_AUTO_NEXT_SERIES, true);
            startActivity(intent);
        };

        // Si el PANEL fue validado hace pocos segundos, abrir el capítulo es inmediato.
        // El player mantiene su chequeo real cada 30 s, por lo que no se elimina seguridad.
        if (SessionManager.wasAccessRecentlyValidated(RECENT_ACCESS_WINDOW_MS)) {
            launch.run();
        } else {
            validateSeriesAccess(true, launch);
        }
    }

    private void validateSeriesAccess(boolean showMessage, Runnable onAllowed) {
        if (accessCheckRunning) {
            // Antes se descartaba el clic si onResume ya estaba validando contra el PANEL.
            // En TV eso se sentía como un OK que no respondía. Conservamos la última acción
            // pedida y la ejecutamos apenas termina la validación en curso.
            if (onAllowed != null) pendingAccessAction = onAllowed;
            return;
        }
        accessCheckRunning = true;
        new Thread(() -> {
            boolean allowed = false;
            try {
                allowed = SessionManager.validateAccessBlocking(getApplicationContext());
            } catch (Exception ignored) { }
            final boolean finalAllowed = allowed;
            runOnUiThread(() -> {
                accessCheckRunning = false;
                Runnable pending = pendingAccessAction;
                pendingAccessAction = null;
                if (!finalAllowed) {
                    CatalogRepository.clearSeriesCache(this);
                    if (showMessage || pending != null) {
                        Toast.makeText(this, "Dispositivo bloqueado o sin acceso", Toast.LENGTH_LONG).show();
                    }
                    finish();
                    return;
                }
                if (onAllowed != null) onAllowed.run();
                if (pending != null && pending != onAllowed && !isFinishing()) pending.run();
            });
        }, "cochi-series-access").start();
    }

    private ProgressManager.Entry latestProgress() {
        ProgressManager.Entry best = null;
        for (Channel episode : series.allEpisodes()) {
            ProgressManager.Entry entry = ProgressManager.get(this, CatalogSource.SERIES, episode.id);
            if (entry != null && (best == null || entry.updatedAt > best.updatedAt)) best = entry;
        }
        return best;
    }

    private Channel firstUnwatchedEpisode() {
        for (Channel episode : series.allEpisodes()) {
            ProgressManager.Entry progress = ProgressManager.get(this, CatalogSource.SERIES, episode.id);
            if (progress != null) return episode;
            if (!ProgressManager.isWatched(this, CatalogSource.SERIES, episode.id)) return episode;
        }
        return null;
    }

    private int firstSeasonWithUnwatchedEpisode() {
        for (int i = 0; i < series.seasons.size(); i++) {
            for (Channel episode : series.seasons.get(i).episodes) {
                if (ProgressManager.get(this, CatalogSource.SERIES, episode.id) != null
                        || !ProgressManager.isWatched(this, CatalogSource.SERIES, episode.id)) return i;
            }
        }
        return 0;
    }

    private int seasonIndexForEpisode(String episodeId) {
        for (int i = 0; i < series.seasons.size(); i++) {
            if (indexOfEpisode(series.seasons.get(i).episodes, episodeId) >= 0) return i;
        }
        return 0;
    }

    private Channel findEpisode(String episodeId) {
        for (Channel episode : series.allEpisodes()) {
            if (episode.id.equals(episodeId)) return episode;
        }
        return null;
    }

    private int indexOfEpisode(List<Channel> list, String episodeId) {
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id.equals(episodeId)) return i;
        }
        return -1;
    }

    private void focusFirstEpisode() {
        episodeRecycler.scrollToPosition(0);
        episodeRecycler.post(() -> {
            RecyclerView.ViewHolder holder = episodeRecycler.findViewHolderForAdapterPosition(0);
            if (holder != null) holder.itemView.requestFocus();
        });
    }


    private void applyTvVisuals() {
        if (!isTelevision()) return;
        int bg = ManagedTheme.background(this);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setBackgroundColor(bg);
    }

    private boolean isTelevision() {
        UiModeManager manager = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        return (manager != null && manager.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION)
                || getPackageManager().hasSystemFeature("android.software.leanback");
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
