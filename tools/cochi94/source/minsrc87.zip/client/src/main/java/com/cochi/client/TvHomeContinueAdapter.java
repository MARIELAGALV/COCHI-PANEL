package com.cochi.client;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.List;

/** Presentación TV del progreso existente. No modifica la lógica de Seguir viendo. */
public final class TvHomeContinueAdapter extends RecyclerView.Adapter<TvHomeContinueAdapter.Holder> {
    public interface Listener {
        void onClick(ProgressManager.Entry entry);
    }

    private final Context context;
    private final Listener listener;
    private final List<ProgressManager.Entry> items = new ArrayList<>();

    public TvHomeContinueAdapter(Context context, Listener listener) {
        this.context = context;
        this.listener = listener;
        setHasStableIds(true);
    }

    public void submitList(List<ProgressManager.Entry> next) {
        items.clear();
        if (next != null) {
            int limit = Math.min(8, next.size());
            for (int i = 0; i < limit; i++) items.add(next.get(i));
        }
        notifyDataSetChanged();
    }

    @Override public long getItemId(int position) {
        ProgressManager.Entry e = items.get(position);
        return (e.source + ":" + e.itemId).hashCode();
    }

    @NonNull @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        MaterialCardView card = new MaterialCardView(context);
        card.setRadius(dp(16));
        card.setStrokeColor(ManagedTheme.color(context, R.color.cochi_tv_border_soft));
        card.setStrokeWidth(dp(1));
        card.setCardBackgroundColor(ManagedTheme.color(context, R.color.cochi_tv_surface));
        card.setFocusable(true);
        card.setClickable(true);
        card.setClipToOutline(true);
        RecyclerView.LayoutParams cp = new RecyclerView.LayoutParams(dp(112), dp(159));
        cp.setMarginEnd(dp(12));
        cp.topMargin = dp(4);
        cp.bottomMargin = dp(5);
        card.setLayoutParams(cp);

        FrameLayout frame = new FrameLayout(context);
        ImageView image = new ImageView(context);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        frame.addView(image, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        View scrim = new View(context);
        scrim.setBackgroundResource(R.drawable.tv_card_scrim);
        frame.addView(scrim, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView title = new TextView(context);
        title.setTextColor(ManagedTheme.color(context, R.color.cochi_text));
        title.setTextSize(14f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setMaxLines(2);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        tp.setMargins(dp(9), 0, dp(9), dp(17));
        title.setLayoutParams(tp);
        frame.addView(title);

        ProgressBar progress = new ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(ManagedTheme.colors(context, R.color.cochi_accent));
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(4), Gravity.BOTTOM);
        pp.setMargins(dp(10), 0, dp(10), dp(7));
        progress.setLayoutParams(pp);
        frame.addView(progress);

        card.addView(frame);
        return new Holder(card, image, title, progress);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        ProgressManager.Entry entry = items.get(position);
        holder.title.setText(entry.name);
        holder.progress.setProgress(entry.percent());
        ImageLoader.load(entry.logo, holder.image);
        holder.card.setContentDescription("Seguir viendo " + entry.name);

        holder.card.setOnFocusChangeListener((v, hasFocus) -> {
            holder.card.animate().cancel();
            holder.card.setScaleX(1f);
            holder.card.setScaleY(1f);
            holder.card.setTranslationZ(0f);
            holder.card.setStrokeColor(context.getColor(
                    hasFocus ? R.color.cochi_accent_2 : R.color.cochi_tv_border_soft));
            holder.card.setStrokeWidth(dp(hasFocus ? 3 : 1));
            holder.card.setCardElevation(dp(hasFocus ? 6 : 2));
            holder.card.setCardBackgroundColor(context.getColor(hasFocus ? R.color.cochi_tv_surface_focus : R.color.cochi_tv_surface));
        });

        holder.card.setOnClickListener(v -> {
            int p = holder.getBindingAdapterPosition();
            if (p != RecyclerView.NO_POSITION && listener != null) listener.onClick(items.get(p));
        });
    }

    @Override public int getItemCount() { return items.size(); }

    private int dp(int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    static final class Holder extends RecyclerView.ViewHolder {
        final MaterialCardView card;
        final ImageView image;
        final TextView title;
        final ProgressBar progress;

        Holder(MaterialCardView card, ImageView image, TextView title, ProgressBar progress) {
            super(card);
            this.card = card;
            this.image = image;
            this.title = title;
            this.progress = progress;
        }
    }
}
