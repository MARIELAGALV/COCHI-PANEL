package com.cochi.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Transferencia temporal entre el buscador y la pantalla de servidores. */
public final class PlaybackOptionStore {
    private static List<PlaybackOption> options = Collections.emptyList();
    private static String title = "";
    private static String meta = "";

    private PlaybackOptionStore() { }

    public static synchronized void set(String newTitle, String newMeta, List<PlaybackOption> newOptions) {
        title = newTitle == null ? "" : newTitle;
        meta = newMeta == null ? "" : newMeta;
        options = newOptions == null ? Collections.emptyList() : new ArrayList<>(newOptions);
    }

    public static synchronized List<PlaybackOption> options() { return new ArrayList<>(options); }
    public static synchronized String title() { return title; }
    public static synchronized String meta() { return meta; }
}
