package com.cochi.client;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

/** Pantalla intermedia de Series: muestra los capítulos de una serie seleccionada. */
public final class SeriesEpisodesActivity extends AppCompatActivity {

    public static final String EXTRA_SERIES_ID = "cochi.extra.SERIES_ID";
    public static final String EXTRA_SERIES_NAME = "cochi.extra.SERIES_NAME";

    private RecyclerView itemRecycler;
    private ChannelListAdapter adapter;
    private TextView emptyText;
    private volatile boolean accessCheckRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog);
        ManagedTheme.applyToActivity(this);

        String seriesId = getIntent().getStringExtra(EXTRA_SERIES_ID);
        String seriesName = getIntent().getStringExtra(EXTRA_SERIES_NAME);
        if (seriesName == null || seriesName.trim().isEmpty()) seriesName = "SERIE";

        TextView title = findViewById(R.id.catalogTitle);
        TextView subtitle = findViewById(R.id.catalogSubtitle);
        LinearLayout categoryRow = findViewById(R.id.categoryRow);
        ProgressBar loading = findViewById(R.id.catalogLoading);
        emptyText = findViewById(R.id.emptyText);
        itemRecycler = findViewById(R.id.itemRecycler);

        title.setText(seriesName.toUpperCase());
        subtitle.setText("Elegí un capítulo");
        categoryRow.setVisibility(View.GONE);
        loading.setVisibility(View.GONE);

        List<Channel> episodes = new ArrayList<>(SeriesStore.getEpisodes(seriesId));
        ChannelStore.setActiveChannels(episodes);

        itemRecycler.setLayoutManager(new LinearLayoutManager(this));
        itemRecycler.setHasFixedSize(true);
        itemRecycler.setItemViewCacheSize(10);
        adapter = new ChannelListAdapter(this, ChannelListAdapter.Mode.CATALOG,
                (position, item) -> openEpisode(position));
        itemRecycler.setAdapter(adapter);

        if (episodes.isEmpty()) {
            emptyText.setText("No hay capítulos disponibles para esta serie.");
            emptyText.setVisibility(View.VISIBLE);
            itemRecycler.setVisibility(View.GONE);
        } else {
            emptyText.setVisibility(View.GONE);
            itemRecycler.setVisibility(View.VISIBLE);
            adapter.submitList(episodes);
            ImageLoader.prefetch(this, episodes, 14);
            itemRecycler.post(() -> {
                RecyclerView.ViewHolder holder = itemRecycler.findViewHolderForAdapterPosition(0);
                if (holder != null) holder.itemView.requestFocus();
            });
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        validateSeriesAccess(false, null);
    }

    private void openEpisode(int index) {
        validateSeriesAccess(true, () -> {
            Channel episode = ChannelStore.get(index);
            if (episode == null) {
                Toast.makeText(this, "Capítulo no disponible", Toast.LENGTH_SHORT).show();
                return;
            }
            if (episode.sources != null && episode.sources.size() > 1) {
                showEpisodeSources(index, episode);
            } else {
                startEpisode(index);
            }
        });
    }

    private void showEpisodeSources(int channelIndex, Channel episode) {
        String[] labels = new String[episode.sources.size()];
        for (int i = 0; i < episode.sources.size(); i++) {
            StreamSource source = episode.sources.get(i);
            PlaybackOption option = new PlaybackOption(
                    source.serverLabel.isEmpty() ? "CO-CHI" : source.serverLabel,
                    source.languageLabel, source.subtitlesLabel, source.qualityLabel,
                    source.url, source.type, source.headers, source.drm.clearKeyPairs, source.priority);
            labels[i] = option.groupLabel() + (option.quality.isEmpty() ? "" : " · " + option.quality);
        }
        new AlertDialog.Builder(this)
                .setTitle("Opciones de reproducción")
                .setItems(labels, (dialog, which) -> {
                    if (ChannelStore.selectSourceAt(channelIndex, which)) startEpisode(channelIndex);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void startEpisode(int index) {
        Intent intent = new Intent(this, PlayerActivity.class);
        intent.putExtra(PlayerActivity.EXTRA_STORE_ITEM, true);
        intent.putExtra(PlayerActivity.EXTRA_CHANNEL_INDEX, index);
        intent.putExtra(PlayerActivity.EXTRA_CATALOG_SOURCE, CatalogSource.SERIES.name());
        startActivity(intent);
    }

    private void validateSeriesAccess(boolean showMessage, Runnable onAllowed) {
        if (accessCheckRunning) return;
        accessCheckRunning = true;
        new Thread(() -> {
            boolean allowed = false;
            try { allowed = SessionManager.validateAccessBlocking(getApplicationContext()); } catch (Exception ignored) { }
            final boolean finalAllowed = allowed;
            runOnUiThread(() -> {
                accessCheckRunning = false;
                if (!finalAllowed) {
                    CatalogRepository.clearSeriesCache(this);
                    if (showMessage) Toast.makeText(this, "Dispositivo bloqueado o sin acceso", Toast.LENGTH_LONG).show();
                    finish();
                    return;
                }
                if (onAllowed != null) onAllowed.run();
            });
        }, "cochi-series-access").start();
    }
}
