package com.cochi.client;

import android.app.UiModeManager;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ChannelListAdapter extends RecyclerView.Adapter<ChannelListAdapter.Holder> {

    public interface OnItemClickListener {
        void onItemClick(int position, Channel item);
    }

    public enum Mode {
        TV,
        CATALOG
    }

    private final Context context;
    private final Mode mode;
    private final OnItemClickListener listener;
    private final List<Channel> items = new ArrayList<>();

    public ChannelListAdapter(Context context, Mode mode, OnItemClickListener listener) {
        this.context = context;
        this.mode = mode;
        this.listener = listener;
        setHasStableIds(true);
    }

    public void submitList(List<Channel> next) {
        items.clear();
        if (next != null) items.addAll(next);
        notifyDataSetChanged();
    }

    @Override
    public long getItemId(int position) {
        Channel item = items.get(position);
        if (item.id != null && !item.id.isEmpty()) return item.id.hashCode();
        return position;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        boolean television = isTelevision();
        if (television && mode == Mode.CATALOG) return createTelevisionPosterHolder();
        return createListHolder(television);
    }

    private Holder createTelevisionPosterHolder() {
        MaterialCardView card = new MaterialCardView(context);
        card.setCardBackgroundColor(ManagedTheme.color(context, R.color.cochi_tv_surface));
        card.setRadius(dp(18));
        card.setStrokeColor(ManagedTheme.color(context, R.color.cochi_tv_border_soft));
        card.setStrokeWidth(dp(1));
        card.setFocusable(true);
        card.setClickable(true);
        card.setClipToOutline(true);

        RecyclerView.LayoutParams cp = new RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(276));
        cp.setMargins(dp(7), dp(7), dp(7), dp(10));
        card.setLayoutParams(cp);

        FrameLayout frame = new FrameLayout(context);
        ImageView image = new ImageView(context);
        image.setImageResource(R.drawable.ic_cochi);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        frame.addView(image, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        View scrim = new View(context);
        scrim.setBackgroundResource(R.drawable.tv_card_scrim);
        frame.addView(scrim, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout text = new LinearLayout(context);
        text.setOrientation(LinearLayout.VERTICAL);
        text.setPadding(dp(12), dp(10), dp(12), dp(13));
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        text.setLayoutParams(tp);

        TextView name = new TextView(context);
        name.setTextColor(ManagedTheme.color(context, R.color.cochi_text));
        name.setTextSize(16f);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setMaxLines(2);
        text.addView(name);

        TextView category = new TextView(context);
        category.setTextColor(ManagedTheme.color(context, R.color.cochi_accent_2));
        category.setTextSize(11f);
        category.setMaxLines(1);
        text.addView(category);

        frame.addView(text);
        card.addView(frame);
        return new Holder(card, image, null, name, category, null);
    }

    private Holder createListHolder(boolean television) {
        boolean tv = mode == Mode.TV;

        int cardHeight;
        int posterWidth;
        int posterHeight;
        if (tv) {
            cardHeight = television ? 98 : 82;
            posterWidth = television ? 58 : 58;
            posterHeight = television ? 58 : 58;
        } else {
            cardHeight = 156;
            posterWidth = 88;
            posterHeight = 132;
        }

        MaterialCardView card = new MaterialCardView(context);
        card.setCardBackgroundColor(ManagedTheme.button(context));
        card.setRadius(dp(television ? 17 : 18));
        card.setStrokeColor(ManagedTheme.border(context));
        card.setStrokeWidth(dp(television ? 1 : 2));
        card.setFocusable(true);
        card.setClickable(true);

        RecyclerView.LayoutParams cardParams = new RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(cardHeight));
        if (television && tv) cardParams.setMargins(dp(7), dp(7), dp(7), dp(9));
        else cardParams.bottomMargin = dp(10);
        card.setLayoutParams(cardParams);

        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(television && tv ? 16 : 14), dp(tv ? 10 : 12),
                dp(television && tv ? 16 : 16), dp(tv ? 10 : 12));

        ImageView image = new ImageView(context);
        image.setImageResource(R.drawable.ic_cochi);
        image.setAdjustViewBounds(true);
        image.setScaleType(tv ? ImageView.ScaleType.CENTER_INSIDE : ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(
                dp(posterWidth), dp(posterHeight));
        imageParams.setMarginEnd(dp(tv ? 12 : 16));
        image.setLayoutParams(imageParams);
        row.addView(image);

        TextView number = null;
        if (tv) {
            number = new TextView(context);
            number.setTextColor(ManagedTheme.color(context, R.color.cochi_accent));
            number.setTextSize(television ? 13f : 14f);
            number.setTypeface(Typeface.DEFAULT_BOLD);
            number.setLayoutParams(new LinearLayout.LayoutParams(
                    dp(television ? 44 : 48), ViewGroup.LayoutParams.WRAP_CONTENT));
            row.addView(number);
        }

        LinearLayout textColumn = new LinearLayout(context);
        textColumn.setOrientation(LinearLayout.VERTICAL);
        textColumn.setLayoutParams(new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView name = new TextView(context);
        name.setTextColor(ManagedTheme.color(context, R.color.cochi_text));
        name.setTextSize(tv && television ? 15.5f : 18f);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setMaxLines(tv ? 1 : 2);
        textColumn.addView(name);

        TextView category = new TextView(context);
        category.setTextColor(context.getColor(tv && television
                ? R.color.cochi_muted : tv ? R.color.cochi_muted_strong : R.color.cochi_accent_2));
        category.setTextSize(tv && television ? 10.5f : 13f);
        category.setMaxLines(1);
        textColumn.addView(category);

        TextView description = null;
        if (!tv) {
            description = new TextView(context);
            description.setTextColor(ManagedTheme.color(context, R.color.cochi_muted));
            description.setTextSize(13f);
            description.setMaxLines(2);
            textColumn.addView(description);
        }

        row.addView(textColumn);
        card.addView(row);

        return new Holder(card, image, number, name, category, description);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        Channel item = items.get(position);
        boolean unavailable = "unavailable".equalsIgnoreCase(item.type);

        holder.itemView.setContentDescription(item.name);
        holder.itemView.setAlpha(unavailable ? 0.72f : 1f);
        holder.name.setText(item.name);
        ImageLoader.load(item.logo, holder.image);

        if (mode == Mode.TV) {
            if (holder.number != null) {
                holder.number.setText(String.format(Locale.US, "%03d", item.number));
            }
            holder.category.setText(unavailable
                    ? safeCategory(item.category) + "  •  FUENTE NO CONFIGURADA"
                    : safeCategory(item.category));
        } else {
            holder.category.setText(safeCategory(item.category));
            if (holder.description != null) {
                holder.description.setText(item.description);
                holder.description.setVisibility(item.description == null || item.description.isEmpty()
                        ? View.GONE : View.VISIBLE);
            }
        }

        holder.card.setOnFocusChangeListener((v, hasFocus) -> {
            boolean television = isTelevision();
            if (television) {
                // Foco inmediato para mando: sin animación de escala/elevación por tarjeta.
                // En TV Box de gama baja esas animaciones acumulaban frames perdidos.
                holder.card.animate().cancel();
                holder.card.setScaleX(1f);
                holder.card.setScaleY(1f);
                holder.card.setTranslationZ(0f);
            } else {
                holder.card.animate()
                        .scaleX(hasFocus ? 1.045f : 1f)
                        .scaleY(hasFocus ? 1.045f : 1f)
                        .translationZ(hasFocus ? dp(12) : 0)
                        .setDuration(120)
                        .start();
            }
            holder.card.setStrokeColor(hasFocus ? ManagedTheme.primary(context) : ManagedTheme.border(context));
            holder.card.setStrokeWidth(dp(hasFocus ? 3 : 1));
            if (!television || mode == Mode.TV) {
                holder.card.setCardBackgroundColor(hasFocus ? ManagedTheme.selection(context) : ManagedTheme.button(context));
            }
            holder.card.setCardElevation(dp(television ? (hasFocus ? 4 : 2) : (hasFocus ? 14 : 3)));
        });

        holder.card.setOnClickListener(v -> {
            int adapterPosition = holder.getBindingAdapterPosition();
            if (adapterPosition == RecyclerView.NO_POSITION || listener == null) return;
            listener.onItemClick(adapterPosition, items.get(adapterPosition));
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private String safeCategory(String value) {
        if (value == null || value.trim().isEmpty()) return "General";
        return value.trim();
    }

    private boolean isTelevision() {
        UiModeManager uiModeManager = (UiModeManager) context.getSystemService(Context.UI_MODE_SERVICE);
        return (uiModeManager != null
                && uiModeManager.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION)
                || context.getPackageManager().hasSystemFeature("android.software.leanback");
    }

    private int dp(int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    static final class Holder extends RecyclerView.ViewHolder {
        final MaterialCardView card;
        final ImageView image;
        final TextView number;
        final TextView name;
        final TextView category;
        final TextView description;

        Holder(MaterialCardView card,
               ImageView image,
               TextView number,
               TextView name,
               TextView category,
               TextView description) {
            super(card);
            this.card = card;
            this.image = image;
            this.number = number;
            this.name = name;
            this.category = category;
            this.description = description;
        }
    }
}
