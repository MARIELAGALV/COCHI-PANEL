package com.cochi.client;

import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** v0.23.46: selector de servidores/opciones de reproducción directa. */
public final class PlaybackOptionsActivity extends AppCompatActivity {
    private boolean television;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (!SessionManager.isLoggedIn(this)) { finish(); return; }
        television = isTelevision();
        List<PlaybackOption> options = PlaybackOptionStore.options();
        if (options.isEmpty()) { Toast.makeText(this, "No hay opciones de reproducción", Toast.LENGTH_SHORT).show(); finish(); return; }
        buildUi(options);
        ManagedTheme.applyToActivity(this);
    }

    private void buildUi(List<PlaybackOption> options) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int side = dp(television ? 34 : 18), top = dp(television ? 24 : 14), bottom = dp(18);
        root.setPadding(side, top, side, bottom);
        if (!television) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                v.setPadding(side, top + insets.getSystemWindowInsetTop(), side,
                        bottom + insets.getSystemWindowInsetBottom());
                return insets;
            });
            root.requestApplyInsets();
        }
        root.setBackgroundResource(television ? R.drawable.cochi_tv_dark_background : R.drawable.cochi_neon_background);
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        MaterialButton back = new MaterialButton(this);
        back.setText("Atrás"); back.setAllCaps(false); back.setOnClickListener(v -> finish());
        back.setTextColor(ManagedTheme.color(this, R.color.cochi_text)); back.setStrokeColor(android.content.res.ColorStateList.valueOf(ManagedTheme.color(this, R.color.cochi_accent))); back.setStrokeWidth(dp(1));
        back.setBackgroundTintList(android.content.res.ColorStateList.valueOf(ManagedTheme.button(this)));
        header.addView(back, new LinearLayout.LayoutParams(dp(television ? 130 : 104), dp(television ? 50 : 46)));

        TextView heading = new TextView(this);
        heading.setText("OPCIONES DE REPRODUCCIÓN"); heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setTextColor(ManagedTheme.color(this, R.color.cochi_text)); heading.setTextSize(television ? 24f : 19f);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); hp.setMarginStart(dp(14));
        header.addView(heading, hp);

        TextView title = new TextView(this);
        title.setText(PlaybackOptionStore.title()); title.setTextColor(ManagedTheme.color(this, R.color.cochi_text));
        title.setTextSize(television ? 28f : 23f); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); tp.topMargin = dp(18);
        root.addView(title, tp);

        TextView meta = new TextView(this);
        meta.setText(PlaybackOptionStore.meta()); meta.setTextColor(ManagedTheme.color(this, R.color.cochi_accent_2)); meta.setTextSize(14f);
        root.addView(meta, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView hint = new TextView(this);
        hint.setText("Elegí un servidor. CO-CHI reproduce directamente sin abrir páginas externas.");
        hint.setTextColor(ManagedTheme.color(this, R.color.cochi_muted)); hint.setTextSize(13f);
        LinearLayout.LayoutParams hip = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); hip.topMargin = dp(8);
        root.addView(hint, hip);

        ScrollView scroll = new ScrollView(this);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f); sp.topMargin = dp(14);
        root.addView(scroll, sp);
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); scroll.addView(list);

        LinkedHashMap<String, List<PlaybackOption>> groups = new LinkedHashMap<>();
        for (PlaybackOption option : options) {
            if (option == null || !option.isPlayable()) continue;
            groups.computeIfAbsent(option.groupKey(), k -> new ArrayList<>()).add(option);
        }

        boolean first = true;
        for (Map.Entry<String, List<PlaybackOption>> entry : groups.entrySet()) {
            List<PlaybackOption> group = entry.getValue(); if (group.isEmpty()) continue;
            PlaybackOption sample = group.get(0);
            MaterialCardView card = new MaterialCardView(this);
            card.setCardBackgroundColor(ManagedTheme.button(this));
            card.setStrokeColor(ManagedTheme.color(this, R.color.cochi_tv_border_soft)); card.setStrokeWidth(dp(1)); card.setRadius(dp(14));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            cp.bottomMargin = dp(10); list.addView(card, cp);

            MaterialButton b = new MaterialButton(this);
            String count = group.size() == 1 ? "1 opción" : group.size() + " opciones";
            String quality = bestQuality(group);
            b.setText(sample.groupLabel() + "\n" + count + (quality.isEmpty() ? "" : " · " + quality));
            b.setAllCaps(false); b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL); b.setTextSize(television ? 17f : 15f);
            b.setTextColor(ManagedTheme.color(this, R.color.cochi_text)); b.setBackgroundTintList(getColorStateList(android.R.color.transparent));
            b.setPadding(dp(18), dp(12), dp(18), dp(12)); b.setMinHeight(dp(television ? 72 : 64));
            b.setOnClickListener(v -> chooseGroup(group)); card.addView(b, new MaterialCardView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            if (first && television) { b.requestFocus(); first = false; }
        }
    }

    private String bestQuality(List<PlaybackOption> group) {
        for (PlaybackOption p : group) if (p != null && !p.quality.isEmpty()) return p.quality;
        return "";
    }

    private void chooseGroup(List<PlaybackOption> group) {
        if (group == null || group.isEmpty()) return;
        if (group.size() == 1) { play(group.get(0)); return; }
        String[] labels = new String[group.size()];
        for (int i = 0; i < group.size(); i++) labels[i] = group.get(i).optionLabel(i);
        new AlertDialog.Builder(this)
                .setTitle(group.get(0).groupLabel())
                .setItems(labels, (dialog, which) -> play(group.get(which)))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void play(PlaybackOption option) {
        if (option == null || !option.isPlayable()) return;
        Intent intent = new Intent(this, PlayerActivity.class);
        if (option.localStoreIndex >= 0 && option.localSourceIndex >= 0
                && ChannelStore.selectSourceAt(option.localStoreIndex, option.localSourceIndex)) {
            intent.putExtra(PlayerActivity.EXTRA_STORE_ITEM, true);
            intent.putExtra(PlayerActivity.EXTRA_CHANNEL_INDEX, option.localStoreIndex);
            intent.putExtra(PlayerActivity.EXTRA_CATALOG_SOURCE, CatalogSource.MOVIES.name());
        } else {
            intent.putExtra(PlayerActivity.EXTRA_URL, option.url);
            intent.putExtra(PlayerActivity.EXTRA_STREAM_TYPE, option.type);
            intent.putExtra(PlayerActivity.EXTRA_HEADERS_JSON, option.headersJson().toString());
            intent.putExtra(PlayerActivity.EXTRA_CLEARKEY_MULTI, option.clearKeyPairs);
            intent.putExtra(PlayerActivity.EXTRA_DISPLAY_NAME, PlaybackOptionStore.title());
        }
        startActivity(intent);
    }

    private boolean isTelevision() {
        UiModeManager manager = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        return (manager != null && manager.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION)
                || getPackageManager().hasSystemFeature("android.software.leanback");
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
