package com.cochi.client;

import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.json.JSONObject;

public class TvActivity extends AppCompatActivity {

    public static final String EXTRA_ADULT_ONLY = "cochi.extra.ADULT_ONLY";
    public static final String EXTRA_SOURCE = "cochi.extra.SOURCE";

    private RecyclerView channelRecycler;
    private int gridSpan = 1;
    private ChannelListAdapter adapter;
    private LinearLayout categoryRow;
    private ProgressBar loading;
    private TextView emptyText;
    private boolean adultOnly;
    private CatalogSource source = CatalogSource.TV1;
    private List<Channel> allChannels = new ArrayList<>();
    // Índice precalculado para que cambiar de categoría no recorra todo el catálogo.
    private final Map<String, List<Channel>> channelsByCategory = new LinkedHashMap<>();
    private String activeCategory = "Todos";
    private int returnChannelPosition = RecyclerView.NO_POSITION;
    private static final String STATE_CATEGORY = "cochi.state.TV_CATEGORY";
    private static final String STATE_POSITION = "cochi.state.TV_POSITION";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tv);
        ManagedTheme.applyToActivity(this);
        applyTvVisuals();

        adultOnly = getIntent().getBooleanExtra(EXTRA_ADULT_ONLY, false);
        String sourceName = getIntent().getStringExtra(EXTRA_SOURCE);
        if (sourceName != null) {
            try { source = CatalogSource.valueOf(sourceName); } catch (Exception ignored) {}
        }
        if (savedInstanceState != null) {
            activeCategory = savedInstanceState.getString(STATE_CATEGORY, "Todos");
            returnChannelPosition = savedInstanceState.getInt(STATE_POSITION, RecyclerView.NO_POSITION);
        }

        channelRecycler = findViewById(R.id.channelRecycler);
        categoryRow = findViewById(R.id.categoryRow);
        loading = findViewById(R.id.catalogLoading);
        emptyText = findViewById(R.id.emptyText);

        gridSpan = isTelevision() ? 2 : 1;
        channelRecycler.setLayoutManager(gridSpan > 1
                ? new GridLayoutManager(this, gridSpan)
                : new LinearLayoutManager(this));
        channelRecycler.setHasFixedSize(true);
        // Android TV: sin animador ni caché excesiva. Evita tirones de layout/GPU al mover el foco.
        channelRecycler.setItemAnimator(null);
        channelRecycler.setItemViewCacheSize(isTelevision() ? 6 : 10);
        RecyclerView.LayoutManager lmFast = channelRecycler.getLayoutManager();
        if (lmFast instanceof LinearLayoutManager) {
            ((LinearLayoutManager) lmFast).setInitialPrefetchItemCount(isTelevision() ? 4 : 6);
        }
        adapter = new ChannelListAdapter(this, ChannelListAdapter.Mode.TV,
                (position, item) -> openChannel(position));
        channelRecycler.setAdapter(adapter);
        channelRecycler.addOnChildAttachStateChangeListener(new RecyclerView.OnChildAttachStateChangeListener() {
            @Override
            public void onChildViewAttachedToWindow(View view) {
                view.setOnKeyListener((v, keyCode, event) -> {
                    if (!usesVerticalCategories() || event.getAction() != KeyEvent.ACTION_DOWN) return false;
                    if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
                        int position = channelRecycler.getChildAdapterPosition(v);
                        if (gridSpan <= 1 || position == RecyclerView.NO_POSITION || position % gridSpan == 0) {
                            focusActiveCategory();
                            return true;
                        }
                    }
                    return false;
                });
            }

            @Override
            public void onChildViewDetachedFromWindow(View view) {
                view.setOnKeyListener(null);
            }
        });

        TextView title = findViewById(R.id.tvTitle);
        TextView subtitle = findViewById(R.id.tvSubtitle);
        title.setText(adultOnly ? "ADULTOS" : source == CatalogSource.TV2 ? "TV 2" : "TV 1");
        subtitle.setText(adultOnly
                ? "Sección protegida"
                : "Elegí un canal para comenzar");

        loadCatalog();
    }

    private void loadCatalog() {
        loading.setVisibility(View.VISIBLE);
        emptyText.setVisibility(View.GONE);
        adapter.submitList(new ArrayList<>());
        categoryRow.removeAllViews();

        CatalogRepository.Callback callback = new CatalogRepository.Callback() {
            @Override
            public void onLoaded(List<Channel> channels, boolean fromRemote) {
                if (isFinishing() || isDestroyed()) return;
                try {
                    loading.setVisibility(View.GONE);
                    List<Channel> filtered = new ArrayList<>();
                    if (channels != null) {
                        for (Channel channel : channels) {
                            if (channel == null) continue;
                            if (adultOnly) {
                                if (channel.adult) filtered.add(channel);
                            } else if (!channel.adult) {
                                filtered.add(channel);
                            }
                        }
                    }
                    filtered.sort(Comparator.comparingInt(c -> c.number));
                    allChannels = filtered;
                    rebuildCategoryIndex();
                    renderCategories();
                    renderActiveCategory();
                } catch (Exception e) {
                    Log.e("COCHI-TV", "Error renderizando categoría TV", e);
                    showCatalogError("No se pudo mostrar esta categoría. Tocá para reintentar.");
                }
            }

            @Override
            public void onError(String message) {
                if (isFinishing() || isDestroyed()) return;
                Log.w("COCHI-TV", "Carga de TV fallida: " + message);
                showCatalogError("No se pudo cargar esta categoría. Tocá para reintentar.");
            }
        };

        if (adultOnly) CatalogRepository.loadAdultFromTv1AndTv2(this, callback);
        else CatalogRepository.load(this, source, callback);
    }

    private void showCatalogError(String message) {
        loading.setVisibility(View.GONE);
        channelRecycler.setVisibility(View.GONE);
        emptyText.setText(message);
        emptyText.setVisibility(View.VISIBLE);
        emptyText.setClickable(true);
        emptyText.setFocusable(true);
        emptyText.setOnClickListener(v -> {
            emptyText.setClickable(false);
            loadCatalog();
        });
    }

    private void renderCategories() {
        Map<String, String> categories = new LinkedHashMap<>();
        categories.put("todos", "Todos");
        for (Channel channel : allChannels) {
            if (channel == null) continue;
            String display = safeCategory(channel.category);
            categories.putIfAbsent(display.toLowerCase(Locale.ROOT), display);
        }

        for (String category : categories.values()) {
            MaterialButton chip = new MaterialButton(this);
            chip.setText(category);
            chip.setAllCaps(false);
            chip.setFocusable(true);
            boolean television = isTelevision();
            chip.setMinHeight(dp(television ? 46 : 44));
            chip.setCornerRadius(dp(television ? 12 : 22));
            chip.setTextSize(television ? 13.5f : 14f);
            chip.setOnClickListener(v -> {
                activeCategory = category;
                renderActiveCategory();
                updateCategorySelection();
            });
            chip.setTag(category);
            chip.setOnFocusChangeListener((v, hasFocus) -> {
                if (television) {
                    chip.animate().cancel();
                    chip.setScaleX(1f);
                    chip.setScaleY(1f);
                } else {
                    chip.animate().scaleX(hasFocus ? 1.015f : 1f).scaleY(hasFocus ? 1.015f : 1f)
                            .setDuration(120).start();
                }
                boolean selected = sameCategory(activeCategory, String.valueOf(chip.getTag()));
                applyCategoryStyle(chip, selected, hasFocus);
            });

            boolean vertical = usesVerticalCategories();
            if (vertical) {
                chip.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
                chip.setPadding(dp(14), 0, dp(12), 0);
                chip.setOnKeyListener((v, keyCode, event) -> {
                    if (event.getAction() == KeyEvent.ACTION_DOWN
                            && keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                        focusFirstChannel();
                        return true;
                    }
                    return false;
                });
            }

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    vertical ? LinearLayout.LayoutParams.MATCH_PARENT : LinearLayout.LayoutParams.WRAP_CONTENT,
                    dp(vertical ? (television ? 46 : 54) : 44));
            if (vertical) params.setMargins(dp(4), 0, dp(4), dp(television ? 6 : 10));
            else params.setMarginEnd(dp(8));
            chip.setLayoutParams(params);
            categoryRow.addView(chip);
        }
        updateCategorySelection();
        // No forzar siempre el foco a "Todos": al volver del reproductor debemos
        // conservar la categoría y el canal que el usuario estaba viendo.
        if (isTelevision() && categoryRow.getChildCount() > 0 && returnChannelPosition == RecyclerView.NO_POSITION) {
            focusActiveCategory();
        }
    }

    private void updateCategorySelection() {
        for (int i = 0; i < categoryRow.getChildCount(); i++) {
            View child = categoryRow.getChildAt(i);
            if (!(child instanceof MaterialButton)) continue;
            MaterialButton button = (MaterialButton) child;
            boolean selected = sameCategory(activeCategory, String.valueOf(button.getTag()));
            applyCategoryStyle(button, selected, button.hasFocus());
        }
    }

    private void applyCategoryStyle(MaterialButton button, boolean selected, boolean focused) {
        boolean television = isTelevision();
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                selected ? ManagedTheme.selection(this) : ManagedTheme.button(this)));
        button.setTextColor(ManagedTheme.text(this));
        button.setStrokeColor(android.content.res.ColorStateList.valueOf(
                focused ? ManagedTheme.primary(this) : (selected ? ManagedTheme.primary(this) : ManagedTheme.border(this))));
        button.setStrokeWidth(dp(focused ? 3 : selected ? 2 : television ? 1 : 2));
    }

    private void rebuildCategoryIndex() {
        channelsByCategory.clear();
        channelsByCategory.put("todos", new ArrayList<>(allChannels));
        for (Channel channel : allChannels) {
            if (channel == null) continue;
            String key = safeCategory(channel.category).toLowerCase(Locale.ROOT);
            channelsByCategory.computeIfAbsent(key, ignored -> new ArrayList<>()).add(channel);
        }
    }

    private void renderActiveCategory() {
        String key = "Todos".equalsIgnoreCase(activeCategory)
                ? "todos" : safeCategory(activeCategory).toLowerCase(Locale.ROOT);
        List<Channel> indexed = channelsByCategory.get(key);
        List<Channel> visible = indexed == null ? new ArrayList<>() : new ArrayList<>(indexed);
        ChannelStore.setActiveChannels(visible);
        renderChannels(visible);
    }

    private void renderChannels(List<Channel> channels) {
        if (channels.isEmpty()) {
            adapter.submitList(channels);
            emptyText.setText("No hay canales en esta categoría.");
            emptyText.setVisibility(View.VISIBLE);
            channelRecycler.setVisibility(View.GONE);
            return;
        }

        emptyText.setVisibility(View.GONE);
        channelRecycler.setVisibility(View.VISIBLE);
        adapter.submitList(channels);
        channelRecycler.post(() -> {
            int target = returnChannelPosition;
            if (target != RecyclerView.NO_POSITION && target >= 0 && target < adapter.getItemCount()) {
                channelRecycler.scrollToPosition(target);
                channelRecycler.post(() -> {
                    RecyclerView.ViewHolder holder = channelRecycler.findViewHolderForAdapterPosition(target);
                    if (holder != null && isTelevision()) holder.itemView.requestFocus();
                });
            } else if (returnChannelPosition == RecyclerView.NO_POSITION && adapter.getItemCount() > 0) {
                channelRecycler.scrollToPosition(0);
            }
        });

        // En TV no disparamos precargas extra al cambiar de categoría: los logos visibles
        // se cargan por RecyclerView/Coil y así la red/CPU queda libre para el mando y el player.
        if (!isTelevision()) ImageLoader.prefetch(this, channels, 6);
    }

    private void openChannel(int index) {
        returnChannelPosition = index;
        Channel selected = ChannelStore.get(index);
        if (selected == null) {
            Toast.makeText(this, "Canal no disponible", Toast.LENGTH_SHORT).show();
            return;
        }
        if ("unavailable".equalsIgnoreCase(selected.type)
                || selected.url == null
                || selected.url.startsWith("cochi://unavailable")) {
            Toast.makeText(this,
                    "Este canal necesita una fuente autorizada configurada desde CO-CHI Backend.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        // v0.23.47: abrir el canal con una instantánea propia. Así el primer canal
        // no depende de que otra pantalla termine de reconstruir ChannelStore.
        Intent intent = new Intent(this, PlayerActivity.class);
        intent.putExtra(PlayerActivity.EXTRA_TV_MODE, true);
        intent.putExtra(PlayerActivity.EXTRA_CHANNEL_INDEX, index);
        intent.putExtra(PlayerActivity.EXTRA_CATALOG_SOURCE, source.name());
        intent.putExtra(PlayerActivity.EXTRA_URL, selected.url);
        intent.putExtra(PlayerActivity.EXTRA_STREAM_TYPE, selected.type);
        intent.putExtra(PlayerActivity.EXTRA_CLEARKEY_MULTI, selected.clearKeyPairs);
        intent.putExtra(PlayerActivity.EXTRA_DISPLAY_NAME, selected.name);
        try { intent.putExtra(PlayerActivity.EXTRA_HEADERS_JSON, new JSONObject(selected.headers).toString()); }
        catch (Exception ignored) { }
        startActivity(intent);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString(STATE_CATEGORY, activeCategory);
        LinearLayoutManager lm = channelRecycler == null ? null : (LinearLayoutManager) channelRecycler.getLayoutManager();
        int pos = returnChannelPosition;
        if (lm != null) {
            int visible = lm.findFirstVisibleItemPosition();
            if (pos == RecyclerView.NO_POSITION && visible != RecyclerView.NO_POSITION) pos = visible;
        }
        outState.putInt(STATE_POSITION, pos);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (returnChannelPosition != RecyclerView.NO_POSITION && adapter != null && adapter.getItemCount() > 0) {
            final int target = Math.min(returnChannelPosition, adapter.getItemCount() - 1);
            channelRecycler.scrollToPosition(target);
            channelRecycler.post(() -> {
                RecyclerView.ViewHolder holder = channelRecycler.findViewHolderForAdapterPosition(target);
                if (holder != null && isTelevision()) holder.itemView.requestFocus();
            });
        }
    }


    private void applyTvVisuals() {
        if (!isTelevision()) return;
        int bg = ManagedTheme.background(this);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setBackgroundColor(bg);
    }

    private boolean usesVerticalCategories() {
        return categoryRow != null && categoryRow.getOrientation() == LinearLayout.VERTICAL;
    }

    private void focusFirstChannel() {
        if (adapter == null || adapter.getItemCount() == 0) return;
        channelRecycler.scrollToPosition(0);
        channelRecycler.post(() -> {
            RecyclerView.ViewHolder holder = channelRecycler.findViewHolderForAdapterPosition(0);
            if (holder != null) holder.itemView.requestFocus();
        });
    }

    private void focusActiveCategory() {
        for (int i = 0; i < categoryRow.getChildCount(); i++) {
            View child = categoryRow.getChildAt(i);
            if (sameCategory(activeCategory, String.valueOf(child.getTag()))) {
                child.requestFocus();
                return;
            }
        }
        if (categoryRow.getChildCount() > 0) categoryRow.getChildAt(0).requestFocus();
    }

    private boolean sameCategory(String a, String b) {
        return safeCategory(a).equalsIgnoreCase(safeCategory(b));
    }

    private String safeCategory(String value) {
        if (value == null || value.trim().isEmpty()) return "General";
        return value.trim();
    }

    private boolean isTelevision() {
        UiModeManager uiModeManager = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        return (uiModeManager != null
                && uiModeManager.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION)
                || getPackageManager().hasSystemFeature("android.software.leanback");
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
