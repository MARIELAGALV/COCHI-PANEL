package com.cochi.client;

import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.view.View;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Pantalla bloqueada cuando la cuenta está vencida. */
public class ExpiredActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!SessionManager.isActivated(this)) {
            openActivation();
            return;
        }
        if (!SessionManager.isExpired(this)) {
            openHome();
            return;
        }

        setContentView(R.layout.activity_expired);

        TextView detail = findViewById(R.id.expiredDetail);
        long expiry = SessionManager.expiresAt(this);
        String date = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(new Date(expiry));
        detail.setText("Tu servicio venció el " + date + ".\nLa fecha y hora son únicas para todos tus dispositivos.\nContactá a tu vendedor para renovar.");

        Button check = findViewById(R.id.expiredCheckButton);
        check.setOnClickListener(v -> {
            check.setEnabled(false);
            Toast.makeText(this, "Comprobando con CO-CHI PANEL…", Toast.LENGTH_SHORT).show();
            new Thread(() -> {
                try {
                    boolean active = SessionManager.refreshActivationBlocking(ExpiredActivity.this);
                    runOnUiThread(() -> {
                        check.setEnabled(true);
                        if (active && !SessionManager.isExpired(ExpiredActivity.this)) {
                            Toast.makeText(ExpiredActivity.this, "Renovación confirmada", Toast.LENGTH_SHORT).show();
                            openHome();
                        } else {
                            Toast.makeText(ExpiredActivity.this, "La renovación todavía no fue confirmada", Toast.LENGTH_SHORT).show();
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        check.setEnabled(true);
                        Toast.makeText(ExpiredActivity.this, "No pude consultar el PANEL", Toast.LENGTH_SHORT).show();
                    });
                }
            }, "cochi-renew-check").start();
        });

        View unlink = findViewById(R.id.expiredUnlinkButton);
        unlink.setOnClickListener(v -> showUnlinkConfirmation());

        setupFocus(check);
        setupFocus(unlink);
        if (isTelevision()) check.post(check::requestFocus);
    }

    private void showUnlinkConfirmation() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Desvincular dispositivo")
                .setMessage("¿Estás seguro de que deseas desvincular este dispositivo?")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Sí, desvincular", (d, which) -> {
                    SessionManager.logout(this);
                    openActivation();
                })
                .create();
        dialog.setOnShowListener(d -> {
            android.widget.Button cancel = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
            if (cancel != null) cancel.requestFocus();
        });
        dialog.show();
    }

    private void setupFocus(View view) {
        view.setOnFocusChangeListener((v, hasFocus) -> v.animate()
                .scaleX(hasFocus ? 1.035f : 1f)
                .scaleY(hasFocus ? 1.035f : 1f)
                .setDuration(120).start());
    }

    private boolean isTelevision() {
        UiModeManager uiModeManager = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        return (uiModeManager != null
                && uiModeManager.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION)
                || getPackageManager().hasSystemFeature("android.software.leanback");
    }

    private void openHome() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    private void openActivation() {
        Intent intent = new Intent(this, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }
}
