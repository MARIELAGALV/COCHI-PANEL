package com.cochi.client;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ContinueWatchingActivity extends AppCompatActivity {
    private ContinueWatchingAdapter adapter;
    private TextView empty;
    private ProgressBar loading;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_continue_watching);
        ManagedTheme.applyToActivity(this);

        RecyclerView list = findViewById(R.id.continueRecycler);
        empty = findViewById(R.id.continueEmpty);
        loading = findViewById(R.id.continueLoading);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ContinueWatchingAdapter(this, new ContinueWatchingAdapter.Listener() {
            @Override public void onClick(ProgressManager.Entry entry) {
                openEntry(entry);
            }

            @Override public void onOptions(ProgressManager.Entry entry) {
                showEntryOptions(entry);
            }
        });
        list.setAdapter(adapter);
    }

    @Override protected void onResume() {
        super.onResume();
        refreshEntries();
    }


    private void showEntryOptions(ProgressManager.Entry entry) {
        final String[] options = {
                "Continuar reproduciendo",
                "Reiniciar desde el principio",
                "Quitar de Seguir viendo"
        };

        new AlertDialog.Builder(this)
                .setTitle(entry.name)
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        openEntry(entry);
                        return;
                    }

                    CatalogSource source = sourceOf(entry);
                    if (source == null) return;

                    if (which == 1) {
                        ProgressManager.remove(this, source, entry.itemId);
                        openEntry(entry);
                    } else if (which == 2) {
                        ProgressManager.remove(this, source, entry.itemId);
                        refreshEntries();
                        Toast.makeText(this, "Quitado de Seguir viendo", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private CatalogSource sourceOf(ProgressManager.Entry entry) {
        try {
            return CatalogSource.valueOf(entry.source);
        } catch (Exception e) {
            Toast.makeText(this, "Contenido no disponible", Toast.LENGTH_SHORT).show();
            return null;
        }
    }

    private void refreshEntries() {
        List<ProgressManager.Entry> entries = ProgressManager.getAll(this);
        adapter.submitList(entries);
        empty.setVisibility(entries.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void openEntry(ProgressManager.Entry entry) {
        CatalogSource source = sourceOf(entry);
        if (source == null) return;

        loading.setVisibility(View.VISIBLE);
        CatalogRepository.load(this, source, new CatalogRepository.Callback() {
            @Override public void onLoaded(List<Channel> items, boolean fromRemote) {
                loading.setVisibility(View.GONE);

                List<Channel> visible = new ArrayList<>();
                int target = -1;

                if (source == CatalogSource.SERIES) {
                    SeriesStore.SeriesInfo series = SeriesStore.findSeriesByEpisodeId(entry.itemId);
                    if (series != null) {
                        visible.addAll(series.allEpisodes());
                        for (int i = 0; i < visible.size(); i++) {
                            if (entry.itemId.equals(visible.get(i).id)) {
                                target = i;
                                break;
                            }
                        }
                    }
                } else {
                    for (Channel item : items) {
                        if (item.adult) continue;
                        if (entry.itemId.equals(item.id)) target = visible.size();
                        visible.add(item);
                    }
                }

                if (target < 0) {
                    ProgressManager.remove(ContinueWatchingActivity.this, source, entry.itemId);
                    Toast.makeText(ContinueWatchingActivity.this,
                            "Ese contenido ya no está en el catálogo", Toast.LENGTH_LONG).show();
                    onResume();
                    return;
                }

                ChannelStore.setActiveChannels(visible);
                Intent intent = new Intent(ContinueWatchingActivity.this, PlayerActivity.class);
                intent.putExtra(PlayerActivity.EXTRA_STORE_ITEM, true);
                intent.putExtra(PlayerActivity.EXTRA_CHANNEL_INDEX, target);
                intent.putExtra(PlayerActivity.EXTRA_CATALOG_SOURCE, source.name());
                intent.putExtra(PlayerActivity.EXTRA_AUTO_RESUME, true);
                intent.putExtra(PlayerActivity.EXTRA_AUTO_NEXT_SERIES, source == CatalogSource.SERIES);
                startActivity(intent);
            }

            @Override public void onError(String message) {
                loading.setVisibility(View.GONE);
                Toast.makeText(ContinueWatchingActivity.this, message, Toast.LENGTH_LONG).show();
            }
        });
    }
}
