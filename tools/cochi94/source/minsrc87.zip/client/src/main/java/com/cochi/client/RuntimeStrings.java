package com.cochi.client;

/**
 * Constantes reconstruidas en tiempo de ejecución para evitar dejar endpoints y
 * etiquetas internas como cadenas completas triviales dentro del DEX.
 * Esto es endurecimiento/obfuscación; la seguridad real sigue en el servidor.
 */
final class RuntimeStrings {
    private RuntimeStrings() {}

    static String panelBaseUrl() {
        return decode(new int[]{18, 184, 43, 35, 187, 228, 154, 66, 69, 111, 120, 255, 253, 31, 225, 176, 124, 17, 123, 54, 208, 180, 194, 17, 75, 75, 39, 182, 131, 244, 39, 44, 218, 50, 189, 130, 17, 194, 210, 28, 47, 126, 234, 87, 52}, 73);
    }

    static String updatesApi() {
        return decode(new int[]{224, 238, 153, 209, 165, 150, 108, 148, 85, 190, 192, 203, 197, 105, 107, 119, 85, 32, 139, 10, 193, 249, 20, 177, 41, 134, 142, 94, 213, 37, 214, 245, 241, 175, 17, 112, 193, 61, 127, 157, 75, 93, 86, 88, 17, 152, 70, 122, 0, 214, 84, 173, 27, 55, 4, 161, 25, 42, 52, 220, 217, 93, 244, 136, 152, 95, 191, 158, 70, 45, 68, 190, 169, 92, 185}, 151);
    }

    static String tvCatalogSalt() {
        return decode(new int[]{7, 153, 234, 149, 219, 197, 171, 161, 221, 73, 36, 117, 31, 112, 148, 28, 241, 40, 83, 136, 57, 145, 187, 171}, 211);
    }

    private static String decode(int[] data, int seed) {
        char[] out = new char[data.length];
        int k = seed & 0xff;
        for (int i = 0; i < data.length; i++) {
            k = (k * 33 + 17 + i) & 0xff;
            out[i] = (char) ((data[i] ^ k) & 0xff);
        }
        return new String(out);
    }
}
