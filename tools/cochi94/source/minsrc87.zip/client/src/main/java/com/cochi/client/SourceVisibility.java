package com.cochi.client;

import org.json.JSONObject;

import java.util.EnumMap;
import java.util.Map;

/** Estado de visibilidad global definido exclusivamente por ADMINISTRACIÓN. */
public final class SourceVisibility {
    private static final Map<CatalogSource, Boolean> values = new EnumMap<>(CatalogSource.class);
    private static volatile boolean loaded;
    private static volatile boolean adultVisible = true;

    static {
        values.put(CatalogSource.TV1, true);
        values.put(CatalogSource.TV2, true);
        values.put(CatalogSource.MOVIES, true);
        values.put(CatalogSource.SERIES, true);
    }

    private SourceVisibility() {}

    public static synchronized void applyConfig(JSONObject config) {
        JSONObject sources = config == null ? null : config.optJSONObject("sources");
        if (sources == null) return;
        apply(sources, CatalogSource.TV1, "tv1");
        apply(sources, CatalogSource.TV2, "tv2");
        apply(sources, CatalogSource.MOVIES, "movies");
        apply(sources, CatalogSource.SERIES, "series");
        JSONObject adult = sources.optJSONObject("adult");
        if (adult == null) adult = sources.optJSONObject("adults");
        if (adult != null) adultVisible = adult.optBoolean("enabled", true);
        loaded = true;
    }

    private static void apply(JSONObject sources, CatalogSource source, String key) {
        JSONObject item = sources.optJSONObject(key);
        if (item != null) values.put(source, item.optBoolean("enabled", true));
    }

    public static synchronized boolean isVisible(CatalogSource source) {
        Boolean value = values.get(source);
        return value == null || value;
    }

    public static boolean isAdultVisible() { return adultVisible; }

    public static boolean isLoaded() { return loaded; }
}
