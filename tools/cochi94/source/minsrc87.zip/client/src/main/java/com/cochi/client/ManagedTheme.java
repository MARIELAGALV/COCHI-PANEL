package com.cochi.client;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ProgressBar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import org.json.JSONObject;

public final class ManagedTheme {
    private static final String PREF="cochi_managed_theme";
    private static final String[] KEYS={"primary","selection","background","button","border","text","secondary"};
    private static final String[] DEF={"#00CFFF","#1E90FF","#0A0F1B","#162338","#1E3D6B","#FFFFFF","#B0B0B0"};
    private ManagedTheme(){}

    public static void update(Context c, JSONObject t){
        if(c==null||t==null)return;
        SharedPreferences.Editor e=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit();
        for(int i=0;i<KEYS.length;i++){
            String v=t.optString(KEYS[i],DEF[i]);
            if(v.matches("#[0-9A-Fa-f]{6}"))e.putString(KEYS[i],v.toUpperCase());
        }
        e.apply();
    }
    private static int get(Context c,String key,String def){
        try{return Color.parseColor(c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(key,def));}
        catch(Exception ignored){return Color.parseColor(def);}
    }
    public static int primary(Context c){return get(c,"primary",DEF[0]);}
    public static int selection(Context c){return get(c,"selection",DEF[1]);}
    public static int background(Context c){return get(c,"background",DEF[2]);}
    public static int button(Context c){return get(c,"button",DEF[3]);}
    public static int border(Context c){return get(c,"border",DEF[4]);}
    public static int text(Context c){return get(c,"text",DEF[5]);}
    public static int secondary(Context c){return get(c,"secondary",DEF[6]);}

    public static int color(Context c, int resId){
        if(resId==R.color.cochi_bg || resId==R.color.cochi_bg_2 || resId==R.color.cochi_tv_bg
                || resId==R.color.cochi_tv_bg_2 || resId==R.color.cochi_tv_sidebar) return background(c);
        if(resId==R.color.cochi_surface || resId==R.color.cochi_surface_2 || resId==R.color.cochi_tv_surface
                || resId==R.color.cochi_tv_surface_2 || resId==R.color.cochi_tv_panel || resId==R.color.cochi_tv_panel_soft) return button(c);
        if(resId==R.color.cochi_surface_focus || resId==R.color.cochi_tv_surface_focus
                || resId==R.color.cochi_blue_button || resId==R.color.cochi_blue_button_pressed) return selection(c);
        if(resId==R.color.cochi_border || resId==R.color.cochi_border_soft
                || resId==R.color.cochi_tv_border || resId==R.color.cochi_tv_border_soft) return border(c);
        if(resId==R.color.cochi_accent || resId==R.color.cochi_accent_2 || resId==R.color.cochi_accent_deep
                || resId==R.color.cochi_tv_focus_glow) return primary(c);
        if(resId==R.color.cochi_text) return text(c);
        if(resId==R.color.cochi_muted || resId==R.color.cochi_muted_strong) return secondary(c);
        return c.getColor(resId);
    }
    public static ColorStateList colors(Context c, int resId){ return ColorStateList.valueOf(color(c,resId)); }

    private static int remapResolved(Context c, int value){
        int[] ids={R.color.cochi_bg,R.color.cochi_bg_2,R.color.cochi_tv_bg,R.color.cochi_tv_bg_2,R.color.cochi_tv_sidebar,
                R.color.cochi_surface,R.color.cochi_surface_2,R.color.cochi_tv_surface,R.color.cochi_tv_surface_2,
                R.color.cochi_surface_focus,R.color.cochi_tv_surface_focus,R.color.cochi_blue_button,R.color.cochi_blue_button_pressed,
                R.color.cochi_border,R.color.cochi_border_soft,R.color.cochi_tv_border,R.color.cochi_tv_border_soft,
                R.color.cochi_accent,R.color.cochi_accent_2,R.color.cochi_accent_deep,
                R.color.cochi_text,R.color.cochi_muted,R.color.cochi_muted_strong};
        for(int id:ids){ try{ if(c.getColor(id)==value) return color(c,id); }catch(Exception ignored){} }
        return value;
    }

    public static void applyToActivity(Activity a){
        if(a==null)return;
        int bg=background(a);
        a.getWindow().setStatusBarColor(bg);
        a.getWindow().setNavigationBarColor(bg);
        View decor=a.getWindow().getDecorView();
        decor.setBackgroundColor(bg);
        View root=decor.findViewById(android.R.id.content);
        if(root!=null){
            root.setBackgroundColor(bg);
            applyToView(a,root);
        }
    }

    private static void applyToView(Context c, View v){
        try{
            if(v instanceof MaterialCardView){
                MaterialCardView card=(MaterialCardView)v;
                card.setCardBackgroundColor(remapResolved(c,card.getCardBackgroundColor().getDefaultColor()));
                if(card.getStrokeColor()!=0) card.setStrokeColor(remapResolved(c,card.getStrokeColor()));
            } else if(v instanceof MaterialButton){
                MaterialButton b=(MaterialButton)v;
                if(b.getBackgroundTintList()!=null) b.setBackgroundTintList(ColorStateList.valueOf(remapResolved(c,b.getBackgroundTintList().getDefaultColor())));
                if(b.getStrokeColor()!=null) b.setStrokeColor(ColorStateList.valueOf(remapResolved(c,b.getStrokeColor().getDefaultColor())));
                if(b.getIconTint()!=null) b.setIconTint(ColorStateList.valueOf(remapResolved(c,b.getIconTint().getDefaultColor())));
            }
            if(v instanceof TextView){
                TextView t=(TextView)v;
                t.setTextColor(remapResolved(c,t.getCurrentTextColor()));
                if(t.getHintTextColors()!=null) t.setHintTextColor(remapResolved(c,t.getHintTextColors().getDefaultColor()));
            }
            if(v.getBackground() instanceof ColorDrawable){
                ColorDrawable cd=(ColorDrawable)v.getBackground();
                int mapped=remapResolved(c,cd.getColor());
                if(mapped!=cd.getColor()) v.setBackgroundColor(mapped);
            }
            if(v instanceof ProgressBar){
                ((ProgressBar)v).setIndeterminateTintList(ColorStateList.valueOf(primary(c)));
            }
            if(v instanceof ViewGroup){
                ViewGroup g=(ViewGroup)v;
                for(int i=0;i<g.getChildCount();i++) applyToView(c,g.getChildAt(i));
            }
        }catch(Exception ignored){}
    }
}

