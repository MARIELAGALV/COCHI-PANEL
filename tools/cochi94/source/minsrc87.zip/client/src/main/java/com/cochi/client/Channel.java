package com.cochi.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class Channel {
    public final String id;
    public final int number;
    public final String name;

    // Compatibilidad: estos campos reflejan siempre la primera fuente activa.
    public final String type;
    public String url;
    public final String clearKeyPairs;
    public final Map<String, String> headers;

    // Nuevo modelo: una entrada puede conservar una o varias fuentes normalizadas.
    public final List<StreamSource> sources;

    public final boolean adult;
    public final String category;
    public final String logo;
    public final String description;

    // Metadatos opcionales de plantilla/redirección provenientes del catálogo.
    // Son opcionales: si el JSON no los trae, quedan en sus valores por defecto.
    public final boolean isTemplate;
    public final String nameRedirect;
    public final String codeRedirect;
    public final String template;

    public Channel(
            String id,
            int number,
            String name,
            String type,
            String url,
            boolean adult,
            String clearKeyPairs,
            Map<String, String> headers) {
        this(id, number, name, type, url, adult, clearKeyPairs, headers,
                "General", "", "", null);
    }

    public Channel(
            String id,
            int number,
            String name,
            String type,
            String url,
            boolean adult,
            String clearKeyPairs,
            Map<String, String> headers,
            String category,
            String logo,
            String description) {
        this(id, number, name, type, url, adult, clearKeyPairs, headers,
                category, logo, description, null);
    }

    public Channel(
            String id,
            int number,
            String name,
            String type,
            String url,
            boolean adult,
            String clearKeyPairs,
            Map<String, String> headers,
            String category,
            String logo,
            String description,
            List<StreamSource> sources) {
        this(id, number, name, type, url, adult, clearKeyPairs, headers,
                category, logo, description, sources, false, "", "", "");
    }

    public Channel(
            String id,
            int number,
            String name,
            String type,
            String url,
            boolean adult,
            String clearKeyPairs,
            Map<String, String> headers,
            String category,
            String logo,
            String description,
            List<StreamSource> sources,
            boolean isTemplate,
            String nameRedirect,
            String codeRedirect,
            String template) {
        this.id = id;
        this.number = number;
        this.name = name;
        this.adult = adult;
        this.category = category == null || category.trim().isEmpty() ? "General" : category.trim();
        this.logo = logo == null ? "" : logo.trim();
        this.description = description == null ? "" : description.trim();
        this.isTemplate = isTemplate;
        this.nameRedirect = safe(nameRedirect);
        this.codeRedirect = safe(codeRedirect);
        this.template = safe(template);

        List<StreamSource> normalized = new ArrayList<>();
        if (sources != null) {
            for (StreamSource source : sources) {
                if (source != null && source.isPlayable()) normalized.add(source);
            }
        }
        if (normalized.isEmpty() && url != null && !url.trim().isEmpty()) {
            DrmConfig drm = new DrmConfig(
                    clearKeyPairs == null || clearKeyPairs.trim().isEmpty() ? "" : "clearkey",
                    "",
                    clearKeyPairs,
                    null);
            normalized.add(new StreamSource(url, type, headers, "", 0L, 0, drm));
        }
        this.sources = normalized.isEmpty()
                ? Collections.emptyList()
                : Collections.unmodifiableList(normalized);

        StreamSource active = this.sources.isEmpty() ? null : this.sources.get(0);
        this.type = active == null
                ? (type == null || type.trim().isEmpty() ? "auto" : type.trim())
                : active.type;
        this.url = active == null ? safe(url) : active.url;
        this.clearKeyPairs = active == null
                ? safe(clearKeyPairs)
                : active.drm.clearKeyPairs;
        this.headers = active == null
                ? immutableHeaders(headers)
                : active.headers;
    }

    public boolean hasClearKey() {
        return !clearKeyPairs.trim().isEmpty();
    }

    public StreamSource primarySource() {
        return sources.isEmpty() ? null : sources.get(0);
    }

    public StreamSource sourceAt(int index) {
        return index < 0 || index >= sources.size() ? null : sources.get(index);
    }

    public boolean hasAlternativeSources() {
        return sources.size() > 1;
    }

    /**
     * Prepara una fuente alternativa como primaria sin activar failover automático.
     * Queda disponible para una futura selección manual o estrategia de respaldo.
     */
    public Channel usingSource(int index) {
        if (index < 0 || index >= sources.size() || index == 0) return this;
        List<StreamSource> reordered = new ArrayList<>();
        StreamSource selected = sources.get(index);
        reordered.add(selected);
        for (int i = 0; i < sources.size(); i++) {
            if (i != index) reordered.add(sources.get(i));
        }
        return new Channel(
                id, number, name, selected.type, selected.url, adult,
                selected.drm.clearKeyPairs, selected.headers,
                category, logo, description, reordered,
                isTemplate, nameRedirect, codeRedirect, template);
    }

    private static Map<String, String> immutableHeaders(Map<String, String> headers) {
        return headers == null || headers.isEmpty()
                ? Collections.emptyMap()
                : Collections.unmodifiableMap(new LinkedHashMap<>(headers));
    }

    private static String safe(String value) {
        return value == null ? "" : value.trim();
    }
}
