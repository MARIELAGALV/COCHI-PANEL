package com.cochi.client;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Cliente aislado del Buscador de series y películas.
 * v0.23.46: la credencial de TMDb queda exclusivamente en CO-CHI PANEL;
 * la APK nunca recibe ni almacena la clave.
 */
public final class TmdbSearchClient {
    private static final String IMAGE_BASE = "https://image.tmdb.org/t/p/w500";

    private TmdbSearchClient() { }

    public static List<WebSearchResult> search(Context context, String rawQuery) throws Exception {
        String query = rawQuery == null ? "" : rawQuery.trim();
        if (query.length() < 2) return new ArrayList<>();

        JSONObject root = BackendClient.searchMedia(context, query);
        JSONArray results = root.optJSONArray("results");
        List<WebSearchResult> out = new ArrayList<>();
        if (results == null) return out;

        for (int i = 0; i < results.length() && out.size() < 30; i++) {
            JSONObject item = results.optJSONObject(i);
            if (item == null) continue;
            String mediaType = item.optString("media_type", "");
            if (!"movie".equals(mediaType) && !"tv".equals(mediaType)) continue;

            String title = item.optString("title", "").trim();
            if (title.isEmpty()) continue;
            String posterPath = item.optString("poster_path", "").trim();
            String posterUrl = item.optString("poster_url", "").trim();
            if (posterUrl.isEmpty() && !posterPath.isEmpty()) posterUrl = IMAGE_BASE + posterPath;

            out.add(new WebSearchResult(
                    item.optLong("id", 0L),
                    mediaType,
                    title,
                    item.optString("original_title", "").trim(),
                    item.optString("year", "").trim(),
                    posterUrl,
                    item.optString("overview", "").trim()));
        }
        return out;
    }
}
