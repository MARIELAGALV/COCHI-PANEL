package com.cochi.client;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Filas visuales del nuevo inicio Android TV.
 * Solo presenta contenido existente; la reproducción continúa usando PlayerActivity.
 */
public final class TvHomeContentAdapter extends RecyclerView.Adapter<TvHomeContentAdapter.Holder> {

    public enum Style {
        LIVE,
        POSTER
    }

    public interface Listener {
        void onClick(HomeItem item);
        void onFocus(HomeItem item);
    }

    public static final class HomeItem {
        public final CatalogSource source;
        public final Channel channel;

        public HomeItem(CatalogSource source, Channel channel) {
            this.source = source;
            this.channel = channel;
        }
    }

    private final Context context;
    private final Style style;
    private final Listener listener;
    private final List<HomeItem> items = new ArrayList<>();

    public TvHomeContentAdapter(Context context, Style style, Listener listener) {
        this.context = context;
        this.style = style;
        this.listener = listener;
        setHasStableIds(true);
    }

    public void submitList(List<HomeItem> next) {
        items.clear();
        if (next != null) items.addAll(next);
        notifyDataSetChanged();
    }

    @Override
    public long getItemId(int position) {
        HomeItem item = items.get(position);
        String id = item.source.name() + ":" + (item.channel.id == null ? position : item.channel.id);
        return id.hashCode();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return style == Style.LIVE ? createLiveHolder() : createPosterHolder();
    }

    private Holder createLiveHolder() {
        MaterialCardView card = baseCard(216, 82);

        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(9), dp(12), dp(9));

        ImageView image = new ImageView(context);
        image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        image.setAdjustViewBounds(true);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(54), dp(54));
        ip.setMarginEnd(dp(11));
        image.setLayoutParams(ip);
        row.addView(image);

        LinearLayout text = new LinearLayout(context);
        text.setOrientation(LinearLayout.VERTICAL);
        text.setGravity(Gravity.CENTER_VERTICAL);
        text.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView title = new TextView(context);
        title.setTextColor(ManagedTheme.color(context, R.color.cochi_text));
        title.setTextSize(15f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setMaxLines(1);
        text.addView(title);

        TextView subtitle = new TextView(context);
        subtitle.setTextColor(ManagedTheme.color(context, R.color.cochi_muted));
        subtitle.setTextSize(11f);
        subtitle.setMaxLines(1);
        text.addView(subtitle);

        TextView live = new TextView(context);
        live.setText("● EN VIVO");
        live.setTextColor(ManagedTheme.color(context, R.color.cochi_accent_2));
        live.setTextSize(10f);
        live.setTypeface(Typeface.DEFAULT_BOLD);
        text.addView(live);

        row.addView(text);
        card.addView(row);
        return new Holder(card, image, title, subtitle, live);
    }

    private Holder createPosterHolder() {
        MaterialCardView card = baseCard(148, 204);

        FrameLayout frame = new FrameLayout(context);
        frame.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        ImageView image = new ImageView(context);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setImageResource(R.drawable.ic_cochi);
        frame.addView(image, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        View scrim = new View(context);
        scrim.setBackgroundResource(R.drawable.tv_card_scrim);
        frame.addView(scrim, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout text = new LinearLayout(context);
        text.setOrientation(LinearLayout.VERTICAL);
        text.setGravity(Gravity.BOTTOM);
        text.setPadding(dp(10), dp(8), dp(10), dp(10));
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        text.setLayoutParams(tp);

        TextView title = new TextView(context);
        title.setTextColor(ManagedTheme.color(context, R.color.cochi_text));
        title.setTextSize(14f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setMaxLines(2);
        text.addView(title);

        TextView subtitle = new TextView(context);
        subtitle.setTextColor(ManagedTheme.color(context, R.color.cochi_accent_2));
        subtitle.setTextSize(10.5f);
        subtitle.setMaxLines(1);
        text.addView(subtitle);

        frame.addView(text);
        card.addView(frame);
        return new Holder(card, image, title, subtitle, null);
    }

    private MaterialCardView baseCard(int widthDp, int heightDp) {
        MaterialCardView card = new MaterialCardView(context);
        card.setCardBackgroundColor(ManagedTheme.color(context, R.color.cochi_tv_surface));
        card.setRadius(dp(16));
        card.setStrokeColor(ManagedTheme.color(context, R.color.cochi_tv_border_soft));
        card.setStrokeWidth(dp(1));
        card.setCardElevation(dp(2));
        card.setFocusable(true);
        card.setClickable(true);
        card.setClipToOutline(true);

        RecyclerView.LayoutParams params = new RecyclerView.LayoutParams(dp(widthDp), dp(heightDp));
        params.setMarginEnd(dp(12));
        params.topMargin = dp(4);
        params.bottomMargin = dp(5);
        card.setLayoutParams(params);
        return card;
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        HomeItem item = items.get(position);
        Channel channel = item.channel;

        holder.title.setText(channel.name == null || channel.name.trim().isEmpty()
                ? "Contenido" : channel.name.trim());
        holder.subtitle.setText(subtitleFor(item));
        ImageLoader.load(imageFor(item), holder.image);
        holder.card.setContentDescription(channel.name);

        holder.card.setOnFocusChangeListener((v, hasFocus) -> {
            holder.card.animate().cancel();
            holder.card.setScaleX(1f);
            holder.card.setScaleY(1f);
            holder.card.setTranslationZ(0f);
            holder.card.setStrokeColor(context.getColor(
                    hasFocus ? R.color.cochi_accent_2 : R.color.cochi_tv_border_soft));
            holder.card.setStrokeWidth(dp(hasFocus ? 3 : 1));
            holder.card.setCardElevation(dp(hasFocus ? 6 : 2));
            holder.card.setCardBackgroundColor(context.getColor(hasFocus ? R.color.cochi_tv_surface_focus : R.color.cochi_tv_surface));
            if (hasFocus && listener != null) listener.onFocus(item);
        });

        holder.card.setOnClickListener(v -> {
            int p = holder.getBindingAdapterPosition();
            if (p != RecyclerView.NO_POSITION && listener != null) listener.onClick(items.get(p));
        });
    }

    private String imageFor(HomeItem item) {
        if (item.source == CatalogSource.SERIES) {
            SeriesStore.SeriesInfo info = SeriesStore.getSeries(item.channel.id);
            if (info != null && info.poster != null && !info.poster.trim().isEmpty()) return info.poster;
        }
        return item.channel.logo;
    }

    private String subtitleFor(HomeItem item) {
        Channel channel = item.channel;
        if (style == Style.LIVE) {
            String sourceName = item.source == CatalogSource.TV2 ? "TV 2" : "TV 1";
            return sourceName + " · " + safeCategory(channel.category);
        }
        if (item.source == CatalogSource.SERIES) {
            SeriesStore.SeriesInfo info = SeriesStore.getSeries(channel.id);
            if (info != null) {
                int seasons = info.seasons.size();
                int episodes = info.episodeCount();
                if (!info.year.isEmpty()) return info.year + " · " + seasons + "T";
                return seasons + (seasons == 1 ? " temporada" : " temporadas")
                        + " · " + episodes + " ep.";
            }
        }
        return safeCategory(channel.category).toUpperCase(Locale.ROOT);
    }

    private String safeCategory(String value) {
        if (value == null || value.trim().isEmpty()) return "General";
        return value.trim();
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    private int dp(int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    static final class Holder extends RecyclerView.ViewHolder {
        final MaterialCardView card;
        final ImageView image;
        final TextView title;
        final TextView subtitle;
        final TextView badge;

        Holder(MaterialCardView card, ImageView image, TextView title, TextView subtitle, TextView badge) {
            super(card);
            this.card = card;
            this.image = image;
            this.title = title;
            this.subtitle = subtitle;
            this.badge = badge;
        }
    }
}
