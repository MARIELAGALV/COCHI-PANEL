package com.cochi.client;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * DRM normalizado de una fuente. La reproducción actual de CO-CHI sigue usando
 * ClearKey como hasta ahora; este modelo también conserva licenseUrl/headers
 * para ampliar compatibilidad sin volver a cambiar el formato del catálogo.
 */
public final class DrmConfig {
    public static final DrmConfig NONE = new DrmConfig("", "", "", null);

    public final String scheme;
    public final String licenseUrl;
    public final String clearKeyPairs;
    public final Map<String, String> headers;

    public DrmConfig(
            String scheme,
            String licenseUrl,
            String clearKeyPairs,
            Map<String, String> headers) {
        this.scheme = safe(scheme);
        this.licenseUrl = safe(licenseUrl);
        this.clearKeyPairs = safe(clearKeyPairs);
        this.headers = headers == null || headers.isEmpty()
                ? Collections.emptyMap()
                : Collections.unmodifiableMap(new LinkedHashMap<>(headers));
    }

    public boolean hasClearKey() {
        return !clearKeyPairs.isEmpty()
                || "clearkey".equalsIgnoreCase(scheme) && !clearKeyPairs.isEmpty();
    }

    public boolean isEmpty() {
        return scheme.isEmpty() && licenseUrl.isEmpty()
                && clearKeyPairs.isEmpty() && headers.isEmpty();
    }

    private static String safe(String value) {
        return value == null ? "" : value.trim();
    }
}
