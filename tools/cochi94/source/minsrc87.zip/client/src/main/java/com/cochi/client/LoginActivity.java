package com.cochi.client;

import android.app.UiModeManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/** Activación real de dispositivo contra CO-CHI PANEL. */
public class LoginActivity extends AppCompatActivity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView codeView;
    private TextView statusView;
    private volatile boolean checking;

    private final Runnable statePoll = new Runnable() {
        @Override public void run() {
            checkBackend(false);
            handler.postDelayed(this, 5000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        codeView = findViewById(R.id.activationCode);
        TextView deviceView = findViewById(R.id.activationDevice);
        statusView = findViewById(R.id.activationStatus);
        Button copyButton = findViewById(R.id.activationCopy);
        Button checkButton = findViewById(R.id.activationCheck);

        deviceView.setText(android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL);
        codeView.setText(SessionManager.activationCode(this));
        statusView.setText("Conectando con CO-CHI PANEL…");

        copyButton.setOnClickListener(v -> {
            String code = SessionManager.activationCode(this);
            if (code.startsWith("----")) {
                Toast.makeText(this, "Esperá a que se genere el código", Toast.LENGTH_SHORT).show();
                return;
            }
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard != null) {
                clipboard.setPrimaryClip(ClipData.newPlainText("Código CO-CHI", code));
                Toast.makeText(this, "Código copiado", Toast.LENGTH_SHORT).show();
            }
        });

        checkButton.setOnClickListener(v -> checkBackend(true));
        setupFocus(copyButton);
        setupFocus(checkButton);
        if (isTelevision()) checkButton.post(checkButton::requestFocus);

        // Ya no existe activación demo oculta: todo acceso se valida en el backend.
        ensureRegistered();
    }

    private void ensureRegistered() {
        if (checking) return;
        checking = true;
        new Thread(() -> {
            try {
                String code = SessionManager.registerIfNeededBlocking(this);
                runOnUiThread(() -> {
                    codeView.setText(code);
                    statusView.setText("Esperando activación del vendedor…");
                    checking = false;
                    checkBackend(false);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    statusView.setText("No se pudo registrar: " + safeMessage(e));
                    checking = false;
                });
            }
        }, "cochi-register").start();
    }

    private void checkBackend(boolean manual) {
        if (checking) return;
        if (SessionManager.deviceSecret(this).isEmpty()) {
            ensureRegistered();
            return;
        }
        checking = true;
        if (manual) statusView.setText("Comprobando estado…");
        new Thread(() -> {
            try {
                boolean active = SessionManager.refreshActivationBlocking(this);
                runOnUiThread(() -> {
                    checking = false;
                    codeView.setText(SessionManager.activationCode(this));
                    String slot = SessionManager.devicePositionLabel(this);
                    if (active) {
                        statusView.setText(slot.isEmpty() ? "Dispositivo activado ✓" : "Dispositivo activado ✓ · " + slot);
                        openHome();
                    } else {
                        statusView.setText(slot.isEmpty()
                                ? "Todavía no fue activado. Compartí el código con tu proveedor."
                                : "Dispositivo " + slot + " vinculado. Esperando activación del servicio.");
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    checking = false;
                    statusView.setText("Sin conexión con el PANEL: " + safeMessage(e));
                });
            }
        }, "cochi-activation-check").start();
    }

    @Override protected void onStart() {
        super.onStart();
        handler.postDelayed(statePoll, 2500L);
    }

    @Override protected void onStop() {
        handler.removeCallbacks(statePoll);
        super.onStop();
    }

    private void setupFocus(View view) {
        view.setOnFocusChangeListener((v, hasFocus) -> v.animate()
                .scaleX(hasFocus ? 1.035f : 1f)
                .scaleY(hasFocus ? 1.035f : 1f)
                .setDuration(120).start());
    }

    private boolean isTelevision() {
        UiModeManager uiModeManager = (UiModeManager) getSystemService(Context.UI_MODE_SERVICE);
        return (uiModeManager != null
                && uiModeManager.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION)
                || getPackageManager().hasSystemFeature("android.software.leanback");
    }

    private static String safeMessage(Exception e) {
        String m = e == null ? "Error" : e.getMessage();
        return m == null || m.trim().isEmpty() ? "Error de conexión" : m.trim();
    }

    private void openHome() {
        handler.removeCallbacks(statePoll);
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
