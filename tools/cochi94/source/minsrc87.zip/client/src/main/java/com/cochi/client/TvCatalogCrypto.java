package com.cochi.client;

import android.util.Base64;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.Mac;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 * Cifrado de catálogo TV exclusivo de CO-CHI v2.
 *
 * No comparte la clave AES-ECB histórica de BLAF. Para cada solicitud TV1/TV2
 * la app genera una pareja EC P-256 temporal. Railway cifra la respuesta con
 * ECDH + HKDF-SHA256 + AES-256-GCM y la clave privada nunca sale del dispositivo.
 */
public final class TvCatalogCrypto {
    private static final String FORMAT = "cochi-tv-crypto-2";
    private static final String ALG = "ECDH-P256+A256GCM";

    private TvCatalogCrypto() {}

    public static RequestContext begin(String sourceKey) throws Exception {
        String source = sourceKey == null ? "" : sourceKey.trim().toLowerCase();
        if (!"tv1".equals(source) && !"tv2".equals(source)) {
            throw new IllegalArgumentException("Cifrado TV V2 solo admite TV1/TV2");
        }
        KeyPairGenerator generator = KeyPairGenerator.getInstance("EC");
        generator.initialize(new ECGenParameterSpec("secp256r1"));
        KeyPair pair = generator.generateKeyPair();
        return new RequestContext(source, pair);
    }

    public static final class RequestContext {
        private final String source;
        private final KeyPair pair;

        private RequestContext(String source, KeyPair pair) {
            this.source = source;
            this.pair = pair;
        }

        public Map<String, String> requestHeaders() {
            Map<String, String> headers = new LinkedHashMap<>();
            headers.put("X-COCHI-TV-Crypto", "2");
            headers.put("X-COCHI-TV-Pub", encodeUrl(pair.getPublic().getEncoded()));
            return Collections.unmodifiableMap(headers);
        }

        public String decryptOrPass(String response) throws Exception {
            String text = response == null ? "" : response.trim();
            if (!text.startsWith("{")) return response;

            JSONObject envelope;
            try {
                envelope = new JSONObject(text);
            } catch (Exception ignored) {
                return response;
            }
            if (!FORMAT.equals(envelope.optString("v", ""))) return response;
            if (!ALG.equals(envelope.optString("alg", ""))) {
                throw new IllegalStateException("Algoritmo TV V2 no soportado");
            }
            if (!source.equals(envelope.optString("src", "").toLowerCase())) {
                throw new IllegalStateException("La respuesta TV V2 no corresponde a " + source);
            }
            int rev = envelope.optInt("rev", 0);
            if (rev != 1) throw new IllegalStateException("Revisión TV V2 no soportada");

            byte[] serverSpki = decodeUrl(envelope.getString("spk"));
            byte[] iv = decodeUrl(envelope.getString("iv"));
            byte[] ciphertext = decodeUrl(envelope.getString("ct"));
            byte[] tag = decodeUrl(envelope.getString("tag"));
            if (iv.length != 12 || tag.length != 16) {
                throw new IllegalStateException("Sobre TV V2 inválido");
            }

            PublicKey serverPublic = KeyFactory.getInstance("EC")
                    .generatePublic(new X509EncodedKeySpec(serverSpki));
            KeyAgreement agreement = KeyAgreement.getInstance("ECDH");
            agreement.init(pair.getPrivate());
            agreement.doPhase(serverPublic, true);
            byte[] shared = agreement.generateSecret();

            byte[] salt = MessageDigest.getInstance("SHA-256").digest(RuntimeStrings.tvCatalogSalt().getBytes(StandardCharsets.UTF_8));
            byte[] info = ("COCHI-TV-CATALOG-V2|" + source).getBytes(StandardCharsets.UTF_8);
            byte[] key = hkdfSha256(shared, salt, info, 32);

            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE,
                    new SecretKeySpec(key, "AES"),
                    new GCMParameterSpec(128, iv));
            cipher.updateAAD((FORMAT + "|" + source + "|1").getBytes(StandardCharsets.UTF_8));

            byte[] combined = new byte[ciphertext.length + tag.length];
            System.arraycopy(ciphertext, 0, combined, 0, ciphertext.length);
            System.arraycopy(tag, 0, combined, ciphertext.length, tag.length);
            byte[] plain = cipher.doFinal(combined);
            return new String(plain, StandardCharsets.UTF_8);
        }
    }

    private static byte[] hkdfSha256(byte[] ikm, byte[] salt, byte[] info, int length)
            throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(salt, "HmacSHA256"));
        byte[] prk = mac.doFinal(ikm);
        ByteArrayOutputStream output = new ByteArrayOutputStream(length);
        byte[] previous = new byte[0];
        int counter = 1;
        while (output.size() < length) {
            mac.init(new SecretKeySpec(prk, "HmacSHA256"));
            mac.update(previous);
            mac.update(info);
            mac.update((byte) counter);
            previous = mac.doFinal();
            int remaining = length - output.size();
            output.write(previous, 0, Math.min(previous.length, remaining));
            counter++;
        }
        return output.toByteArray();
    }

    private static String encodeUrl(byte[] value) {
        return Base64.encodeToString(value, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
    }

    private static byte[] decodeUrl(String value) {
        return Base64.decode(value, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
    }
}
