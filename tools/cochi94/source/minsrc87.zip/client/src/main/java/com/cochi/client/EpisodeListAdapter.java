package com.cochi.client;

import android.app.UiModeManager;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Lista compacta de episodios para la ficha de una serie. */
public final class EpisodeListAdapter extends RecyclerView.Adapter<EpisodeListAdapter.Holder> {

    public interface Listener {
        void onEpisodeClick(Channel episode);
    }

    public static final class Row {
        public final Channel episode;
        public final String status;
        public Row(Channel episode, String status) {
            this.episode = episode;
            this.status = status == null ? "" : status;
        }
    }

    private final Context context;
    private final Listener listener;
    private final List<Row> rows = new ArrayList<>();

    public EpisodeListAdapter(Context context, Listener listener) {
        this.context = context;
        this.listener = listener;
        setHasStableIds(true);
    }

    public void submitList(List<Row> next) {
        rows.clear();
        if (next != null) rows.addAll(next);
        notifyDataSetChanged();
    }

    @Override public long getItemId(int position) {
        String id = rows.get(position).episode.id;
        return id == null || id.isEmpty() ? position : id.hashCode();
    }

    @NonNull
    @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (isTelevision()) return createTelevisionHolder();
        return createMobileHolder();
    }

    private Holder createTelevisionHolder() {
        MaterialCardView card = new MaterialCardView(context);
        card.setCardBackgroundColor(ManagedTheme.color(context, R.color.cochi_tv_surface));
        card.setRadius(dp(16));
        card.setStrokeColor(ManagedTheme.color(context, R.color.cochi_tv_border_soft));
        card.setStrokeWidth(dp(1));
        card.setFocusable(true);
        card.setClickable(true);
        card.setClipToOutline(true);
        RecyclerView.LayoutParams cp = new RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(174));
        cp.setMargins(dp(5), dp(5), dp(5), dp(9));
        card.setLayoutParams(cp);

        LinearLayout root = new LinearLayout(context);
        root.setOrientation(LinearLayout.VERTICAL);

        ImageView image = new ImageView(context);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        image.setImageResource(R.drawable.ic_cochi_series);
        root.addView(image, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(94)));

        LinearLayout info = new LinearLayout(context);
        info.setOrientation(LinearLayout.HORIZONTAL);
        info.setGravity(Gravity.TOP);
        info.setPadding(dp(10), dp(7), dp(10), dp(7));
        root.addView(info, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView number = new TextView(context);
        number.setTextColor(ManagedTheme.color(context, R.color.cochi_accent));
        number.setTextSize(13f);
        number.setTypeface(Typeface.DEFAULT_BOLD);
        number.setLayoutParams(new LinearLayout.LayoutParams(dp(34),
                ViewGroup.LayoutParams.WRAP_CONTENT));
        info.addView(number);

        LinearLayout texts = new LinearLayout(context);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView name = new TextView(context);
        name.setTextColor(ManagedTheme.color(context, R.color.cochi_text));
        name.setTextSize(14f);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setMaxLines(2);
        texts.addView(name);

        TextView status = new TextView(context);
        status.setTextColor(ManagedTheme.color(context, R.color.cochi_accent_2));
        status.setTextSize(11f);
        status.setMaxLines(1);
        texts.addView(status);

        TextView description = new TextView(context);
        description.setTextColor(ManagedTheme.color(context, R.color.cochi_muted));
        description.setTextSize(10f);
        description.setMaxLines(1);
        texts.addView(description);

        info.addView(texts);
        card.addView(root);
        return new Holder(card, image, number, name, status, description);
    }

    private Holder createMobileHolder() {
        MaterialCardView card = new MaterialCardView(context);
        card.setCardBackgroundColor(ManagedTheme.color(context, R.color.cochi_surface));
        card.setRadius(dp(15));
        card.setStrokeColor(ManagedTheme.color(context, R.color.cochi_border));
        card.setStrokeWidth(dp(2));
        card.setFocusable(true);
        card.setClickable(true);
        RecyclerView.LayoutParams cp = new RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(96));
        cp.bottomMargin = dp(10);
        card.setLayoutParams(cp);

        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(8), dp(14), dp(8));

        ImageView image = new ImageView(context);
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setImageResource(R.drawable.ic_cochi_series);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(116), dp(72));
        ip.setMarginEnd(dp(14));
        image.setLayoutParams(ip);
        row.addView(image);

        TextView number = new TextView(context);
        number.setTextColor(ManagedTheme.color(context, R.color.cochi_accent));
        number.setTextSize(16f);
        number.setTypeface(Typeface.DEFAULT_BOLD);
        number.setLayoutParams(new LinearLayout.LayoutParams(dp(48),
                ViewGroup.LayoutParams.WRAP_CONTENT));
        row.addView(number);

        LinearLayout texts = new LinearLayout(context);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setGravity(Gravity.CENTER_VERTICAL);
        texts.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView name = new TextView(context);
        name.setTextColor(ManagedTheme.color(context, R.color.cochi_text));
        name.setTextSize(16f);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setMaxLines(2);
        texts.addView(name);

        TextView status = new TextView(context);
        status.setTextColor(ManagedTheme.color(context, R.color.cochi_accent_2));
        status.setTextSize(13f);
        status.setMaxLines(1);
        texts.addView(status);

        TextView description = new TextView(context);
        description.setTextColor(ManagedTheme.color(context, R.color.cochi_muted));
        description.setTextSize(12f);
        description.setMaxLines(1);
        texts.addView(description);

        row.addView(texts);
        card.addView(row);
        return new Holder(card, image, number, name, status, description);
    }

    @Override public void onBindViewHolder(@NonNull Holder holder, int position) {
        Row row = rows.get(position);
        Channel episode = row.episode;
        holder.number.setText(String.format(Locale.US, "%02d", episode.number));
        holder.name.setText(episode.name);
        holder.status.setText(row.status);
        holder.status.setVisibility(row.status.isEmpty() ? View.GONE : View.VISIBLE);
        holder.description.setText(episode.description);
        holder.description.setVisibility(episode.description == null || episode.description.trim().isEmpty()
                ? View.GONE : View.VISIBLE);
        ImageLoader.load(episode.logo, holder.image);

        holder.card.setOnFocusChangeListener((v, focused) -> {
            boolean television = isTelevision();
            if (television) {
                // Los capítulos responden al DPAD sin esperar una animación de 120 ms.
                holder.card.animate().cancel();
                holder.card.setScaleX(1f);
                holder.card.setScaleY(1f);
                holder.card.setTranslationZ(0f);
                holder.card.setCardElevation(dp(focused ? 4 : 2));
            } else {
                holder.card.animate().scaleX(focused ? 1.025f : 1f)
                        .scaleY(focused ? 1.025f : 1f)
                        .translationZ(focused ? dp(10) : 0)
                        .setDuration(120).start();
            }
            holder.card.setStrokeColor(focused ? ManagedTheme.primary(context) : ManagedTheme.border(context));
            holder.card.setStrokeWidth(dp(focused ? 3 : television ? 1 : 2));
            holder.card.setCardBackgroundColor(focused ? ManagedTheme.selection(context) : ManagedTheme.button(context));
        });
        holder.card.setOnClickListener(v -> {
            int p = holder.getBindingAdapterPosition();
            if (p != RecyclerView.NO_POSITION && listener != null) listener.onEpisodeClick(rows.get(p).episode);
        });
    }

    @Override public int getItemCount() { return rows.size(); }

    private boolean isTelevision() {
        UiModeManager manager = (UiModeManager) context.getSystemService(Context.UI_MODE_SERVICE);
        return (manager != null && manager.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION)
                || context.getPackageManager().hasSystemFeature("android.software.leanback");
    }

    private int dp(int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    static final class Holder extends RecyclerView.ViewHolder {
        final MaterialCardView card;
        final ImageView image;
        final TextView number;
        final TextView name;
        final TextView status;
        final TextView description;

        Holder(MaterialCardView card, ImageView image, TextView number,
               TextView name, TextView status, TextView description) {
            super(card);
            this.card = card;
            this.image = image;
            this.number = number;
            this.name = name;
            this.status = status;
            this.description = description;
        }
    }
}
