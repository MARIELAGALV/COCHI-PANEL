package com.cochi.client;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public final class CatalogRepository {

    // Todos los catálogos se obtienen únicamente desde CO-CHI PANEL mediante
    // sesión de dispositivo. La APK no contiene URLs privadas de GitHub.

    // Misma clave/formato que usa BLAF Manager para los bloques {"code":"..."}.
    // AES-256-ECB + PKCS7 (PKCS5Padding en Java es compatible para AES).
    private static final String BLAF_JSON_AES_KEY =
            "R0JyelFiaDBzZFJWdGtRVTJ4RzZFSVlE";

    // Caché local de Series. Guarda una copia byte-a-byte de la respuesta remota;
    // no altera la estructura ni el contenido de la JSON.
    private static final String SERIES_CACHE_FILE = "cochi_series_catalog_cache.json";
    private static volatile List<Channel> SERIES_MEMORY_ITEMS;
    private static final AtomicBoolean SERIES_REFRESHING = new AtomicBoolean(false);

    // v0.23.39: caché transitoria para que Inicio -> TV1/TV2/Películas no vuelva
    // a descargar el mismo catálogo recién obtenido. Solo vive en memoria y expira
    // rápido; nunca se persiste en disco. También agrupamos solicitudes simultáneas
    // de la misma fuente para evitar dobles descargas en TV Box con poca memoria.
    private static final long FAST_CACHE_TTL_MS = 5L * 60L * 1000L;
    // v0.23.82: tolerancia a caídas breves del panel. Nunca mostramos al cliente
    // host/IP ni el texto técnico de la excepción.
    private static final int NETWORK_RETRY_ATTEMPTS = 3;
    private static final long NETWORK_RETRY_BASE_DELAY_MS = 1200L;
    private static final Map<CatalogSource, FastCacheEntry> FAST_CACHE = new EnumMap<>(CatalogSource.class);
    private static final Map<CatalogSource, List<Callback>> IN_FLIGHT = new EnumMap<>(CatalogSource.class);

    private static final class FastCacheEntry {
        final List<Channel> items;
        final long loadedAtMs;
        FastCacheEntry(List<Channel> items, long loadedAtMs) {
            this.items = items;
            this.loadedAtMs = loadedAtMs;
        }
    }

    public interface Callback {
        void onLoaded(List<Channel> items, boolean fromRemote);
        void onError(String message);
    }

    private CatalogRepository() {}

    public static void load(Context context, CatalogSource source, Callback callback) {
        Context appContext = context.getApplicationContext();

        if (source == CatalogSource.SERIES) {
            new Thread(() -> {
                try {
                    LoadResult result = loadSeriesCatalog(appContext);
                    new Handler(Looper.getMainLooper()).post(
                            () -> callback.onLoaded(result.items, result.fromRemote));
                } catch (Exception e) {
                    new Handler(Looper.getMainLooper()).post(
                            () -> callback.onError("No se pudo actualizar el contenido. Reintentá en unos segundos."));
                }
            }, "cochi-series-load").start();
            return;
        }

        // v0.23.76: TV1/TV2 siempre consultan al PANEL en fresco.
        // Así, ACTUALIZAR en el panel impacta al volver a entrar/recargar Canales
        // sin esperar la caché rápida de 5 minutos. Películas conserva la caché
        // transitoria para no castigar TV Box de pocos recursos.
        final boolean forceFreshFromPanel = source == CatalogSource.TV1 || source == CatalogSource.TV2;

        FastCacheEntry cached;
        synchronized (FAST_CACHE) {
            cached = FAST_CACHE.get(source);
            if (!forceFreshFromPanel
                    && cached != null
                    && !cached.items.isEmpty()
                    && System.currentTimeMillis() - cached.loadedAtMs <= FAST_CACHE_TTL_MS) {
                List<Channel> snapshot = new ArrayList<>(cached.items);
                new Handler(Looper.getMainLooper()).post(() -> callback.onLoaded(snapshot, false));
                return;
            }

            List<Callback> waiters = IN_FLIGHT.get(source);
            if (waiters != null) {
                waiters.add(callback);
                return;
            }
            waiters = new ArrayList<>();
            waiters.add(callback);
            IN_FLIGHT.put(source, waiters);
        }

        new Thread(() -> {
            try {
                String json = downloadProtectedCatalogWithRetry(appContext, source);
                List<Channel> items = parseItems(json);
                // TV2 usa exactamente la URI, ClearKey y headers descifrados desde BA2.json.
                // No se reemplazan hosts ni se aplican URLs antiguas.
                synchronized (FAST_CACHE) {
                    if (!forceFreshFromPanel) {
                        FAST_CACHE.put(source, new FastCacheEntry(new ArrayList<>(items), System.currentTimeMillis()));
                    } else {
                        // Evita que un TV1/TV2 anterior pueda reaparecer por caché.
                        FAST_CACHE.remove(source);
                    }
                }
                dispatchFastLoaded(source, items);
            } catch (Exception e) {
                if (e instanceof BackendClient.BackendException) {
                    int status = ((BackendClient.BackendException) e).statusCode;
                    if (status == 401 || status == 403) {
                        synchronized (FAST_CACHE) {
                            FAST_CACHE.clear();
                        }
                    }
                }
                dispatchFastError(source, "No se pudo actualizar el contenido. Reintentá en unos segundos.");
            }
        }, "cochi-catalog-" + source.name().toLowerCase(Locale.ROOT)).start();
    }

    private static String downloadProtectedCatalogWithRetry(Context context, CatalogSource source) throws Exception {
        Exception last = null;
        for (int attempt = 1; attempt <= NETWORK_RETRY_ATTEMPTS; attempt++) {
            try {
                return BackendClient.downloadProtectedCatalog(context, source);
            } catch (BackendClient.BackendException e) {
                // Acceso rechazado no es un problema transitorio: no insistir.
                if (e.statusCode == 401 || e.statusCode == 403) throw e;
                last = e;
            } catch (Exception e) {
                last = e;
            }
            if (attempt < NETWORK_RETRY_ATTEMPTS) {
                try {
                    Thread.sleep(NETWORK_RETRY_BASE_DELAY_MS * attempt);
                } catch (InterruptedException interrupted) {
                    Thread.currentThread().interrupt();
                    throw interrupted;
                }
            }
        }
        if (last != null) throw last;
        throw new IllegalStateException("No se pudo actualizar el contenido");
    }

    private static void dispatchFastLoaded(CatalogSource source, List<Channel> items) {
        final List<Callback> callbacks;
        synchronized (FAST_CACHE) {
            callbacks = IN_FLIGHT.remove(source);
        }
        if (callbacks == null || callbacks.isEmpty()) return;
        final List<Channel> snapshot = items == null ? new ArrayList<>() : new ArrayList<>(items);
        new Handler(Looper.getMainLooper()).post(() -> {
            for (Callback cb : callbacks) {
                if (cb != null) cb.onLoaded(new ArrayList<>(snapshot), true);
            }
        });
    }

    private static void dispatchFastError(CatalogSource source, String message) {
        final List<Callback> callbacks;
        synchronized (FAST_CACHE) {
            callbacks = IN_FLIGHT.remove(source);
        }
        if (callbacks == null || callbacks.isEmpty()) return;
        new Handler(Looper.getMainLooper()).post(() -> {
            for (Callback cb : callbacks) {
                if (cb != null) cb.onError(message);
            }
        });
    }

    public static void clearTransientCache() {
        synchronized (FAST_CACHE) {
            FAST_CACHE.clear();
            IN_FLIGHT.clear();
        }
    }



    private static final class LoadResult {
        final List<Channel> items;
        final boolean fromRemote;
        LoadResult(List<Channel> items, boolean fromRemote) {
            this.items = items;
            this.fromRemote = fromRemote;
        }
    }

    private static LoadResult loadSeriesCatalog(Context context) throws Exception {
        // Seguridad: Series no puede servirse desde memoria/disco sin validar primero
        // el estado REAL del dispositivo contra CO-CHI PANEL.
        if (!SessionManager.validateAccessBlocking(context)) {
            clearSeriesCache(context);
            throw new IllegalStateException("Dispositivo bloqueado o sin acceso activo");
        }

        // 1) Memoria: volver a Series dentro de la misma sesión es inmediato.
        List<Channel> memory = SERIES_MEMORY_ITEMS;
        if (memory != null && !memory.isEmpty() && !SeriesStore.isEmpty()) {
            refreshSeriesInBackground(context);
            return new LoadResult(new ArrayList<>(memory), false);
        }

        // 2) Disco: mostrar primero la última copia válida y actualizar detrás.
        LoadResult disk = loadSeriesFromDiskCache(context);
        if (disk != null && !disk.items.isEmpty()) {
            SERIES_MEMORY_ITEMS = new ArrayList<>(disk.items);
            refreshSeriesInBackground(context);
            return disk;
        }

        // 3) Primera carga: remoto.
        return loadSeriesRemote(context, true);
    }

    private static LoadResult loadSeriesRemote(Context context, boolean allowLocalFallback) throws Exception {
        String json = downloadProtectedCatalogWithRetry(context, CatalogSource.SERIES);
        List<Channel> parsed = parseSeriesCatalog(json);
        if (parsed.isEmpty()) throw new IllegalStateException("No hay series disponibles");
        SERIES_MEMORY_ITEMS = new ArrayList<>(parsed);
        writeSeriesDiskCache(context, json);
        return new LoadResult(parsed, true);
    }

    private static LoadResult loadSeriesFromDiskCache(Context context) {
        File cache = new File(context.getFilesDir(), SERIES_CACHE_FILE);
        if (!cache.isFile() || cache.length() < 2L) return null;
        try (InputStream input = new FileInputStream(cache)) {
            String json = readAll(input);
            List<Channel> parsed = parseSeriesCatalog(json);
            return parsed.isEmpty() ? null : new LoadResult(parsed, false);
        } catch (Exception ignored) {
            return null;
        }
    }

    private static void writeSeriesDiskCache(Context context, String json) {
        if (json == null || json.trim().isEmpty()) return;
        File target = new File(context.getFilesDir(), SERIES_CACHE_FILE);
        File temp = new File(context.getFilesDir(), SERIES_CACHE_FILE + ".tmp");
        try (FileOutputStream out = new FileOutputStream(temp)) {
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.flush();
            if (target.exists()) target.delete();
            if (!temp.renameTo(target)) {
                try (FileOutputStream direct = new FileOutputStream(target)) {
                    direct.write(json.getBytes(StandardCharsets.UTF_8));
                }
                temp.delete();
            }
        } catch (Exception ignored) {
            temp.delete();
        }
    }

    private static void refreshSeriesInBackground(Context context) {
        if (!SERIES_REFRESHING.compareAndSet(false, true)) return;
        new Thread(() -> {
            try {
                Context app = context.getApplicationContext();
                if (!SessionManager.validateAccessBlocking(app)) {
                    clearSeriesCache(app);
                    return;
                }
                loadSeriesRemote(app, false);
            } catch (BackendClient.BackendException e) {
                if (e.statusCode == 401 || e.statusCode == 403) {
                    clearSeriesCache(context.getApplicationContext());
                }
            } catch (Exception ignored) {
                // Un fallo de red temporal no destruye una copia válida si el acceso no fue rechazado.
            } finally {
                SERIES_REFRESHING.set(false);
            }
        }, "cochi-series-refresh").start();
    }

    /** Borra toda copia local de Series cuando el backend revoca el acceso. */
    public static synchronized void clearSeriesCache(Context context) {
        SERIES_MEMORY_ITEMS = null;
        SeriesStore.clear();
        if (context == null) return;
        try {
            File cache = new File(context.getApplicationContext().getFilesDir(), SERIES_CACHE_FILE);
            if (cache.exists()) cache.delete();
            File temp = new File(context.getApplicationContext().getFilesDir(), SERIES_CACHE_FILE + ".tmp");
            if (temp.exists()) temp.delete();
        } catch (Exception ignored) { }
    }

    /** Precarga Series en segundo plano para que la categoría abra más rápido. */
    public static void prefetchSeries(Context context) {
        if (context == null) return;
        load(context.getApplicationContext(), CatalogSource.SERIES, new Callback() {
            @Override public void onLoaded(List<Channel> items, boolean fromRemote) { }
            @Override public void onError(String message) { }
        });
    }

    public static void loadAdultFromTv1AndTv2(Context context, Callback callback) {
        final List<Channel> combined = new ArrayList<>();
        load(context, CatalogSource.TV1, new Callback() {
            @Override
            public void onLoaded(List<Channel> items, boolean fromRemoteTv1) {
                for (Channel item : items) if (item.adult) combined.add(item);
                load(context, CatalogSource.TV2, new Callback() {
                    @Override
                    public void onLoaded(List<Channel> items2, boolean fromRemoteTv2) {
                        for (Channel item : items2) if (item.adult) combined.add(item);
                        callback.onLoaded(combined, fromRemoteTv1 || fromRemoteTv2);
                    }

                    @Override
                    public void onError(String message) {
                        if (!combined.isEmpty()) callback.onLoaded(combined, fromRemoteTv1);
                        else callback.onError(message);
                    }
                });
            }

            @Override
            public void onError(String message) {
                load(context, CatalogSource.TV2, new Callback() {
                    @Override
                    public void onLoaded(List<Channel> items, boolean fromRemote) {
                        List<Channel> adult = new ArrayList<>();
                        for (Channel item : items) if (item.adult) adult.add(item);
                        callback.onLoaded(adult, fromRemote);
                    }

                    @Override
                    public void onError(String message2) {
                        callback.onError(message2);
                    }
                });
            }
        });
    }



    private static String assetFor(CatalogSource source) {
        switch (source) {
            case TV1: return "tv1_ba1des_real_sanitized.json";
            case TV2: return "tv2_demo.json";
            case MOVIES: return "peliculas_demo.json";
            case SERIES: return "series_demo.json";
            default: return "tv1_ba1des_real_sanitized.json";
        }
    }



    private static String readAsset(Context context, String name) throws Exception {
        try (InputStream input = context.getAssets().open(name)) {
            return readAll(input);
        }
    }

    private static String readAll(InputStream input) throws Exception {
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) out.append(line).append('\n');
        }
        return out.toString();
    }

    private static String firstNonEmpty(String... values) {
        if (values == null) return "";
        for (String value : values) {
            if (value != null && !value.trim().isEmpty()) return value.trim();
        }
        return "";
    }


    /** Series v2: Categoría -> Serie -> Temporada -> Episodio. */
    private static List<Channel> parseSeriesCatalog(String json) throws Exception {
        Object root = new JSONTokener(json).nextValue();
        if (root instanceof JSONObject) {
            JSONObject object = (JSONObject) root;
            if (object.optInt("version", 0) >= 2 && object.optJSONArray("series") != null) {
                List<Channel> v2 = parseSeriesV2(object);
                if (!v2.isEmpty()) return v2;
                throw new IllegalArgumentException("Series v2 todavía no tiene contenido");
            }
        }

        // El formato histórico de BLAF conserva la jerarquía de cada serie dentro
        // de samples/temp. La leemos directamente para poder inferir temporadas.
        if (root instanceof JSONArray) {
            List<Channel> legacyStructured = parseLegacySeriesBlocks((JSONArray) root);
            if (!legacyStructured.isEmpty()) return legacyStructured;
        }

        // Compatibilidad final con formatos planos usados durante el desarrollo.
        return groupSeries(parseItems(json));
    }

    private static List<Channel> parseSeriesV2(JSONObject root) throws Exception {
        Map<String, String> categoryNames = new LinkedHashMap<>();
        Map<String, List<String>> membershipFromCategories = new LinkedHashMap<>();

        JSONArray categories = root.optJSONArray("categories");
        if (categories != null) {
            for (int i = 0; i < categories.length(); i++) {
                JSONObject category = categories.optJSONObject(i);
                if (category == null) continue;
                String name = firstNonEmpty(category.optString("name", ""), "General");
                String id = firstNonEmpty(category.optString("id", ""), SeriesStore.slug(name));
                categoryNames.putIfAbsent(id, name);
                JSONArray ids = category.optJSONArray("seriesIds");
                if (ids == null) ids = category.optJSONArray("series_ids");
                if (ids != null) {
                    for (int j = 0; j < ids.length(); j++) {
                        String seriesId = ids.optString(j, "").trim();
                        if (seriesId.isEmpty()) continue;
                        membershipFromCategories
                                .computeIfAbsent(seriesId, ignored -> new ArrayList<>())
                                .add(id);
                    }
                }
            }
        }

        List<SeriesStore.SeriesInfo> richSeries = new ArrayList<>();
        List<Channel> parents = new ArrayList<>();
        JSONArray seriesArray = root.optJSONArray("series");
        int parentNumber = 1;

        for (int i = 0; i < seriesArray.length(); i++) {
            JSONObject rawSeries = seriesArray.optJSONObject(i);
            if (rawSeries == null) continue;
            JSONObject series = decodeBlafObject(rawSeries);
            if (series == null) continue;

            String name = firstNonEmpty(
                    rawSeries.optString("name", ""),
                    series.optString("name", ""),
                    series.optString("title", ""),
                    "Serie " + (i + 1));
            String id = firstNonEmpty(
                    rawSeries.optString("id", ""),
                    series.optString("id", ""),
                    "series-" + SeriesStore.slug(name));
            String poster = firstNonEmpty(
                    rawSeries.optString("poster", ""), rawSeries.optString("icon", ""),
                    series.optString("poster", ""), series.optString("icon", ""),
                    series.optString("image", ""));
            String backdrop = firstNonEmpty(
                    rawSeries.optString("backdrop", ""), rawSeries.optString("background", ""),
                    series.optString("backdrop", ""), series.optString("background", ""));
            String year = firstNonEmpty(
                    rawSeries.optString("year", ""), series.optString("year", ""),
                    rawSeries.optString("anio", ""), series.optString("anio", ""));
            String genre = firstNonEmpty(
                    rawSeries.optString("genre", ""), series.optString("genre", ""),
                    rawSeries.optString("genero", ""), series.optString("genero", ""));
            String synopsis = firstNonEmpty(
                    rawSeries.optString("synopsis", ""), series.optString("synopsis", ""),
                    rawSeries.optString("description", ""), series.optString("description", ""),
                    rawSeries.optString("descripcion", ""), series.optString("descripcion", ""));
            boolean adult = rawSeries.optBoolean("adult", series.optBoolean("adult", false));

            List<String> categoryIds = new ArrayList<>();
            List<String> fromBlocks = membershipFromCategories.get(id);
            if (fromBlocks != null) categoryIds.addAll(fromBlocks);
            collectStringArray(rawSeries.optJSONArray("categories"), categoryIds);
            collectStringArray(series.optJSONArray("categories"), categoryIds);
            String oneCategory = firstNonEmpty(
                    rawSeries.optString("category", ""), series.optString("category", ""),
                    rawSeries.optString("categoria", ""), series.optString("categoria", ""));
            if (!oneCategory.isEmpty()) categoryIds.add(oneCategory);
            categoryIds = normalizeCategoryIds(categoryIds, categoryNames);
            if (categoryIds.isEmpty()) {
                categoryNames.putIfAbsent("general", "General");
                categoryIds.add("general");
            }

            List<SeriesStore.Season> seasons = parseV2Seasons(series, rawSeries, id, name, poster);
            if (seasons.isEmpty()) continue;

            SeriesStore.SeriesInfo info = new SeriesStore.SeriesInfo(
                    id, name, poster, backdrop, year, genre, synopsis, adult, categoryIds, seasons,
                    parsePlaybackMarkers(series, rawSeries));
            richSeries.add(info);

            String category = categoryNames.get(categoryIds.get(0));
            if (category == null) category = "General";
            parents.add(seriesParentChannel(info, category, parentNumber++));
        }

        SeriesStore.replaceCatalog(richSeries, categoryNames);
        return parents;
    }

    private static List<SeriesStore.Season> parseV2Seasons(
            JSONObject series,
            JSONObject rawSeries,
            String seriesId,
            String seriesName,
            String poster) {
        JSONArray seasonsArray = series.optJSONArray("seasons");
        if (seasonsArray == null) seasonsArray = rawSeries.optJSONArray("seasons");
        if (seasonsArray == null) seasonsArray = series.optJSONArray("temporadas");
        if (seasonsArray == null) seasonsArray = rawSeries.optJSONArray("temporadas");

        if (seasonsArray == null) {
            JSONArray episodes = firstArray(series, "episodes", "episodios", "capitulos", "capítulos", "temp");
            if (episodes == null) episodes = firstArray(rawSeries, "episodes", "episodios", "capitulos", "capítulos", "temp");
            return inferSeasonsFromEpisodes(episodes, seriesId, seriesName, poster);
        }

        List<SeriesStore.Season> seasons = new ArrayList<>();
        for (int i = 0; i < seasonsArray.length(); i++) {
            JSONObject rawSeason = seasonsArray.optJSONObject(i);
            if (rawSeason == null) continue;
            JSONObject seasonObject = decodeBlafObject(rawSeason);
            if (seasonObject == null) seasonObject = rawSeason;
            int seasonNumber = seasonObject.optInt("number",
                    seasonObject.optInt("numero", inferLeadingNumber(seasonObject.optString("name", ""), i + 1)));
            if (seasonNumber <= 0) seasonNumber = i + 1;
            String seasonName = firstNonEmpty(
                    rawSeason.optString("name", ""), seasonObject.optString("name", ""),
                    "Temporada " + seasonNumber);
            String seasonPoster = firstNonEmpty(
                    rawSeason.optString("icon", ""), rawSeason.optString("poster", ""),
                    seasonObject.optString("icon", ""), seasonObject.optString("poster", ""), poster);
            JSONArray episodesArray = firstArray(seasonObject,
                    "episodes", "episodios", "capitulos", "capítulos", "temp", "samples", "items");
            if (episodesArray == null) episodesArray = firstArray(rawSeason,
                    "episodes", "episodios", "capitulos", "capítulos", "temp", "samples", "items");
            List<Channel> episodes = parseEpisodeArray(
                    episodesArray, seriesId, seriesName, seasonNumber, seasonPoster);
            if (!episodes.isEmpty()) seasons.add(new SeriesStore.Season(seasonNumber, seasonName, episodes));
        }
        return seasons;
    }

    private static List<Channel> parseLegacySeriesBlocks(JSONArray groups) {
        Map<String, String> categoryNames = new LinkedHashMap<>();
        List<SeriesStore.SeriesInfo> richSeries = new ArrayList<>();
        List<Channel> parents = new ArrayList<>();
        int parentNumber = 1;

        for (int g = 0; g < groups.length(); g++) {
            JSONObject group = groups.optJSONObject(g);
            if (group == null) continue;
            String categoryName = firstNonEmpty(
                    group.optString("name", ""), group.optString("category", ""), "General");
            String categoryId = SeriesStore.slug(categoryName);
            categoryNames.putIfAbsent(categoryId, categoryName);

            JSONArray samples = firstArray(group, "samples", "items", "series");
            if (samples == null) continue;

            for (int i = 0; i < samples.length(); i++) {
                JSONObject rawSeries = samples.optJSONObject(i);
                if (rawSeries == null) continue;
                JSONObject series = decodeBlafObject(rawSeries);
                if (series == null) continue;

                String name = firstNonEmpty(
                        rawSeries.optString("name", ""), series.optString("name", ""),
                        series.optString("title", ""), "Serie " + (i + 1));
                String id = firstNonEmpty(
                        rawSeries.optString("id", ""), series.optString("id", ""),
                        "series-" + SeriesStore.slug(categoryName + "-" + name));
                String poster = firstNonEmpty(
                        rawSeries.optString("icon", ""), rawSeries.optString("poster", ""),
                        series.optString("icon", ""), series.optString("poster", ""),
                        series.optString("image", ""));
                String backdrop = firstNonEmpty(
                        rawSeries.optString("backdrop", ""), series.optString("backdrop", ""));
                String synopsis = firstNonEmpty(
                        rawSeries.optString("synopsis", ""), series.optString("synopsis", ""),
                        rawSeries.optString("description", ""), series.optString("description", ""));

                JSONArray nested = firstArray(series,
                        "seasons", "temporadas", "temp", "episodes", "episodios", "capitulos", "capítulos", "items");
                if (nested == null) nested = firstArray(rawSeries,
                        "seasons", "temporadas", "temp", "episodes", "episodios", "capitulos", "capítulos", "items");

                List<SeriesStore.Season> seasons;
                if (looksLikeSeasonContainers(nested)) {
                    seasons = parseV2Seasons(series, rawSeries, id, name, poster);
                } else {
                    seasons = inferSeasonsFromEpisodes(nested, id, name, poster);
                }

                // Algunas listas muy antiguas tienen una única entrada reproducible por serie.
                if (seasons.isEmpty()) {
                    Channel direct = playableEpisode(rawSeries, id, name, 1, 1, poster);
                    if (direct != null) {
                        seasons.add(new SeriesStore.Season(1, "Temporada 1",
                                java.util.Collections.singletonList(direct)));
                    }
                }
                if (seasons.isEmpty()) continue;

                SeriesStore.SeriesInfo info = new SeriesStore.SeriesInfo(
                        id, name, poster, backdrop,
                        firstNonEmpty(rawSeries.optString("year", ""), series.optString("year", "")),
                        firstNonEmpty(rawSeries.optString("genre", ""), series.optString("genre", "")),
                        synopsis,
                        rawSeries.optBoolean("adult", series.optBoolean("adult", false)) || isAdultCategory(categoryName),
                        java.util.Collections.singletonList(categoryId), seasons,
                        parsePlaybackMarkers(series, rawSeries));
                richSeries.add(info);
                parents.add(seriesParentChannel(info, categoryName, parentNumber++));
            }
        }

        SeriesStore.replaceCatalog(richSeries, categoryNames);
        return parents;
    }

    private static boolean looksLikeSeasonContainers(JSONArray array) {
        if (array == null || array.length() == 0) return false;
        int checked = 0;
        int containers = 0;
        for (int i = 0; i < array.length() && checked < 5; i++) {
            JSONObject raw = array.optJSONObject(i);
            if (raw == null) continue;
            JSONObject item = decodeBlafObject(raw);
            if (item == null) item = raw;
            checked++;
            if (firstArray(item, "episodes", "episodios", "capitulos", "capítulos", "temp", "samples", "items") != null
                    && firstNonEmpty(item.optString("url", ""), item.optString("uri", ""), item.optString("stream", "")).isEmpty()) {
                containers++;
            }
        }
        return checked > 0 && containers >= Math.max(1, checked / 2);
    }

    private static List<SeriesStore.Season> inferSeasonsFromEpisodes(
            JSONArray episodesArray,
            String seriesId,
            String seriesName,
            String poster) {
        Map<Integer, List<Channel>> bySeason = new LinkedHashMap<>();
        if (episodesArray == null) return new ArrayList<>();

        for (int i = 0; i < episodesArray.length(); i++) {
            JSONObject raw = episodesArray.optJSONObject(i);
            if (raw == null) continue;
            JSONObject decoded = decodeBlafObject(raw);
            if (decoded == null) decoded = raw;
            String name = firstNonEmpty(raw.optString("name", ""), decoded.optString("name", ""));
            int seasonNumber = decoded.optInt("season", decoded.optInt("temporada", inferSeasonNumber(name, 1)));
            if (seasonNumber <= 0) seasonNumber = 1;
            List<Channel> list = bySeason.computeIfAbsent(seasonNumber, ignored -> new ArrayList<>());
            int episodeNumber = decoded.optInt("number",
                    decoded.optInt("episode", decoded.optInt("episodio", inferEpisodeNumber(name, list.size() + 1))));
            if (episodeNumber <= 0) episodeNumber = list.size() + 1;
            Channel episode = playableEpisode(raw, seriesId, seriesName, seasonNumber, episodeNumber, poster);
            if (episode != null) list.add(episode);
        }

        List<SeriesStore.Season> seasons = new ArrayList<>();
        for (Map.Entry<Integer, List<Channel>> entry : bySeason.entrySet()) {
            seasons.add(new SeriesStore.Season(entry.getKey(), "Temporada " + entry.getKey(), entry.getValue()));
        }
        return seasons;
    }

    private static List<Channel> parseEpisodeArray(
            JSONArray array,
            String seriesId,
            String seriesName,
            int seasonNumber,
            String poster) {
        List<Channel> episodes = new ArrayList<>();
        if (array == null) return episodes;
        for (int i = 0; i < array.length(); i++) {
            JSONObject raw = array.optJSONObject(i);
            if (raw == null) continue;
            JSONObject decoded = decodeBlafObject(raw);
            if (decoded == null) decoded = raw;
            String rawName = firstNonEmpty(raw.optString("name", ""), decoded.optString("name", ""));
            int episodeNumber = decoded.optInt("number",
                    decoded.optInt("episode", decoded.optInt("episodio", inferEpisodeNumber(rawName, i + 1))));
            if (episodeNumber <= 0) episodeNumber = i + 1;
            Channel episode = playableEpisode(raw, seriesId, seriesName, seasonNumber, episodeNumber, poster);
            if (episode != null) episodes.add(episode);
        }
        return episodes;
    }

    /**
     * Metadatos opcionales de plantilla/redirección que puede traer el catálogo:
     *   isTemplate (bool), nameRedirect, codeRedirect, template.
     * Se leen de dos objetos (decodificado BLAF y raw) con soporte camelCase y
     * snake_case. Si el catálogo no los trae, quedan los valores por defecto.
     */
    private static final class TemplateMeta {
        final boolean isTemplate;
        final String nameRedirect;
        final String codeRedirect;
        final String template;

        TemplateMeta(boolean isTemplate, String nameRedirect, String codeRedirect, String template) {
            this.isTemplate = isTemplate;
            this.nameRedirect = nameRedirect == null ? "" : nameRedirect.trim();
            this.codeRedirect = codeRedirect == null ? "" : codeRedirect.trim();
            this.template = template == null ? "" : template.trim();
        }

        static TemplateMeta empty() {
            return new TemplateMeta(false, "", "", "");
        }

        static TemplateMeta from(JSONObject primary, JSONObject fallback) {
            JSONObject a = primary != null ? primary : null;
            JSONObject b = fallback != null ? fallback : null;
            boolean isTemplate = (a != null && a.optBoolean("isTemplate", a.optBoolean("is_template", false)))
                    || (b != null && b.optBoolean("isTemplate", b.optBoolean("is_template", false)));
            String nameRedirect = firstNonEmpty(
                    a == null ? "" : a.optString("nameRedirect", ""),
                    a == null ? "" : a.optString("name_redirect", ""),
                    b == null ? "" : b.optString("nameRedirect", ""),
                    b == null ? "" : b.optString("name_redirect", ""));
            String codeRedirect = firstNonEmpty(
                    a == null ? "" : a.optString("codeRedirect", ""),
                    a == null ? "" : a.optString("code_redirect", ""),
                    b == null ? "" : b.optString("codeRedirect", ""),
                    b == null ? "" : b.optString("code_redirect", ""));
            String template = firstNonEmpty(
                    a == null ? "" : a.optString("template", ""),
                    b == null ? "" : b.optString("template", ""));
            return new TemplateMeta(isTemplate, nameRedirect, codeRedirect, template);
        }
    }

    private static Channel playableEpisode(
            JSONObject raw,
            String seriesId,
            String seriesName,
            int seasonNumber,
            int episodeNumber,
            String inheritedPoster) {
        if (raw == null) return null;
        JSONObject playback = decodeBlafObject(raw);
        if (playback == null) playback = raw;

        String url = firstNonEmpty(
                playback.optString("url", ""), playback.optString("uri", ""), playback.optString("stream", ""),
                raw.optString("url", ""), raw.optString("uri", ""), raw.optString("stream", ""));

        String name = firstNonEmpty(
                raw.optString("name", ""), raw.optString("title", ""),
                playback.optString("name", ""), playback.optString("title", ""),
                "Episodio " + episodeNumber);
        String logo = firstNonEmpty(
                raw.optString("icon", ""), raw.optString("poster", ""), raw.optString("image", ""),
                playback.optString("icon", ""), playback.optString("poster", ""), playback.optString("image", ""),
                inheritedPoster);
        String description = firstNonEmpty(
                raw.optString("description", ""), raw.optString("synopsis", ""),
                playback.optString("description", ""), playback.optString("synopsis", ""));
        String drmScheme = firstNonEmpty(playback.optString("drm_scheme", ""), raw.optString("drm_scheme", ""));
        String explicitType = firstNonEmpty(
                playback.optString("type", ""), playback.optString("tipo", ""),
                raw.optString("type", ""), raw.optString("tipo", ""));
        String type = inferType(explicitType, url, drmScheme);
        String keyPairs = parseKeyPairsFromItem(playback, drmScheme);
        if (keyPairs.isEmpty()) keyPairs = parseKeyPairsFromItem(raw, drmScheme);
        Map<String, String> headers = parseHeaders(playback);
        if (headers.isEmpty()) headers = parseHeaders(raw);

        List<StreamSource> sources = buildNormalizedSources(
                playback, raw, url, type, drmScheme, keyPairs, headers);
        StreamSource primarySource = firstPlayableSource(sources);
        if (primarySource == null) return null;
        url = primarySource.url;
        type = primarySource.type;
        keyPairs = primarySource.drm.clearKeyPairs;
        headers = primarySource.headers;
        HeaderResolver.learnFrom(url, headers);

        String id = firstNonEmpty(
                raw.optString("id", ""), playback.optString("id", ""),
                seriesId + "-s" + seasonNumber + "e" + episodeNumber);
        TemplateMeta meta = TemplateMeta.from(playback, raw);
        return new Channel(
                id,
                episodeNumber,
                name,
                type,
                url,
                raw.optBoolean("adult", playback.optBoolean("adult", false)),
                keyPairs,
                headers,
                "Temporada " + seasonNumber,
                logo,
                description,
                sources,
                meta.isTemplate,
                meta.nameRedirect,
                meta.codeRedirect,
                meta.template);
    }

    private static Channel seriesParentChannel(SeriesStore.SeriesInfo info, String category, int number) {
        String seasonsText = info.seasons.size() == 1
                ? "1 temporada" : info.seasons.size() + " temporadas";
        String episodesText = info.episodeCount() == 1
                ? "1 capítulo" : info.episodeCount() + " capítulos";
        String meta = seasonsText + " · " + episodesText;
        if (!info.year.isEmpty()) meta = info.year + " · " + meta;
        if (!info.genre.isEmpty()) meta = info.genre + " · " + meta;
        return new Channel(
                info.id, number, info.name, "series", "", info.adult, "",
                new LinkedHashMap<>(), category, info.poster, meta);
    }

    private static void collectStringArray(JSONArray array, List<String> out) {
        if (array == null || out == null) return;
        for (int i = 0; i < array.length(); i++) {
            String value = array.optString(i, "").trim();
            if (!value.isEmpty()) out.add(value);
        }
    }

    private static List<String> normalizeCategoryIds(List<String> raw, Map<String, String> categoryNames) {
        List<String> out = new ArrayList<>();
        for (String value : raw) {
            String clean = value == null ? "" : value.trim();
            if (clean.isEmpty()) continue;
            String id = clean;
            if (!categoryNames.containsKey(id)) {
                for (Map.Entry<String, String> entry : categoryNames.entrySet()) {
                    if (clean.equalsIgnoreCase(entry.getValue())) {
                        id = entry.getKey();
                        break;
                    }
                }
            }
            if (!categoryNames.containsKey(id)) {
                id = SeriesStore.slug(clean);
                categoryNames.putIfAbsent(id, clean);
            }
            if (!out.contains(id)) out.add(id);
        }
        return out;
    }

    private static SeriesStore.PlaybackMarkers parsePlaybackMarkers(JSONObject primary, JSONObject fallback) {
        JSONObject root = primary == null ? null : primary.optJSONObject("playbackMarkers");
        if (root == null && fallback != null) root = fallback.optJSONObject("playbackMarkers");
        if (root == null) return SeriesStore.PlaybackMarkers.empty();

        JSONObject seasonsObject = root.optJSONObject("seasons");
        if (seasonsObject == null) return SeriesStore.PlaybackMarkers.empty();

        Map<Integer, SeriesStore.SeasonMarkers> seasons = new LinkedHashMap<>();
        java.util.Iterator<String> keys = seasonsObject.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            JSONObject seasonObject = seasonsObject.optJSONObject(key);
            if (seasonObject == null) continue;
            int seasonNumber = safeInt(key, seasonObject.optInt("number", -1));
            if (seasonNumber <= 0) continue;

            SeriesStore.EpisodeMarkers defaults = parseEpisodeMarkers(seasonObject);
            Map<Integer, SeriesStore.EpisodeMarkers> overrides = new LinkedHashMap<>();
            JSONObject episodes = seasonObject.optJSONObject("episodes");
            if (episodes != null) {
                java.util.Iterator<String> episodeKeys = episodes.keys();
                while (episodeKeys.hasNext()) {
                    String episodeKey = episodeKeys.next();
                    JSONObject episodeObject = episodes.optJSONObject(episodeKey);
                    if (episodeObject == null) continue;
                    int episodeNumber = safeInt(episodeKey, -1);
                    if (episodeNumber <= 0) continue;
                    overrides.put(episodeNumber, parseEpisodeMarkers(episodeObject));
                }
            }
            seasons.put(seasonNumber, new SeriesStore.SeasonMarkers(defaults, overrides));
        }
        return new SeriesStore.PlaybackMarkers(seasons);
    }

    private static SeriesStore.EpisodeMarkers parseEpisodeMarkers(JSONObject object) {
        if (object == null) return new SeriesStore.EpisodeMarkers(null, null, -1L);
        SeriesStore.MarkerRange recap = parseMarkerRange(object.optJSONObject("recap"));
        SeriesStore.MarkerRange intro = parseMarkerRange(object.optJSONObject("intro"));
        long nextEpisodeAtMs = object.has("nextEpisodeAt")
                ? Math.max(0L, Math.round(object.optDouble("nextEpisodeAt", -1D) * 1000D))
                : -1L;
        return new SeriesStore.EpisodeMarkers(recap, intro, nextEpisodeAtMs);
    }

    private static SeriesStore.MarkerRange parseMarkerRange(JSONObject object) {
        if (object == null || !object.has("start") || !object.has("end")) return null;
        long startMs = Math.max(0L, Math.round(object.optDouble("start", 0D) * 1000D));
        long endMs = Math.max(0L, Math.round(object.optDouble("end", 0D) * 1000D));
        if (endMs <= startMs) return null;
        return new SeriesStore.MarkerRange(startMs, endMs);
    }

    private static int inferSeasonNumber(String name, int fallback) {
        String value = name == null ? "" : name.trim();
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(?i)(?:^|[^0-9])S(?:EASON)?\\s*0*(\\d{1,2})[^0-9]*E\\s*0*\\d+")
                .matcher(value);
        if (m.find()) return safeInt(m.group(1), fallback);
        m = java.util.regex.Pattern.compile("(?i)(?:^|[^0-9])(\\d{1,2})\\s*[xX-]\\s*\\d{1,3}").matcher(value);
        if (m.find()) return safeInt(m.group(1), fallback);
        return fallback;
    }

    private static int inferEpisodeNumber(String name, int fallback) {
        String value = name == null ? "" : name.trim();
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(?i)S(?:EASON)?\\s*0*\\d{1,2}[^0-9]*E\\s*0*(\\d{1,3})")
                .matcher(value);
        if (m.find()) return safeInt(m.group(1), fallback);
        m = java.util.regex.Pattern.compile("(?i)(?:^|[^0-9])\\d{1,2}\\s*[xX-]\\s*0*(\\d{1,3})").matcher(value);
        if (m.find()) return safeInt(m.group(1), fallback);
        m = java.util.regex.Pattern.compile("(?i)(?:episodio|episode|cap[ií]tulo|cap)\\s*0*(\\d{1,3})").matcher(value);
        if (m.find()) return safeInt(m.group(1), fallback);
        return fallback;
    }

    private static int inferLeadingNumber(String name, int fallback) {
        if (name == null) return fallback;
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{1,2})").matcher(name);
        return m.find() ? safeInt(m.group(1), fallback) : fallback;
    }

    private static int safeInt(String raw, int fallback) {
        try { return Integer.parseInt(raw); } catch (Exception ignored) { return fallback; }
    }

    /**
     * Acepta dos familias de JSON:
     * 1) formato CO-CHI plano: {"items":[...]}
     * 2) formato BA1DES: [{"name":"CATEGORIA","samples":[...]}]
     */
    public static Channel parseResolvedTv2Playback(String json) throws Exception {
        List<Channel> items = parseItems(json);
        if (items == null || items.isEmpty()) throw new IllegalArgumentException("Respuesta TV2 sin fuente reproducible");
        return items.get(0);
    }

    private static List<Channel> parseItems(String json) throws Exception {
        String trimmed = json == null ? "" : json.trim();
        if (trimmed.startsWith("#EXTM3U") || trimmed.contains("\n#EXTINF:")) {
            return parseM3uPlaylist(json);
        }
        Object root = new JSONTokener(json).nextValue();
        if (root instanceof JSONArray) {
            return parseCategoryBlocks((JSONArray) root);
        }
        if (!(root instanceof JSONObject)) {
            throw new IllegalArgumentException("JSON no reconocido");
        }

        JSONObject object = (JSONObject) root;
        JSONArray flat = object.optJSONArray("items");
        if (flat == null) flat = object.optJSONArray("channels");
        if (flat != null) return parseFlatArray(flat, null, 1);

        JSONArray groups = object.optJSONArray("categories");
        if (groups == null) groups = object.optJSONArray("groups");
        if (groups == null) groups = object.optJSONArray("sections");
        if (groups != null) return parseCategoryBlocks(groups);

        throw new IllegalArgumentException("Falta items/channels o bloques de categorías");
    }

    /**
     * Compatibilidad aditiva con listas M3U/M3U8. No cambia el parser JSON histórico.
     * Reconoce EXTINF, KODIPROP ClearKey, --key KID:KEY y opciones VLC de headers.
     */
    private static List<Channel> parseM3uPlaylist(String text) {
        List<Channel> out = new ArrayList<>();
        if (text == null) return out;

        String currentName = "";
        String currentCategory = "General";
        String currentLogo = "";
        String currentId = "";
        int currentNumber = 0;
        boolean currentAdult = false;
        StringBuilder currentKeys = new StringBuilder();
        Map<String, String> currentHeaders = new LinkedHashMap<>();
        String currentUrl = "";
        boolean haveEntry = false;

        String pendingKodiKeys = "";
        Map<String, String> pendingHeaders = new LinkedHashMap<>();
        int fallbackNumber = 1;

        String normalized = text.replace("\r\n", "\n").replace('\r', '\n');
        String[] lines = normalized.split("\n");
        for (String rawLine : lines) {
            String line = rawLine == null ? "" : rawLine.trim();
            if (line.isEmpty()) continue;

            if (line.regionMatches(true, 0, "#KODIPROP:", 0, 10)) {
                int eq = line.indexOf('=');
                String prop = eq > 0 ? line.substring(10, eq).trim() : "";
                String value = eq > 0 ? line.substring(eq + 1).trim() : "";
                if (prop.toLowerCase(Locale.ROOT).contains("license_key")) {
                    String parsedKeys = parsePackedKeyArguments(value);
                    if (haveEntry && currentUrl.isEmpty()) appendKeyPairs(currentKeys, parsedKeys);
                    else pendingKodiKeys = mergeKeyPairs(pendingKodiKeys, parsedKeys);
                }
                continue;
            }

            if (line.regionMatches(true, 0, "#EXTVLCOPT:", 0, 11)) {
                int eq = line.indexOf('=');
                if (eq > 0) {
                    String key = line.substring(11, eq).trim().toLowerCase(Locale.ROOT);
                    String value = line.substring(eq + 1).trim();
                    Map<String, String> targetHeaders = haveEntry && currentUrl.isEmpty() ? currentHeaders : pendingHeaders;
                    if (key.equals("http-referrer") || key.equals("http-referer")) targetHeaders.put("Referer", value);
                    else if (key.equals("http-origin")) targetHeaders.put("Origin", value);
                    else if (key.equals("http-user-agent")) targetHeaders.put("User-Agent", value);
                }
                continue;
            }

            if (line.regionMatches(true, 0, "#EXTHTTP:", 0, 9)) {
                try {
                    JSONObject object = new JSONObject(line.substring(9).trim());
                    mergeHeaderObject(object, haveEntry && currentUrl.isEmpty() ? currentHeaders : pendingHeaders);
                } catch (Exception ignored) { }
                continue;
            }

            if (line.regionMatches(true, 0, "#EXTINF:", 0, 8)) {
                if (haveEntry && !currentUrl.isEmpty()) {
                    out.add(buildM3uChannel(currentId, currentNumber, currentName, currentCategory,
                            currentLogo, currentAdult, currentUrl, currentKeys.toString(), currentHeaders,
                            fallbackNumber++));
                }

                haveEntry = true;
                currentUrl = "";
                currentKeys.setLength(0);
                appendKeyPairs(currentKeys, pendingKodiKeys);
                currentHeaders = new LinkedHashMap<>(pendingHeaders);
                pendingKodiKeys = "";
                pendingHeaders.clear();

                String info = line.substring(8).trim();
                int comma = findM3uInfoComma(info);
                String attrs = comma >= 0 ? info.substring(0, comma) : info;
                currentName = comma >= 0 ? info.substring(comma + 1).trim() : "";
                currentId = m3uAttribute(attrs, "tvg-id");
                currentLogo = m3uAttribute(attrs, "tvg-logo");
                currentCategory = firstNonEmpty(
                        m3uAttribute(attrs, "group-title"),
                        m3uAttribute(attrs, "tvg-group"),
                        "General");
                String chno = m3uAttribute(attrs, "tvg-chno");
                currentNumber = safeInt(chno, 0);
                currentAdult = isAdultCategory(currentCategory);
                continue;
            }

            if (line.startsWith("--key") && haveEntry) {
                appendKeyPairs(currentKeys, parsePackedKeyArguments(line));
                continue;
            }

            if (!line.startsWith("#") && haveEntry && currentUrl.isEmpty()) {
                ParsedStreamSpec spec = parseInlineStreamSpec(line);
                currentUrl = spec.url;
                appendKeyPairs(currentKeys, spec.keyPairs);
            }
        }

        if (haveEntry && !currentUrl.isEmpty()) {
            out.add(buildM3uChannel(currentId, currentNumber, currentName, currentCategory,
                    currentLogo, currentAdult, currentUrl, currentKeys.toString(), currentHeaders,
                    fallbackNumber));
        }
        return out;
    }

    private static Channel buildM3uChannel(
            String id, int number, String name, String category, String logo, boolean adult,
            String url, String keyPairs, Map<String, String> headers, int fallbackNumber) {
        int finalNumber = number > 0 ? number : fallbackNumber;
        String finalName = firstNonEmpty(name, "Canal " + finalNumber);
        String finalId = firstNonEmpty(id, slug(category) + "-" + finalNumber);
        String type = inferType("", url, keyPairs == null || keyPairs.isEmpty() ? "" : "clearkey");
        HeaderResolver.learnFrom(url, headers);
        return new Channel(finalId, finalNumber, finalName, type, url, adult,
                keyPairs, headers, category, logo, "");
    }

    private static int findM3uInfoComma(String info) {
        boolean quoted = false;
        for (int i = 0; i < info.length(); i++) {
            char c = info.charAt(i);
            if (c == '"') quoted = !quoted;
            else if (c == ',' && !quoted) return i;
        }
        return -1;
    }

    private static String m3uAttribute(String attrs, String name) {
        Pattern pattern = Pattern.compile("(?i)(?:^|\\s)" + Pattern.quote(name) + "\\s*=\\s*(?:\\\"([^\\\"]*)\\\"|'([^']*)'|([^\\s,]+))");
        Matcher matcher = pattern.matcher(attrs == null ? "" : attrs);
        if (!matcher.find()) return "";
        for (int i = 1; i <= 3; i++) {
            String value = matcher.group(i);
            if (value != null) return value.trim();
        }
        return "";
    }

    private static final class ParsedStreamSpec {
        final String url;
        final String keyPairs;
        ParsedStreamSpec(String url, String keyPairs) {
            this.url = url == null ? "" : url.trim();
            this.keyPairs = keyPairs == null ? "" : keyPairs.trim();
        }
    }

    /** Separa una URL de argumentos tipo: URL --key KID:KEY --key KID:KEY. */
    private static ParsedStreamSpec parseInlineStreamSpec(String raw) {
        if (raw == null) return new ParsedStreamSpec("", "");
        String clean = raw.trim();
        Matcher marker = Pattern.compile("(?i)\\s+--key(?:\\s+|=)").matcher(clean);
        if (!marker.find()) return new ParsedStreamSpec(clean, "");
        String url = clean.substring(0, marker.start()).trim();
        String args = clean.substring(marker.start()).trim();
        return new ParsedStreamSpec(url, parsePackedKeyArguments(args));
    }

    private static String parsePackedKeyArguments(String raw) {
        if (raw == null) return "";
        String value = raw.trim();
        StringBuilder out = new StringBuilder();

        Matcher keyArg = Pattern.compile("(?i)--key(?:\\s+|=)([0-9a-fA-F]{32})\\s*:\\s*([0-9a-fA-F]{32})").matcher(value);
        while (keyArg.find()) appendNormalizedPair(out, keyArg.group(1), keyArg.group(2));
        if (out.length() > 0) return out.toString();

        String sanitized = value.replace('|', ',');
        String[] entries = sanitized.split("[,;\\r\\n\\s]+");
        for (String entry : entries) {
            String candidate = entry.trim();
            if (candidate.startsWith("--key=")) candidate = candidate.substring(6);
            else if (candidate.equalsIgnoreCase("--key")) continue;
            appendPackedKeyPair(out, candidate);
        }
        return out.toString();
    }

    private static String mergeKeyPairs(String first, String second) {
        StringBuilder out = new StringBuilder();
        appendKeyPairs(out, first);
        appendKeyPairs(out, second);
        return out.toString();
    }

    private static void appendKeyPairs(StringBuilder out, String packed) {
        if (packed == null || packed.trim().isEmpty()) return;
        for (String entry : packed.split("[,;\\r\\n]+")) appendPackedKeyPair(out, entry);
    }


    private static boolean isRemotePlaylistType(String rawType) {
        if (rawType == null) return false;
        String value = rawType.trim().toLowerCase(Locale.ROOT).replace('-', '_');
        return value.equals("remote_playlist") || value.equals("m3u_playlist") || value.equals("playlist_remote");
    }

    /**
     * Descarga una playlist de texto para una entrada remote_playlist. Sólo admite HTTP(S),
     * usa timeouts cortos y limita el tamaño para que una fuente defectuosa no bloquee la app.
     */
    private static String downloadRemotePlaylist(String rawUrl) throws Exception {
        URL url = new URL(rawUrl);
        String protocol = url.getProtocol() == null ? "" : url.getProtocol().toLowerCase(Locale.ROOT);
        if (!protocol.equals("https") && !protocol.equals("http")) {
            throw new IllegalArgumentException("Playlist remota: protocolo no permitido");
        }

        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setConnectTimeout(7000);
        connection.setReadTimeout(10000);
        connection.setInstanceFollowRedirects(true);
        connection.setRequestProperty("Accept", "application/vnd.apple.mpegurl, application/x-mpegURL, text/plain, */*");
        connection.setRequestProperty("User-Agent", "CO-CHI/Android");

        try {
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) {
                throw new IllegalStateException("Playlist remota HTTP " + status);
            }
            int declaredLength = connection.getContentLength();
            final int maxBytes = 5 * 1024 * 1024;
            if (declaredLength > maxBytes) {
                throw new IllegalStateException("Playlist remota demasiado grande");
            }

            try (InputStream input = connection.getInputStream()) {
                byte[] buffer = new byte[8192];
                java.io.ByteArrayOutputStream output = new java.io.ByteArrayOutputStream(
                        declaredLength > 0 ? Math.min(declaredLength, maxBytes) : 32768);
                int total = 0;
                int read;
                while ((read = input.read(buffer)) != -1) {
                    total += read;
                    if (total > maxBytes) throw new IllegalStateException("Playlist remota demasiado grande");
                    output.write(buffer, 0, read);
                }
                String text = output.toString(StandardCharsets.UTF_8.name()).trim();
                if (!text.startsWith("#EXTM3U") && !text.contains("\n#EXTINF:")) {
                    throw new IllegalArgumentException("La URL no devolvió una playlist M3U/M3U8 válida");
                }
                return text;
            }
        } finally {
            connection.disconnect();
        }
    }

    private static List<Channel> parseCategoryBlocks(JSONArray groups) throws Exception {
        List<Channel> result = new ArrayList<>();
        int nextNumber = 1;

        for (int g = 0; g < groups.length(); g++) {
            JSONObject group = groups.optJSONObject(g);
            if (group == null) continue;

            String category = firstNonEmpty(
                    group.optString("name", ""),
                    group.optString("nombre", ""),
                    group.optString("category", ""),
                    group.optString("categoria", ""),
                    "General");

            JSONArray samples = group.optJSONArray("samples");
            if (samples == null) samples = group.optJSONArray("items");
            if (samples == null) samples = group.optJSONArray("channels");
            if (samples == null) continue;

            List<Channel> parsed = parseFlatArray(samples, category, nextNumber);
            result.addAll(parsed);
            nextNumber += parsed.size();
        }
        return result;
    }

    private static List<Channel> parseFlatArray(
            JSONArray array,
            String inheritedCategory,
            int startingNumber) throws Exception {
        List<Channel> items = new ArrayList<>();

        for (int i = 0; i < array.length(); i++) {
            JSONObject rawItem = array.optJSONObject(i);
            if (rawItem == null) continue;
            collectItem(
                    rawItem,
                    inheritedCategory,
                    "",
                    "",
                    startingNumber,
                    items);
        }
        return items;
    }

    /**
     * Convierte un elemento de BLAF/CO-CHI a uno o más Channel.
     * Soporta:
     * - item directo con uri/url/stream
     * - item cifrado como {"code":"..."}
     * - series con temp/episodes/capitulos anidados
     * - hijos anidados que también estén cifrados
     */
    private static void collectItem(
            JSONObject rawItem,
            String inheritedCategory,
            String parentName,
            String inheritedLogo,
            int startingNumber,
            List<Channel> out) {
        JSONObject item = decodeBlafObject(rawItem);
        if (item == null) return;

        int nextNumber = startingNumber + out.size();
        String itemName = firstNonEmpty(
                item.optString("name", ""),
                item.optString("nombre", ""),
                item.optString("title", ""));
        String ownLogo = firstNonEmpty(
                item.optString("icon", ""),
                item.optString("logo", ""),
                item.optString("icono", ""),
                item.optString("ícono", ""),
                item.optString("poster", ""),
                item.optString("image", ""),
                item.optString("imagen", ""),
                inheritedLogo);

        String category = firstNonEmpty(
                item.optString("category", ""),
                item.optString("categoria", ""),
                inheritedCategory,
                "General");

        String url = firstNonEmpty(
                item.optString("url", ""),
                item.optString("uri", ""),
                item.optString("stream", ""));
        ParsedStreamSpec streamSpec = parseInlineStreamSpec(url);
        url = streamSpec.url;

        // Entrada especial y optativa: una categoría puede apuntar a una playlist M3U/M3U8 remota.
        // Los canales históricos siguen exactamente por el camino de siempre; sólo se activa
        // cuando type/tipo es remote_playlist (o remote-playlist).
        String requestedType = firstNonEmpty(
                item.optString("type", ""),
                item.optString("tipo", ""));
        if (isRemotePlaylistType(requestedType) && !url.isEmpty()) {
            try {
                String playlistText = downloadRemotePlaylist(url);
                List<Channel> remoteChannels = parseM3uPlaylist(playlistText);
                if (!remoteChannels.isEmpty()) {
                    String remoteCategory = firstNonEmpty(
                            item.optString("category", ""),
                            item.optString("categoria", ""),
                            itemName,
                            inheritedCategory,
                            "Pluto TV");
                    int baseNumber = item.optInt("number", item.optInt("numero", nextNumber));
                    for (int r = 0; r < remoteChannels.size(); r++) {
                        Channel child = remoteChannels.get(r);
                        int number = baseNumber + r;
                        String id = firstNonEmpty(child.id, slug(remoteCategory) + "-" + number);
                        out.add(new Channel(
                                id,
                                number,
                                child.name,
                                child.type,
                                child.url,
                                child.adult || isAdultCategory(remoteCategory),
                                child.clearKeyPairs,
                                child.headers,
                                remoteCategory,
                                child.logo,
                                child.description,
                                child.sources));
                    }
                }
            } catch (Exception ignored) {
                // Una playlist remota caída no rompe TV1/TV2 ni impide cargar el resto del JSON.
            }
            return;
        }

        // Normalización nueva: además del formato histórico de una sola URL,
        // una entrada puede declarar sources[]/fuentes[]. La primera fuente queda
        // activa para no modificar el reproductor existente.
        String baseDrmScheme = item.optString("drm_scheme", "").trim();
        String baseExplicitType = firstNonEmpty(
                item.optString("type", ""),
                item.optString("tipo", ""));
        String baseType = inferType(baseExplicitType, url, baseDrmScheme);
        String baseKeyPairs = mergeKeyPairs(
                parseKeyPairsFromItem(item, baseDrmScheme),
                streamSpec.keyPairs);
        Map<String, String> baseHeaders = parseHeaders(item);
        List<StreamSource> normalizedSources = buildNormalizedSources(
                item, null, url, baseType, baseDrmScheme, baseKeyPairs, baseHeaders);
        StreamSource primarySource = firstPlayableSource(normalizedSources);
        if (primarySource != null) {
            url = primarySource.url;
        }

        // Si hay una URI reproducible (directa o dentro de sources[]), este objeto ya es una entrada final.
        if (!url.isEmpty()) {
            String displayName = itemName;
            if (displayName.isEmpty()) displayName = "Contenido " + nextNumber;
            if (!parentName.isEmpty() && !displayName.equalsIgnoreCase(parentName)) {
                displayName = parentName + " · " + displayName;
            }

            String description = firstNonEmpty(
                    item.optString("description", ""),
                    item.optString("descripcion", ""));

            String type = primarySource == null ? baseType : primarySource.type;
            String keyPairs = primarySource == null ? baseKeyPairs : primarySource.drm.clearKeyPairs;
            Map<String, String> headers = primarySource == null ? baseHeaders : primarySource.headers;
            HeaderResolver.learnFrom(url, headers);

            boolean adult = item.optBoolean("adult", item.optBoolean("adulto", false))
                    || isAdultCategory(category);

            int number = item.optInt("number",
                    item.optInt("numero", nextNumber));
            String id = firstNonEmpty(
                    item.optString("id", ""),
                    slug(category) + "-" + number);

            TemplateMeta meta = TemplateMeta.from(item, null);
            out.add(new Channel(
                    id,
                    number,
                    displayName,
                    type,
                    url,
                    adult,
                    keyPairs,
                    headers,
                    category,
                    ownLogo,
                    description,
                    normalizedSources,
                    meta.isTemplate,
                    meta.nameRedirect,
                    meta.codeRedirect,
                    meta.template));
            return;
        }

        // Series de BLAF: una serie suele contener los capítulos en "temp".
        JSONArray nested = firstArray(
                item,
                "temp",
                "episodes",
                "episodios",
                "capitulos",
                "capítulos",
                "samples",
                "items");
        if (nested == null) return;

        String nestedParent = parentName;
        if (!itemName.isEmpty()) {
            nestedParent = parentName.isEmpty() ? itemName : parentName + " · " + itemName;
        }

        for (int i = 0; i < nested.length(); i++) {
            JSONObject child = nested.optJSONObject(i);
            if (child == null) continue;
            collectItem(
                    child,
                    category,
                    nestedParent,
                    ownLogo,
                    startingNumber,
                    out);
        }
    }


    /**
     * El parser base conserva compatibilidad con los JSON BLAF y obtiene capítulos
     * reproducibles. Para SERIES los reagrupamos por el primer nombre padre:
     * "NOMBRE SERIE · CAPÍTULO" -> una tarjeta "NOMBRE SERIE" con sus capítulos.
     */
    private static List<Channel> groupSeries(List<Channel> flatEpisodes) {
        Map<String, List<Channel>> groupedEpisodes = new LinkedHashMap<>();
        Map<String, Channel> firstByGroup = new LinkedHashMap<>();
        Map<String, String> seriesNameByGroup = new LinkedHashMap<>();

        for (Channel episode : flatEpisodes) {
            String fullName = episode.name == null ? "" : episode.name.trim();
            String seriesName = fullName;
            String episodeName = fullName;

            int separator = fullName.indexOf(" · ");
            if (separator > 0) {
                seriesName = fullName.substring(0, separator).trim();
                episodeName = fullName.substring(separator + 3).trim();
            }
            if (seriesName.isEmpty()) seriesName = "Serie";

            String category = firstNonEmpty(episode.category, "General");
            String groupKey = category.toLowerCase(Locale.ROOT) + "\n" + seriesName.toLowerCase(Locale.ROOT);

            List<Channel> episodes = groupedEpisodes.computeIfAbsent(groupKey, k -> new ArrayList<>());
            int episodeNumber = episodes.size() + 1;
            if (episodeName.isEmpty() || episodeName.equalsIgnoreCase(seriesName)) {
                episodeName = "Capítulo " + episodeNumber;
            }
            Channel cleanEpisode = new Channel(
                    episode.id,
                    episodeNumber,
                    episodeName,
                    episode.type,
                    episode.url,
                    episode.adult,
                    episode.clearKeyPairs,
                    episode.headers,
                    category,
                    episode.logo,
                    episode.description,
                    episode.sources,
                    episode.isTemplate,
                    episode.nameRedirect,
                    episode.codeRedirect,
                    episode.template);
            episodes.add(cleanEpisode);
            firstByGroup.putIfAbsent(groupKey, episode);
            seriesNameByGroup.putIfAbsent(groupKey, seriesName);
        }

        Map<String, List<Channel>> bySeriesId = new LinkedHashMap<>();
        List<Channel> parents = new ArrayList<>();
        int number = 1;

        for (Map.Entry<String, List<Channel>> entry : groupedEpisodes.entrySet()) {
            String groupKey = entry.getKey();
            List<Channel> episodes = entry.getValue();
            if (episodes.isEmpty()) continue;

            Channel first = firstByGroup.get(groupKey);
            String seriesName = seriesNameByGroup.get(groupKey);
            String seriesId = "series-" + Integer.toUnsignedString(groupKey.hashCode());
            boolean adult = false;
            for (Channel episode : episodes) adult = adult || episode.adult;

            String countText = episodes.size() == 1
                    ? "1 capítulo"
                    : episodes.size() + " capítulos";

            Channel parent = new Channel(
                    seriesId,
                    number++,
                    seriesName,
                    "series",
                    "",
                    adult,
                    "",
                    new LinkedHashMap<>(),
                    first == null ? "General" : first.category,
                    first == null ? "" : first.logo,
                    countText,
                    null,
                    first != null && first.isTemplate,
                    first == null ? "" : first.nameRedirect,
                    first == null ? "" : first.codeRedirect,
                    first == null ? "" : first.template);

            parents.add(parent);
            bySeriesId.put(seriesId, episodes);
        }

        Map<String, String> legacyCategories = new LinkedHashMap<>();
        List<SeriesStore.SeriesInfo> legacySeries = new ArrayList<>();
        for (Channel parent : parents) {
            String categoryName = firstNonEmpty(parent.category, "General");
            String categoryId = SeriesStore.slug(categoryName);
            legacyCategories.putIfAbsent(categoryId, categoryName);
            List<Channel> episodes = bySeriesId.get(parent.id);
            if (episodes == null) episodes = new ArrayList<>();
            Map<Integer, List<Channel>> inferred = new LinkedHashMap<>();
            for (Channel episode : episodes) {
                int seasonNumber = inferSeasonNumber(episode.name, 1);
                inferred.computeIfAbsent(seasonNumber, ignored -> new ArrayList<>()).add(episode);
            }
            List<SeriesStore.Season> seasons = new ArrayList<>();
            for (Map.Entry<Integer, List<Channel>> season : inferred.entrySet()) {
                seasons.add(new SeriesStore.Season(
                        season.getKey(), "Temporada " + season.getKey(), season.getValue()));
            }
            legacySeries.add(new SeriesStore.SeriesInfo(
                    parent.id, parent.name, parent.logo, "", "", "", "", parent.adult,
                    java.util.Collections.singletonList(categoryId), seasons));
        }
        SeriesStore.replaceCatalog(legacySeries, legacyCategories);
        return parents;
    }

    private static JSONArray firstArray(JSONObject object, String... names) {
        for (String name : names) {
            JSONArray value = object.optJSONArray(name);
            if (value != null) return value;
        }
        return null;
    }

    private static JSONObject decodeBlafObject(JSONObject raw) {
        if (raw == null) return null;
        String code = raw.optString("code", "").trim();
        if (code.isEmpty()) return raw;

        try {
            byte[] encrypted = Base64.decode(code, Base64.DEFAULT);
            if (encrypted.length == 0 || encrypted.length % 16 != 0) return raw;

            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
            SecretKeySpec key = new SecretKeySpec(
                    BLAF_JSON_AES_KEY.getBytes(StandardCharsets.UTF_8),
                    "AES");
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] plainBytes = cipher.doFinal(encrypted);
            String plain = new String(plainBytes, StandardCharsets.UTF_8).trim();
            Object decoded = new JSONTokener(plain).nextValue();
            return decoded instanceof JSONObject ? (JSONObject) decoded : raw;
        } catch (Exception ignored) {
            // Si un campo "code" no pertenece al cifrado de BLAF, no rompe el catálogo.
            return raw;
        }
    }

    private static List<StreamSource> buildNormalizedSources(
            JSONObject primary,
            JSONObject fallback,
            String legacyUrl,
            String legacyType,
            String legacyDrmScheme,
            String legacyKeyPairs,
            Map<String, String> legacyHeaders) {
        List<StreamSource> out = new ArrayList<>();

        // Compatibilidad estricta: si el objeto histórico trae url, sigue siendo la
        // fuente número 1. sources[] se agrega detrás y no cambia qué se reproduce hoy.
        if (legacyUrl != null && !legacyUrl.trim().isEmpty()) {
            JSONObject nestedDrm = firstDrmObject(primary, fallback);
            String scheme = firstNonEmpty(
                    legacyDrmScheme,
                    nestedDrm == null ? "" : nestedDrm.optString("scheme", ""),
                    nestedDrm == null ? "" : nestedDrm.optString("type", ""));
            String licenseUrl = nestedDrm == null ? "" : firstNonEmpty(
                    nestedDrm.optString("licenseUrl", ""),
                    nestedDrm.optString("license_url", ""),
                    nestedDrm.optString("url", ""));
            String pairs = legacyKeyPairs == null ? "" : legacyKeyPairs.trim();
            if (nestedDrm != null) {
                pairs = mergeKeyPairs(pairs, parseKeyPairsFromItem(nestedDrm, scheme));
                pairs = mergeKeyPairs(pairs, parsePackedClearKeyLicense(licenseUrl, scheme));
            }
            Map<String, String> drmHeaders = nestedDrm == null
                    ? new LinkedHashMap<>()
                    : parseHeaders(nestedDrm);
            DrmConfig drm = new DrmConfig(scheme, licenseUrl, pairs, drmHeaders);
            addSourceIfUnique(out, new StreamSource(
                    legacyUrl,
                    inferType(legacyType == null ? "" : legacyType, legacyUrl, scheme),
                    legacyHeaders,
                    "",
                    0L,
                    0,
                    drm));
        }

        appendDeclaredSources(out, primary, legacyHeaders);
        appendDeclaredSources(out, fallback, legacyHeaders);
        return out;
    }

    private static void appendDeclaredSources(
            List<StreamSource> out,
            JSONObject container,
            Map<String, String> inheritedHeaders) {
        if (container == null) return;

        JSONArray array = container.optJSONArray("sources");
        if (array == null) array = container.optJSONArray("fuentes");
        if (array != null) {
            for (int i = 0; i < array.length(); i++) {
                JSONObject rawSource = array.optJSONObject(i);
                StreamSource source = parseStreamSource(rawSource, inheritedHeaders, i + 1);
                addSourceIfUnique(out, source);
            }
        }

        JSONObject single = container.optJSONObject("source");
        if (single == null) single = container.optJSONObject("fuente");
        StreamSource one = parseStreamSource(single, inheritedHeaders, out.size() + 1);
        addSourceIfUnique(out, one);
    }

    private static StreamSource parseStreamSource(
            JSONObject rawSource,
            Map<String, String> inheritedHeaders,
            int defaultPriority) {
        if (rawSource == null) return null;
        JSONObject source = decodeBlafObject(rawSource);
        if (source == null) source = rawSource;

        String url = firstNonEmpty(
                source.optString("url", ""),
                source.optString("uri", ""),
                source.optString("stream", ""));
        if (url.isEmpty()) return null;

        ParsedStreamSpec inline = parseInlineStreamSpec(url);
        url = inline.url;

        JSONObject drmObject = source.optJSONObject("drm");
        String scheme = firstNonEmpty(
                source.optString("drm_scheme", ""),
                drmObject == null ? "" : drmObject.optString("scheme", ""),
                drmObject == null ? "" : drmObject.optString("type", ""));
        String licenseUrl = firstNonEmpty(
                source.optString("drm_license_url", ""),
                drmObject == null ? "" : drmObject.optString("licenseUrl", ""),
                drmObject == null ? "" : drmObject.optString("license_url", ""),
                drmObject == null ? "" : drmObject.optString("url", ""));

        String pairs = mergeKeyPairs(parseKeyPairsFromItem(source, scheme), inline.keyPairs);
        if (drmObject != null) {
            pairs = mergeKeyPairs(pairs, parseKeyPairsFromItem(drmObject, scheme));
            pairs = mergeKeyPairs(pairs, parsePackedClearKeyLicense(licenseUrl, scheme));
        }

        Map<String, String> headers = mergeHeaderMaps(inheritedHeaders, parseHeaders(source));
        Map<String, String> drmHeaders = drmObject == null
                ? new LinkedHashMap<>()
                : parseHeaders(drmObject);
        String explicitType = firstNonEmpty(
                source.optString("type", ""),
                source.optString("tipo", ""));
        String type = inferType(explicitType, url, scheme);
        String quality = firstNonEmpty(
                source.optString("qualityLabel", ""),
                source.optString("quality", ""),
                source.optString("calidad", ""),
                source.optString("label", ""));
        long bitrate = Math.max(0L, source.optLong("bitrate", source.optLong("bandwidth", 0L)));
        int priority = source.optInt("priority", source.optInt("prioridad", defaultPriority));

        String serverLabel = firstNonEmpty(
                source.optString("server", ""),
                source.optString("provider", ""),
                source.optString("servidor", ""),
                source.optString("source_name", ""));
        String languageLabel = firstNonEmpty(
                source.optString("language", ""),
                source.optString("idioma", ""),
                source.optString("audio", ""));
        String subtitlesLabel = firstNonEmpty(
                source.optString("subtitles", ""),
                source.optString("subtitulos", ""),
                source.optString("subs", ""));

        HeaderResolver.learnFrom(url, headers);
        return new StreamSource(
                url, type, headers, quality, serverLabel, languageLabel, subtitlesLabel,
                bitrate, priority, new DrmConfig(scheme, licenseUrl, pairs, drmHeaders));
    }

    private static JSONObject firstDrmObject(JSONObject primary, JSONObject fallback) {
        JSONObject drm = primary == null ? null : primary.optJSONObject("drm");
        if (drm == null && fallback != null) drm = fallback.optJSONObject("drm");
        return drm;
    }

    private static Map<String, String> mergeHeaderMaps(
            Map<String, String> inherited,
            Map<String, String> explicit) {
        LinkedHashMap<String, String> merged = new LinkedHashMap<>();
        if (inherited != null) merged.putAll(inherited);
        if (explicit != null) merged.putAll(explicit);
        return merged;
    }

    private static void addSourceIfUnique(List<StreamSource> out, StreamSource candidate) {
        if (candidate == null || !candidate.isPlayable()) return;
        for (StreamSource current : out) {
            if (current.url.equals(candidate.url)
                    && current.type.equalsIgnoreCase(candidate.type)
                    && current.drm.clearKeyPairs.equals(candidate.drm.clearKeyPairs)) {
                return;
            }
        }
        out.add(candidate);
    }

    private static StreamSource firstPlayableSource(List<StreamSource> sources) {
        if (sources == null) return null;
        for (StreamSource source : sources) {
            if (source != null && source.isPlayable()) return source;
        }
        return null;
    }

    private static String parsePackedClearKeyLicense(String packed, String scheme) {
        if (!"clearkey".equalsIgnoreCase(scheme) || packed == null || !packed.contains(":")) {
            return "";
        }
        StringBuilder pairs = new StringBuilder();
        String[] entries = packed.split("[,;\\r\\n]+");
        for (String entry : entries) appendPackedKeyPair(pairs, entry);
        return pairs.toString();
    }

    private static String inferType(String explicitType, String url, String drmScheme) {
        String declared = explicitType == null ? "" : explicitType.trim();
        if (!declared.isEmpty() && !"auto".equalsIgnoreCase(declared)) {
            String normalized = declared.toLowerCase(Locale.ROOT);
            if (normalized.equals("hls")
                    || normalized.equals("m3u8")
                    || normalized.contains("mpegurl")) return "hls";
            if (normalized.equals("dash")
                    || normalized.equals("mpd")
                    || normalized.contains("dash+xml")) return "dash";
            if (normalized.equals("youtube")
                    || normalized.equals("yt")) return "youtube";
            if (normalized.equals("progressive")
                    || normalized.equals("file")
                    || normalized.equals("mp4")) return "progressive";
            return declared;
        }
        String lower = url == null ? "" : url.toLowerCase(Locale.ROOT);
        if (lower.contains("youtube.com") || lower.contains("youtu.be")) return "youtube";
        if (lower.contains(".m3u8")) return "hls";
        if (lower.contains(".mpd")) return "dash";
        if (drmScheme != null && !drmScheme.trim().isEmpty()) return "dash";
        return "auto";
    }

    private static Map<String, String> parseHeaders(JSONObject item) {
        Map<String, String> headers = new LinkedHashMap<>();

        JSONObject headersJson = item.optJSONObject("headers");
        if (headersJson != null) mergeHeaderObject(headersJson, headers);

        JSONArray drmHeaders = item.optJSONArray("drm_header");
        if (drmHeaders != null) {
            for (int i = 0; i < drmHeaders.length(); i++) {
                JSONObject headerObject = drmHeaders.optJSONObject(i);
                if (headerObject != null) mergeHeaderObject(headerObject, headers);
            }
        }
        return headers;
    }

    private static void mergeHeaderObject(JSONObject source, Map<String, String> destination) {
        JSONArray names = source.names();
        if (names == null) return;
        for (int i = 0; i < names.length(); i++) {
            String name = names.optString(i, "");
            if (name.isEmpty()) continue;
            String value = source.optString(name, "");
            if (!value.trim().isEmpty()) destination.put(name, value.trim());
        }
    }

    private static String parseKeyPairsFromItem(JSONObject item, String drmScheme) {
        StringBuilder pairs = new StringBuilder();

        JSONArray keys = item.optJSONArray("keys");
        if (keys != null) {
            for (int k = 0; k < keys.length(); k++) {
                JSONObject key = keys.optJSONObject(k);
                if (key == null) continue;
                appendNormalizedPair(pairs,
                        key.optString("kid", ""),
                        key.optString("key", ""));
            }
        }

        // Algunos catálogos autorizados usan drm_license_url como contenedor de pares KID:KEY.
        // CO-CHI solo interpreta ese campo localmente cuando el esquema declarado es ClearKey.
        if ("clearkey".equalsIgnoreCase(drmScheme)) {
            String packed = item.optString("drm_license_url", "").trim();
            if (!packed.isEmpty() && packed.contains(":")) {
                String[] entries = packed.split("[,;\\r\\n]+");
                for (String entry : entries) {
                    appendPackedKeyPair(pairs, entry);
                }
            }
        }
        return pairs.toString();
    }

    /**
     * Acepta ClearKey en las dos formas usadas por los catálogos CO-CHI:
     *   KID_HEX:KEY_HEX
     *   KID_BASE64:KEY_BASE64
     * y también la convención Max usada por TV1:
     *   Max:KEY_HEX:KID_HEX
     *
     * Internamente siempre normalizamos los 16 bytes de KID/KEY a hex de 32 caracteres.
     */
    private static void appendPackedKeyPair(StringBuilder out, String rawEntry) {
        if (rawEntry == null) return;
        String entry = rawEntry.trim();
        if (entry.isEmpty()) return;

        String[] parts = entry.split("\\s*:\\s*");
        if (parts.length < 2) return;

        // Convención observada en las listas CO-CHI:
        //   Base64/Base64 (sin prefijo) => KID:KEY
        //   Max:HEX:HEX              => KEY:KID
        // Por eso el formato Max necesita invertir los dos valores antes de
        // normalizarlos al formato interno canónico KID:KEY.
        boolean maxFormat = parts.length >= 3
                && "max".equalsIgnoreCase(parts[0].trim());
        String firstRaw = parts[parts.length - 2];
        String secondRaw = parts[parts.length - 1];
        if (maxFormat) {
            appendNormalizedPair(out, secondRaw, firstRaw);
        } else {
            appendNormalizedPair(out, firstRaw, secondRaw);
        }
    }

    private static void appendNormalizedPair(StringBuilder out, String kidRaw, String keyRaw) {
        String kid = normalize128(kidRaw);
        String key = normalize128(keyRaw);
        if (kid.isEmpty() || key.isEmpty()) return;
        if (out.length() > 0) out.append('\n');
        out.append(kid).append(':').append(key);
    }

    private static String normalize128(String raw) {
        if (raw == null) return "";
        String trimmed = raw.trim();
        String hex = trimmed.replace("-", "").replace(" ", "");
        if (hex.matches("(?i)[0-9a-f]{32}")) return hex.toLowerCase(Locale.ROOT);

        try {
            String padded = trimmed;
            int remainder = padded.length() % 4;
            if (remainder != 0) padded += "====".substring(remainder);
            byte[] decoded;
            try {
                decoded = Base64.decode(padded, Base64.NO_WRAP);
            } catch (IllegalArgumentException standardError) {
                decoded = Base64.decode(padded, Base64.URL_SAFE | Base64.NO_WRAP);
            }
            if (decoded.length != 16) return "";
            StringBuilder out = new StringBuilder(32);
            for (byte b : decoded) out.append(String.format(Locale.US, "%02x", b & 0xff));
            return out.toString();
        } catch (Exception ignored) {
            return "";
        }
    }

    private static boolean isAdultCategory(String category) {
        String normalized = category == null ? "" : category.toLowerCase(Locale.ROOT);
        return normalized.contains("xxx")
                || normalized.contains("adult")
                || normalized.contains("18+")
                || normalized.contains("🔞");
    }

    private static String slug(String value) {
        String normalized = value == null ? "item" : value.toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9]+", "-")
                .replaceAll("(^-+|-+$)", "");
        return normalized.isEmpty() ? "item" : normalized;
    }
}
