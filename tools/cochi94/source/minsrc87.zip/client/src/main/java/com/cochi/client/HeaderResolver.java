package com.cochi.client;

import java.net.URI;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Resuelve headers de reproducción sin repetirlos canal por canal.
 *
 * Prioridad:
 * 1) Headers explícitos del item JSON.
 * 2) Perfil aprendido automáticamente para el host de la URI.
 * 3) Headers estándar seguros de CO-CHI.
 *
 * CO-CHI aprende por frecuencia: si un host usa mayoritariamente el mismo
 * Origin/Referer/User-Agent, ese valor se convierte en perfil automático.
 * Un valor minoritario no rompe el perfil porque el canal que lo necesite puede
 * seguir trayéndolo explícito y siempre tendrá prioridad.
 *
 * Headers sensibles o variables (Authorization, Cookie, Range, Host, etc.)
 * nunca se aprenden de forma automática.
 */
public final class HeaderResolver {

    private static final String DEFAULT_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 13; CO-CHI) "
                    + "AppleWebKit/537.36 (KHTML, like Gecko) "
                    + "Chrome/140.0 Mobile Safari/537.36 CO-CHI/0.22.14";

    // Cuando hay varios valores para un mismo host, solo heredamos el dominante
    // si representa al menos el 75% de los ejemplos explícitos observados.
    private static final double DOMINANT_PROFILE_THRESHOLD = 0.75d;

    private static final Set<String> LEARNABLE = Collections.unmodifiableSet(
            new HashSet<>(Arrays.asList(
                    "origin",
                    "referer",
                    "user-agent",
                    "accept",
                    "accept-language"
            )));

    private static final Map<String, HostProfile> HOST_PROFILES = new ConcurrentHashMap<>();

    private HeaderResolver() {}

    /** Registra un ejemplo explícito del catálogo para aprender el perfil del host. */
    public static void learnFrom(String url, Map<String, String> explicitHeaders) {
        if (explicitHeaders == null || explicitHeaders.isEmpty()) return;
        String host = hostOf(url);
        if (host.isEmpty()) return;

        HostProfile profile = HOST_PROFILES.get(host);
        if (profile == null) {
            HostProfile created = new HostProfile();
            HostProfile existing = HOST_PROFILES.putIfAbsent(host, created);
            profile = existing == null ? created : existing;
        }

        synchronized (profile) {
            for (Map.Entry<String, String> entry : explicitHeaders.entrySet()) {
                String rawName = safe(entry.getKey());
                String rawValue = safe(entry.getValue());
                if (rawName.isEmpty() || rawValue.isEmpty()) continue;

                String normalizedName = rawName.toLowerCase(Locale.ROOT);
                if (!LEARNABLE.contains(normalizedName)) continue;

                HeaderStats stats = profile.stats.get(normalizedName);
                if (stats == null) {
                    stats = new HeaderStats(canonicalName(normalizedName));
                    profile.stats.put(normalizedName, stats);
                }
                stats.add(rawValue);
            }
        }
    }

    /**
     * Devuelve los headers finales para una URI. Los explícitos siempre ganan.
     */
    public static Map<String, String> resolve(String url, Map<String, String> explicitHeaders) {
        LinkedHashMap<String, String> resolved = new LinkedHashMap<>();
        putIgnoreCase(resolved, "Accept", "*/*");
        putIgnoreCase(resolved, "Accept-Language", "es-AR,es;q=0.9,en;q=0.7");
        putIgnoreCase(resolved, "User-Agent", DEFAULT_USER_AGENT);

        String host = hostOf(url);
        HostProfile profile = host.isEmpty() ? null : HOST_PROFILES.get(host);
        if (profile != null) {
            synchronized (profile) {
                for (HeaderStats stats : profile.stats.values()) {
                    String dominant = stats.dominantValue();
                    if (dominant != null) {
                        putIgnoreCase(resolved, stats.canonicalName, dominant);
                    }
                }
            }
        }

        if (explicitHeaders != null) {
            for (Map.Entry<String, String> entry : explicitHeaders.entrySet()) {
                String name = safe(entry.getKey());
                String value = safe(entry.getValue());
                if (!name.isEmpty() && !value.isEmpty()) {
                    putIgnoreCase(resolved, name, value);
                }
            }
        }

        return Collections.unmodifiableMap(resolved);
    }

    /** Visible para diagnóstico/desarrollo. */
    public static Map<String, String> learnedProfileFor(String url) {
        String host = hostOf(url);
        HostProfile profile = host.isEmpty() ? null : HOST_PROFILES.get(host);
        if (profile == null) return Collections.emptyMap();

        LinkedHashMap<String, String> copy = new LinkedHashMap<>();
        synchronized (profile) {
            for (HeaderStats stats : profile.stats.values()) {
                String dominant = stats.dominantValue();
                if (dominant != null) copy.put(stats.canonicalName, dominant);
            }
        }
        return Collections.unmodifiableMap(copy);
    }

    private static void putIgnoreCase(Map<String, String> map, String name, String value) {
        String existingKey = null;
        for (String key : map.keySet()) {
            if (key.equalsIgnoreCase(name)) {
                existingKey = key;
                break;
            }
        }
        if (existingKey != null) map.remove(existingKey);
        map.put(name, value);
    }

    private static String hostOf(String url) {
        try {
            URI uri = URI.create(safe(url));
            String host = uri.getHost();
            return host == null ? "" : host.toLowerCase(Locale.ROOT);
        } catch (Exception ignored) {
            return "";
        }
    }

    private static String canonicalName(String normalizedName) {
        switch (normalizedName) {
            case "origin": return "Origin";
            case "referer": return "Referer";
            case "user-agent": return "User-Agent";
            case "accept": return "Accept";
            case "accept-language": return "Accept-Language";
            default: return normalizedName;
        }
    }

    private static String safe(String value) {
        return value == null ? "" : value.trim();
    }

    private static final class HostProfile {
        final Map<String, HeaderStats> stats = new LinkedHashMap<>();
    }

    private static final class HeaderStats {
        final String canonicalName;
        final Map<String, Integer> counts = new LinkedHashMap<>();
        int total;

        HeaderStats(String canonicalName) {
            this.canonicalName = canonicalName;
        }

        void add(String value) {
            Integer previous = counts.get(value);
            counts.put(value, previous == null ? 1 : previous + 1);
            total++;
        }

        String dominantValue() {
            if (counts.isEmpty() || total <= 0) return null;
            String bestValue = null;
            int bestCount = -1;
            for (Map.Entry<String, Integer> entry : counts.entrySet()) {
                if (entry.getValue() > bestCount) {
                    bestValue = entry.getKey();
                    bestCount = entry.getValue();
                }
            }
            if (counts.size() == 1) return bestValue;
            double share = (double) bestCount / (double) total;
            return share >= DOMINANT_PROFILE_THRESHOLD ? bestValue : null;
        }
    }
}
