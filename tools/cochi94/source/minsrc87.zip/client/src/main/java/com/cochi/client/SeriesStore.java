package com.cochi.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Catálogo de Series en memoria.
 *
 * v0.22 agrega la jerarquía real Categoría -> Serie -> Temporada -> Episodio.
 * El store también mantiene compatibilidad con el formato anterior para que
 * CO-CHI pueda migrar de a poco sin romper TIROLIBRE.json.
 */
public final class SeriesStore {

    public static final class MarkerRange {
        public final long startMs;
        public final long endMs;

        public MarkerRange(long startMs, long endMs) {
            this.startMs = Math.max(0L, startMs);
            this.endMs = Math.max(this.startMs, endMs);
        }

        public boolean isValid() { return endMs > startMs; }
    }

    public static final class EpisodeMarkers {
        public final MarkerRange recap;
        public final MarkerRange intro;
        public final long nextEpisodeAtMs;

        public EpisodeMarkers(MarkerRange recap, MarkerRange intro, long nextEpisodeAtMs) {
            this.recap = recap;
            this.intro = intro;
            this.nextEpisodeAtMs = nextEpisodeAtMs;
        }

        public boolean isEmpty() {
            return (recap == null || !recap.isValid())
                    && (intro == null || !intro.isValid())
                    && nextEpisodeAtMs < 0L;
        }
    }

    public static final class SeasonMarkers {
        public final EpisodeMarkers defaults;
        public final Map<Integer, EpisodeMarkers> episodeOverrides;

        public SeasonMarkers(EpisodeMarkers defaults, Map<Integer, EpisodeMarkers> episodeOverrides) {
            this.defaults = defaults == null ? new EpisodeMarkers(null, null, -1L) : defaults;
            this.episodeOverrides = Collections.unmodifiableMap(new LinkedHashMap<>(
                    episodeOverrides == null ? Collections.emptyMap() : episodeOverrides));
        }

        public EpisodeMarkers forEpisode(int episodeNumber) {
            EpisodeMarkers override = episodeOverrides.get(episodeNumber);
            if (override == null) return defaults;
            MarkerRange recap = override.recap != null ? override.recap : defaults.recap;
            MarkerRange intro = override.intro != null ? override.intro : defaults.intro;
            long next = override.nextEpisodeAtMs >= 0L ? override.nextEpisodeAtMs : defaults.nextEpisodeAtMs;
            return new EpisodeMarkers(recap, intro, next);
        }
    }

    public static final class PlaybackMarkers {
        public final Map<Integer, SeasonMarkers> seasons;

        public PlaybackMarkers(Map<Integer, SeasonMarkers> seasons) {
            this.seasons = Collections.unmodifiableMap(new LinkedHashMap<>(
                    seasons == null ? Collections.emptyMap() : seasons));
        }

        public static PlaybackMarkers empty() { return new PlaybackMarkers(Collections.emptyMap()); }

        public EpisodeMarkers resolve(int seasonNumber, int episodeNumber) {
            SeasonMarkers season = seasons.get(seasonNumber);
            return season == null ? new EpisodeMarkers(null, null, -1L) : season.forEpisode(episodeNumber);
        }
    }

    public static final class Season {
        public final int number;
        public final String name;
        public final List<Channel> episodes;

        public Season(int number, String name, List<Channel> episodes) {
            this.number = number;
            this.name = safe(name).isEmpty() ? "Temporada " + number : safe(name);
            this.episodes = Collections.unmodifiableList(new ArrayList<>(
                    episodes == null ? Collections.emptyList() : episodes));
        }
    }

    public static final class SeriesInfo {
        public final String id;
        public final String name;
        public final String poster;
        public final String backdrop;
        public final String year;
        public final String genre;
        public final String synopsis;
        public final boolean adult;
        public final List<String> categoryIds;
        public final List<Season> seasons;
        public final PlaybackMarkers playbackMarkers;

        public SeriesInfo(
                String id,
                String name,
                String poster,
                String backdrop,
                String year,
                String genre,
                String synopsis,
                boolean adult,
                List<String> categoryIds,
                List<Season> seasons) {
            this(id, name, poster, backdrop, year, genre, synopsis, adult, categoryIds, seasons, PlaybackMarkers.empty());
        }

        public SeriesInfo(
                String id,
                String name,
                String poster,
                String backdrop,
                String year,
                String genre,
                String synopsis,
                boolean adult,
                List<String> categoryIds,
                List<Season> seasons,
                PlaybackMarkers playbackMarkers) {
            this.id = safe(id);
            this.name = safe(name).isEmpty() ? "Serie" : safe(name);
            this.poster = safe(poster);
            this.backdrop = safe(backdrop);
            this.year = safe(year);
            this.genre = safe(genre);
            this.synopsis = safe(synopsis);
            this.adult = adult;
            this.categoryIds = Collections.unmodifiableList(new ArrayList<>(
                    categoryIds == null ? Collections.emptyList() : categoryIds));
            this.seasons = Collections.unmodifiableList(new ArrayList<>(
                    seasons == null ? Collections.emptyList() : seasons));
            this.playbackMarkers = playbackMarkers == null ? PlaybackMarkers.empty() : playbackMarkers;
        }

        public List<Channel> allEpisodes() {
            List<Channel> out = new ArrayList<>();
            for (Season season : seasons) out.addAll(season.episodes);
            return out;
        }

        public int episodeCount() {
            int total = 0;
            for (Season season : seasons) total += season.episodes.size();
            return total;
        }
    }

    private static Map<String, SeriesInfo> seriesById = Collections.emptyMap();
    private static Map<String, String> categoryNames = Collections.emptyMap();
    private static Map<String, Set<String>> categoriesBySeriesId = Collections.emptyMap();

    private SeriesStore() {}

    public static synchronized void replaceCatalog(
            List<SeriesInfo> series,
            Map<String, String> categories) {
        Map<String, SeriesInfo> byId = new LinkedHashMap<>();
        Map<String, Set<String>> membership = new LinkedHashMap<>();

        if (series != null) {
            for (SeriesInfo info : series) {
                if (info == null || info.id.isEmpty()) continue;
                byId.put(info.id, info);
                LinkedHashSet<String> ids = new LinkedHashSet<>();
                for (String categoryId : info.categoryIds) {
                    if (!safe(categoryId).isEmpty()) ids.add(safe(categoryId));
                }
                membership.put(info.id, Collections.unmodifiableSet(ids));
            }
        }

        Map<String, String> categoryCopy = new LinkedHashMap<>();
        if (categories != null) categoryCopy.putAll(categories);

        seriesById = Collections.unmodifiableMap(byId);
        categoryNames = Collections.unmodifiableMap(categoryCopy);
        categoriesBySeriesId = Collections.unmodifiableMap(membership);
    }

    /** Compatibilidad: reemplaza únicamente episodios de una serie legacy. */
    public static synchronized void replace(Map<String, List<Channel>> episodesBySeriesId) {
        List<SeriesInfo> series = new ArrayList<>();
        Map<String, String> categories = new LinkedHashMap<>();
        if (episodesBySeriesId != null) {
            for (Map.Entry<String, List<Channel>> entry : episodesBySeriesId.entrySet()) {
                List<Channel> episodes = entry.getValue() == null
                        ? Collections.emptyList() : entry.getValue();
                Channel first = episodes.isEmpty() ? null : episodes.get(0);
                String category = first == null ? "General" : safe(first.category);
                String categoryId = slug(category);
                categories.putIfAbsent(categoryId, category);
                String name = first == null ? "Serie" : deriveSeriesName(first.name);
                String poster = first == null ? "" : first.logo;
                series.add(new SeriesInfo(
                        entry.getKey(), name, poster, "", "", "", "", false,
                        Collections.singletonList(categoryId),
                        Collections.singletonList(new Season(1, "Temporada 1", episodes))));
            }
        }
        replaceCatalog(series, categories);
    }

    public static synchronized SeriesInfo getSeries(String seriesId) {
        return seriesById.get(seriesId);
    }

    public static synchronized List<Channel> getEpisodes(String seriesId) {
        SeriesInfo info = seriesById.get(seriesId);
        return info == null ? Collections.emptyList() : info.allEpisodes();
    }

    public static synchronized SeriesInfo findSeriesByEpisodeId(String episodeId) {
        if (episodeId == null) return null;
        for (SeriesInfo info : seriesById.values()) {
            for (Channel episode : info.allEpisodes()) {
                if (episodeId.equals(episode.id)) return info;
            }
        }
        return null;
    }

    public static synchronized EpisodeMarkers markersForEpisode(String episodeId) {
        if (episodeId == null) return new EpisodeMarkers(null, null, -1L);
        for (SeriesInfo info : seriesById.values()) {
            for (Season season : info.seasons) {
                for (Channel episode : season.episodes) {
                    if (episodeId.equals(episode.id)) {
                        return info.playbackMarkers.resolve(season.number, episode.number);
                    }
                }
            }
        }
        return new EpisodeMarkers(null, null, -1L);
    }


    public static synchronized List<String> getCategoryNames() {
        return new ArrayList<>(categoryNames.values());
    }

    public static synchronized boolean belongsToCategory(String seriesId, String displayCategory) {
        if (displayCategory == null || displayCategory.trim().isEmpty()
                || "Todos".equalsIgnoreCase(displayCategory.trim())) return true;

        Set<String> membership = categoriesBySeriesId.get(seriesId);
        if (membership == null || membership.isEmpty()) return false;

        for (String categoryId : membership) {
            String display = categoryNames.get(categoryId);
            if (displayCategory.equalsIgnoreCase(categoryId)
                    || (display != null && displayCategory.equalsIgnoreCase(display))) {
                return true;
            }
        }
        return false;
    }

    public static synchronized String firstCategoryName(String seriesId) {
        Set<String> membership = categoriesBySeriesId.get(seriesId);
        if (membership != null) {
            for (String categoryId : membership) {
                String display = categoryNames.get(categoryId);
                if (display != null && !display.trim().isEmpty()) return display;
            }
        }
        return "General";
    }

    public static synchronized boolean isEmpty() {
        return seriesById.isEmpty();
    }

    public static synchronized void clear() {
        seriesById = Collections.emptyMap();
        categoryNames = Collections.emptyMap();
        categoriesBySeriesId = Collections.emptyMap();
    }

    private static String deriveSeriesName(String full) {
        String value = safe(full);
        int separator = value.indexOf(" · ");
        return separator > 0 ? value.substring(0, separator).trim() : value;
    }

    public static String slug(String value) {
        String lower = safe(value).toLowerCase(java.util.Locale.ROOT)
                .replace('á', 'a').replace('é', 'e').replace('í', 'i')
                .replace('ó', 'o').replace('ú', 'u').replace('ñ', 'n');
        lower = lower.replaceAll("[^a-z0-9]+", "-");
        lower = lower.replaceAll("^-+|-+$", "");
        return lower.isEmpty() ? "general" : lower;
    }

    private static String safe(String value) {
        return value == null ? "" : value.trim();
    }
}
