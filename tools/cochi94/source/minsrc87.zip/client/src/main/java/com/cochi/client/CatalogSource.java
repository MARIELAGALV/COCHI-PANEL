package com.cochi.client;

public enum CatalogSource {
    TV1,
    TV2,
    MOVIES,
    SERIES
}
