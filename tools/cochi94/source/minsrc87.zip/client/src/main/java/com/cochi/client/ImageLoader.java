package com.cochi.client;

import android.content.Context;
import android.widget.ImageView;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import coil3.SingletonImageLoader;
import coil3.request.ImageRequest;
import coil3.target.ImageViewTarget;

/**
 * Cargador de imágenes de CO-CHI basado en Coil 3.
 *
 * En v0.13 las listas usan RecyclerView, por lo que solo se cargan los logos
 * visibles y los próximos elementos. Coil mantiene caché de memoria/disco y
 * prefetch() calienta una pequeña ventana sin descargar todo el catálogo.
 */
public final class ImageLoader {
    private static final int DEFAULT_PREFETCH_LIMIT = 18;

    private ImageLoader() {}

    public static void load(String url, ImageView target) {
        if (target == null) return;

        target.setImageResource(R.drawable.ic_cochi);
        if (url == null || url.trim().isEmpty()) return;

        ImageRequest request = new ImageRequest.Builder(target.getContext())
                .data(normalize(url))
                .target(new ImageViewTarget(target))
                .build();

        SingletonImageLoader.get(target.getContext()).enqueue(request);
    }

    public static void prefetch(Context context, List<Channel> items) {
        prefetch(context, items, DEFAULT_PREFETCH_LIMIT);
    }

    public static void prefetch(Context context, List<Channel> items, int limit) {
        if (context == null || items == null || items.isEmpty() || limit <= 0) return;

        Context appContext = context.getApplicationContext();
        Set<String> seen = new HashSet<>();
        int queued = 0;

        for (Channel item : items) {
            if (item == null || item.logo == null || item.logo.trim().isEmpty()) continue;
            String normalized = normalize(item.logo);
            if (!seen.add(normalized)) continue;

            ImageRequest request = new ImageRequest.Builder(appContext)
                    .data(normalized)
                    .build();
            SingletonImageLoader.get(appContext).enqueue(request);

            queued++;
            if (queued >= limit) break;
        }
    }

    private static String normalize(String raw) {
        return raw.trim().replace(" ", "%20");
    }
}
