package com.cochi.client;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Cifrado local AES-GCM respaldado por Android Keystore para secretos de sesión.
 * Migra automáticamente valores antiguos en texto plano la primera vez que se leen.
 */
final class SecureStore {
    private static final String KEY_ALIAS = "cochi.session.aes.v1";
    private static final String PREFIX = "v1:";

    private SecureStore() {}

    static String get(Context context, SharedPreferences prefs, String key, String defaultValue) {
        String stored = prefs.getString(key, null);
        if (stored == null || stored.isEmpty()) return defaultValue;
        if (!stored.startsWith(PREFIX)) {
            // Migración transparente de versiones anteriores.
            put(context, prefs, key, stored);
            return stored;
        }
        try {
            String[] parts = stored.split(":", 3);
            if (parts.length != 3) return defaultValue;
            byte[] iv = Base64.decode(parts[1], Base64.NO_WRAP);
            byte[] encrypted = Base64.decode(parts[2], Base64.NO_WRAP);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
        } catch (Exception ignored) {
            return defaultValue;
        }
    }

    static void put(Context context, SharedPreferences prefs, String key, String value) {
        String clean = value == null ? "" : value;
        if (clean.isEmpty()) {
            prefs.edit().remove(key).apply();
            return;
        }
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
            byte[] encrypted = cipher.doFinal(clean.getBytes(StandardCharsets.UTF_8));
            String encoded = PREFIX
                    + Base64.encodeToString(cipher.getIV(), Base64.NO_WRAP) + ":"
                    + Base64.encodeToString(encrypted, Base64.NO_WRAP);
            prefs.edit().putString(key, encoded).apply();
        } catch (Exception ignored) {
            // Compatibilidad extrema: si un firmware roto no ofrece AndroidKeyStore,
            // no bloqueamos al usuario. El resto de capas (sesión/backend/R8) sigue activo.
            prefs.edit().putString(key, clean).apply();
        }
    }

    private static SecretKey getOrCreateKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        java.security.Key existing = keyStore.getKey(KEY_ALIAS, null);
        if (existing instanceof SecretKey) return (SecretKey) existing;

        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build();
        generator.init(spec);
        return generator.generateKey();
    }
}
