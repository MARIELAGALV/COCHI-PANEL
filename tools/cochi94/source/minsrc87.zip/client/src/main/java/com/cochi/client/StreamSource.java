package com.cochi.client;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Fuente reproducible normalizada. */
public final class StreamSource {
    public final String url;
    public final String type;
    public final Map<String, String> headers;
    public final String qualityLabel;
    public final String serverLabel;
    public final String languageLabel;
    public final String subtitlesLabel;
    public final long bitrate;
    public final int priority;
    public final DrmConfig drm;

    public StreamSource(
            String url,
            String type,
            Map<String, String> headers,
            String qualityLabel,
            long bitrate,
            int priority,
            DrmConfig drm) {
        this(url, type, headers, qualityLabel, "", "", "", bitrate, priority, drm);
    }

    public StreamSource(
            String url,
            String type,
            Map<String, String> headers,
            String qualityLabel,
            String serverLabel,
            String languageLabel,
            String subtitlesLabel,
            long bitrate,
            int priority,
            DrmConfig drm) {
        this.url = safe(url);
        this.type = safe(type).isEmpty() ? "auto" : safe(type);
        this.headers = headers == null || headers.isEmpty()
                ? Collections.emptyMap()
                : Collections.unmodifiableMap(new LinkedHashMap<>(headers));
        this.qualityLabel = safe(qualityLabel);
        this.serverLabel = safe(serverLabel);
        this.languageLabel = safe(languageLabel);
        this.subtitlesLabel = safe(subtitlesLabel);
        this.bitrate = Math.max(0L, bitrate);
        this.priority = priority;
        this.drm = drm == null ? DrmConfig.NONE : drm;
    }

    public boolean isPlayable() {
        return !url.isEmpty();
    }

    private static String safe(String value) {
        return value == null ? "" : value.trim();
    }
}
