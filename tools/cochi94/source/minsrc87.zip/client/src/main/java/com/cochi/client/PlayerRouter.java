package com.cochi.client;

import android.net.Uri;

import java.util.Locale;

public final class PlayerRouter {

    public enum Engine {
        MEDIA3,
        YOUTUBE
    }

    private PlayerRouter() {}

    public static Engine engineFor(String url) {
        return isYoutube(url) ? Engine.YOUTUBE : Engine.MEDIA3;
    }

    public static boolean isYoutube(String url) {
        if (url == null) return false;
        String lower = url.toLowerCase(Locale.ROOT);
        return lower.contains("youtube.com/") || lower.contains("youtu.be/");
    }

    public static String youtubeVideoId(String rawUrl) {
        try {
            if (rawUrl == null) return null;
            String normalized = rawUrl.trim();
            if (!normalized.matches("(?i)^https?://.*")) {
                normalized = "https://" + normalized;
            }
            Uri uri = Uri.parse(normalized);
            String host = uri.getHost();
            if (host == null) return null;
            host = host.toLowerCase(Locale.ROOT);

            if (host.contains("youtu.be")) {
                String path = uri.getPath();
                return path != null && path.length() > 1 ? path.substring(1).split("/")[0] : null;
            }

            String v = uri.getQueryParameter("v");
            if (v != null && !v.isEmpty()) return v;

            String path = uri.getPath();
            if (path != null) {
                String[] parts = path.split("/");
                for (int i = 0; i < parts.length - 1; i++) {
                    if ("embed".equals(parts[i]) || "shorts".equals(parts[i]) || "live".equals(parts[i])) {
                        return parts[i + 1];
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return null;
    }
}
