package com.cochi.client;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;

import java.util.ArrayList;
import java.util.List;

public final class ContinueWatchingAdapter extends RecyclerView.Adapter<ContinueWatchingAdapter.Holder> {
    public interface Listener {
        void onClick(ProgressManager.Entry entry);
        void onOptions(ProgressManager.Entry entry);
    }

    private final Context context;
    private final Listener listener;
    private final List<ProgressManager.Entry> items = new ArrayList<>();

    public ContinueWatchingAdapter(Context context, Listener listener) {
        this.context = context;
        this.listener = listener;
    }

    public void submitList(List<ProgressManager.Entry> next) {
        items.clear();
        if (next != null) items.addAll(next);
        notifyDataSetChanged();
    }

    @NonNull @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        MaterialCardView card = new MaterialCardView(context);
        card.setCardBackgroundColor(ManagedTheme.color(context, R.color.cochi_surface));
        card.setRadius(dp(18));
        card.setClickable(true);
        card.setFocusable(true);
        RecyclerView.LayoutParams cp = new RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(104));
        cp.bottomMargin = dp(10);
        card.setLayoutParams(cp);

        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(10), dp(8), dp(10));

        ImageView image = new ImageView(context);
        image.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(92), dp(72));
        ip.setMarginEnd(dp(16));
        image.setLayoutParams(ip);
        row.addView(image);

        LinearLayout column = new LinearLayout(context);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView title = new TextView(context);
        title.setTextColor(ManagedTheme.color(context, R.color.cochi_text));
        title.setTextSize(17f);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setMaxLines(1);
        column.addView(title);

        TextView subtitle = new TextView(context);
        subtitle.setTextColor(ManagedTheme.color(context, R.color.cochi_muted));
        subtitle.setTextSize(13f);
        column.addView(subtitle);

        ProgressBar progress = new ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(8));
        pp.topMargin = dp(8);
        progress.setLayoutParams(pp);
        column.addView(progress);

        row.addView(column);

        TextView options = new TextView(context);
        options.setText("\u22ee");
        options.setTextColor(ManagedTheme.color(context, R.color.cochi_text));
        options.setTextSize(26f);
        options.setGravity(Gravity.CENTER);
        options.setContentDescription("Opciones de Seguir viendo");
        options.setClickable(true);
        options.setFocusable(true);
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(dp(42), ViewGroup.LayoutParams.MATCH_PARENT);
        op.setMarginStart(dp(4));
        options.setLayoutParams(op);
        row.addView(options);

        card.addView(row);
        return new Holder(card, image, title, subtitle, progress, options);
    }

    @Override public void onBindViewHolder(@NonNull Holder holder, int position) {
        ProgressManager.Entry entry = items.get(position);
        holder.title.setText(entry.name);
        holder.subtitle.setText(("SERIES".equals(entry.source) ? "Serie" : "Película") + " · " + entry.percent() + "% visto");
        holder.progress.setProgress(entry.percent());
        ImageLoader.load(entry.logo, holder.image);
        holder.card.setOnClickListener(v -> listener.onClick(entry));
        holder.card.setOnLongClickListener(v -> {
            listener.onOptions(entry);
            return true;
        });
        holder.options.setOnClickListener(v -> listener.onOptions(entry));
        holder.options.setOnFocusChangeListener((v, focused) ->
                holder.options.setAlpha(focused ? 1f : 0.8f));
        holder.card.setOnFocusChangeListener((v, focused) -> {
            holder.card.setStrokeColor(focused ? ManagedTheme.primary(context) : ManagedTheme.border(context));
            holder.card.setStrokeWidth(dp(focused ? 3 : 1));
        });
    }

    @Override public int getItemCount() { return items.size(); }

    private int dp(int value) {
        return Math.round(value * context.getResources().getDisplayMetrics().density);
    }

    static final class Holder extends RecyclerView.ViewHolder {
        final MaterialCardView card;
        final ImageView image;
        final TextView title;
        final TextView subtitle;
        final ProgressBar progress;
        final TextView options;

        Holder(MaterialCardView card, ImageView image, TextView title, TextView subtitle,
               ProgressBar progress, TextView options) {
            super(card);
            this.card = card;
            this.image = image;
            this.title = title;
            this.subtitle = subtitle;
            this.progress = progress;
            this.options = options;
        }
    }
}
